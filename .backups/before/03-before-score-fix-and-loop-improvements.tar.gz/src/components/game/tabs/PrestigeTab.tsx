"use client";

import { useGameStore } from "@/game/state/store";
import { PRESTIGE_LAYERS, type PrestigeLayerDef } from "@/game/data/prestigeLayers";
import { CHALLENGES } from "@/game/data/challenges";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Crown,
  Flame,
  Lock,
  CheckCircle2,
  Circle,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";

const ADVANCE_THRESHOLD = 3;

type LayerStatus = "locked" | "inProgress" | "complete" | "available" | "planned";

export function PrestigeTab() {
  const galacticWins = useGameStore((s) => s.galacticWins);
  const unlockedChallenges = useGameStore((s) => s.unlockedChallenges);
  const completedChallenges = useGameStore((s) => s.completedChallenges);
  const setShowChallenges = useGameStore((s) => s.setShowChallenges);

  // ----- Layer 1 (Evolution) status logic -----
  // - "locked": no galactic wins and challenges not yet unlocked
  // - "inProgress": unlocked but <3 unique challenges completed
  // - "complete": >=3 unique challenges completed
  const completedCount = CHALLENGES.filter(
    (c) => completedChallenges[c.id]
  ).length;
  const layer1Status: LayerStatus = !unlockedChallenges && galacticWins === 0
    ? "locked"
    : completedCount >= ADVANCE_THRESHOLD
      ? "complete"
      : unlockedChallenges || galacticWins > 0
        ? "inProgress"
        : "locked";

  // Build a status summary line per layer.
  // Layers 2-10 are not yet mechanically unlocked — we show them as
  // "planned" (revealed) or "locked" (mystery "???") based on the
  // completion status of the previous layer in the chain.
  function statusForLayer(layer: PrestigeLayerDef, prevStatus: LayerStatus): LayerStatus {
    if (layer.order === 1) return layer1Status;
    // A later layer is "planned" (revealed name + story) only when the
    // previous layer is complete. Otherwise it's "locked" (???).
    return prevStatus === "complete" ? "planned" : "locked";
  }

  // Compute status per-layer, walking the chain.
  const layerStatuses: Record<string, LayerStatus> = {};
  let prev: LayerStatus = layer1Status;
  for (const layer of PRESTIGE_LAYERS) {
    layerStatuses[layer.id] = statusForLayer(layer, prev);
    prev = layerStatuses[layer.id];
  }

  return (
    <div className="space-y-4">
      {/* Divine Awakening — top hero card */}
      <Card className="glass-panel relative overflow-hidden">
        <div
          className="absolute top-0 right-0 w-48 h-48 pointer-events-none"
          style={{
            background:
              "radial-gradient(circle at top right, rgba(192,132,252,0.25), transparent 70%)",
          }}
        />
        <CardHeader className="pb-2 relative">
          <CardTitle className="text-base flex items-center gap-2">
            <Crown className="w-5 h-5 text-violet-300" />
            Divine Awakening
          </CardTitle>
          <CardDescription>
            Ten ascending tiers of godhood — each a self-contained prestige
            reset with its own mechanics, currency, and unlock criteria.
            Master the current layer to reveal what lies beyond.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Layer status summary line */}
          <div className="flex flex-wrap items-center gap-1.5 text-[0.7rem]">
            {PRESTIGE_LAYERS.map((layer, i) => {
              const status = layerStatuses[layer.id];
              const isComplete = status === "complete";
              const isInProgress = status === "inProgress";
              const isLocked = status === "locked";
              const isPlanned = status === "planned";
              return (
                <span key={layer.id} className="flex items-center gap-1.5">
                  <span
                    className={cn(
                      "px-1.5 py-0.5 rounded border font-mono",
                      isComplete &&
                        "border-emerald-500/40 bg-emerald-500/10 text-emerald-300",
                      isInProgress &&
                        "border-amber-500/40 bg-amber-500/10 text-amber-200",
                      isPlanned &&
                        "border-violet-500/40 bg-violet-500/10 text-violet-200",
                      isLocked &&
                        "border-border bg-muted/30 text-muted-foreground"
                    )}
                  >
                    {isComplete && "✓ "}
                    {isLocked && "🔒 "}
                    {layer.name}
                  </span>
                  {i < PRESTIGE_LAYERS.length - 1 && (
                    <span className="text-muted-foreground/50">·</span>
                  )}
                </span>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Timeline of layers */}
      <div className="space-y-2">
        {PRESTIGE_LAYERS.map((layer, idx) => {
          const status = layerStatuses[layer.id];
          const isLayer1 = layer.order === 1;
          const revealName = status !== "locked";
          const prevComplete = idx === 0 ? false : layerStatuses[PRESTIGE_LAYERS[idx - 1].id] === "complete";
          return (
            <div
              key={layer.id}
              className={cn(
                "relative rounded-lg border p-3 transition-all",
                status === "complete" && "border-emerald-500/40 bg-emerald-500/5",
                status === "inProgress" && "border-amber-500/40 bg-amber-500/5",
                status === "planned" && "border-violet-500/40 bg-violet-500/5",
                status === "locked" && "border-border bg-muted/20 opacity-75"
              )}
            >
              <div className="flex items-start gap-3">
                {/* Order badge */}
                <div
                  className={cn(
                    "shrink-0 w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm border",
                    status === "complete" &&
                      "bg-emerald-500/20 border-emerald-400/60 text-emerald-200",
                    status === "inProgress" &&
                      "bg-amber-500/20 border-amber-400/60 text-amber-100",
                    status === "planned" &&
                      "bg-violet-500/20 border-violet-400/60 text-violet-200",
                    status === "locked" &&
                      "bg-muted/40 border-border text-muted-foreground"
                  )}
                >
                  {status === "complete" ? (
                    <CheckCircle2 className="w-4 h-4" />
                  ) : status === "locked" ? (
                    <Lock className="w-3.5 h-3.5" />
                  ) : (
                    layer.order
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  {/* Name + currency */}
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <h3 className="text-sm font-bold leading-tight">
                      {revealName ? layer.name : "???"}
                    </h3>
                    {revealName && (
                      <Badge variant="outline" className="text-[0.6rem]">
                        {layer.currency}
                      </Badge>
                    )}
                    {status === "complete" && (
                      <Badge
                        variant="outline"
                        className="text-[0.6rem] text-emerald-300 border-emerald-500/40"
                      >
                        Complete
                      </Badge>
                    )}
                    {status === "inProgress" && (
                      <Badge
                        variant="outline"
                        className="text-[0.6rem] text-amber-200 border-amber-500/40"
                      >
                        In Progress
                      </Badge>
                    )}
                    {status === "planned" && (
                      <Badge
                        variant="outline"
                        className="text-[0.6rem] text-violet-200 border-violet-500/40"
                      >
                        Revealed
                      </Badge>
                    )}
                  </div>

                  {/* Story */}
                  {revealName ? (
                    <p className="text-xs text-muted-foreground leading-snug italic">
                      {layer.story}
                    </p>
                  ) : (
                    <p className="text-xs text-muted-foreground italic leading-snug">
                      Complete the previous layer to reveal.
                    </p>
                  )}

                  {/* Layer 1: challenge progress + View Challenges button */}
                  {isLayer1 && (
                    <div className="mt-2 space-y-2">
                      <div>
                        <div className="flex items-center justify-between text-[0.65rem] mb-1">
                          <span className="text-muted-foreground uppercase tracking-wide">
                            {layer.completeState}
                          </span>
                          <span className="font-mono font-bold tabular-nums">
                            {completedCount}/{ADVANCE_THRESHOLD}
                          </span>
                        </div>
                        <Progress
                          value={
                            (Math.min(completedCount, ADVANCE_THRESHOLD) /
                              ADVANCE_THRESHOLD) *
                            100
                          }
                          className="h-1.5"
                        />
                      </div>
                      {status === "locked" ? (
                        <p className="text-[0.7rem] text-muted-foreground flex items-center gap-1.5">
                          <Lock className="w-3 h-3" />
                          Reach the Galactic stage once to unlock Challenges.
                        </p>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 gap-1"
                          onClick={() => setShowChallenges(true)}
                        >
                          <Flame className="w-3 h-3 text-orange-400" />
                          View Challenges
                        </Button>
                      )}
                    </div>
                  )}

                  {/* Locked layers (2-10) that haven't been revealed yet */}
                  {!isLayer1 && status === "locked" && (
                    <p className="text-[0.7rem] text-muted-foreground italic mt-1">
                      {prevComplete
                        ? `Unlock by: ${layer.unlockCondition}`
                        : "Complete the previous layer to reveal."}
                    </p>
                  )}

                  {/* Revealed (planned) layer details */}
                  {!isLayer1 && status === "planned" && (
                    <div className="mt-1.5 space-y-1 text-[0.7rem]">
                      <div className="flex items-start gap-1.5">
                        <Circle className="w-2.5 h-2.5 text-muted-foreground mt-1 shrink-0" />
                        <span className="text-muted-foreground">
                          <span className="text-foreground/80">Mechanics:</span>{" "}
                          {layer.mechanic.join(" · ")}
                        </span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <Sparkles className="w-2.5 h-2.5 text-violet-300 mt-1 shrink-0" />
                        <span className="text-muted-foreground">
                          <span className="text-foreground/80">Reward:</span>{" "}
                          {layer.persistentReward}
                        </span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <Lock className="w-2.5 h-2.5 text-muted-foreground mt-1 shrink-0" />
                        <span className="text-muted-foreground">
                          <span className="text-foreground/80">Next:</span>{" "}
                          {layer.unlockNext}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
