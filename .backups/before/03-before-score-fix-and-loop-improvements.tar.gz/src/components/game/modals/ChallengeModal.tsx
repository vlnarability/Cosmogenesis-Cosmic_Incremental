"use client";

import { useGameStore } from "@/game/state/store";
import {
  CHALLENGES,
  getMaxRepeats,
  getChallengeDebuffAtRepeat,
  getChallengeMasteryAtRepeat,
  type ChallengeDef,
} from "@/game/data/challenges";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Flame, Lock, CheckCircle2, Repeat, AlertCircle, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const ADVANCE_THRESHOLD = 3;

export function ChallengeModal() {
  const showChallenges = useGameStore((s) => s.showChallenges);
  const setShowChallenges = useGameStore((s) => s.setShowChallenges);
  const unlockedChallenges = useGameStore((s) => s.unlockedChallenges);
  const activeChallenge = useGameStore((s) => s.activeChallenge);
  const completedChallenges = useGameStore((s) => s.completedChallenges);
  const challengeRepeatCounts = useGameStore((s) => s.challengeRepeatCounts);
  const upgrades = useGameStore((s) => s.upgrades);
  const setActiveChallenge = useGameStore((s) => s.setActiveChallenge);

  // Max repeats is global: 5 base, 10 with the Challenge Mastery upgrade.
  const maxRepeats = getMaxRepeats((upgrades["challenge_mastery"] || 0) > 0);

  // Aggregate progress.
  const completedCount = CHALLENGES.filter(
    (c) => completedChallenges[c.id]
  ).length;
  const masteredCount = CHALLENGES.filter(
    (c) => (challengeRepeatCounts[c.id] || 0) >= maxRepeats
  ).length;
  const totalCompletions = CHALLENGES.reduce(
    (sum, c) => sum + (challengeRepeatCounts[c.id] || 0),
    0
  );

  const advanceProgress = Math.min(ADVANCE_THRESHOLD, completedCount);

  return (
    <Dialog open={showChallenges} onOpenChange={setShowChallenges}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto glass-strong">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Flame className="w-5 h-5 text-orange-400" />
            Evolution Challenges
          </DialogTitle>
          <DialogDescription>
            Complete 3 to advance to Enlightenment. Repeat for scaling rewards.
          </DialogDescription>
        </DialogHeader>

        {/* Locked state: must first reach a Galactic win to unlock challenges */}
        {!unlockedChallenges && (
          <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-4 flex items-start gap-3">
            <Lock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-semibold text-amber-200">
                Challenges are sealed
              </div>
              <p className="text-xs text-muted-foreground mt-1 leading-snug">
                Reach the Galactic stage once to unlock Evolution Challenges.
                Each challenge is a self-imposed handicap that grants a permanent
                mastery bonus on completion.
              </p>
            </div>
          </div>
        )}

        {/* Progress summary */}
        <div className="rounded-lg border border-border bg-muted/30 p-3 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground uppercase tracking-wide">
              Advancement Progress
            </span>
            <span className="font-mono font-bold tabular-nums">
              {completedCount}/{ADVANCE_THRESHOLD} to advance ·{" "}
              <span className="text-emerald-400">
                {masteredCount}/{CHALLENGES.length} mastered
              </span>
            </span>
          </div>
          <Progress
            value={(advanceProgress / ADVANCE_THRESHOLD) * 100}
            className="h-2"
          />
          <div className="flex items-center justify-between text-[0.65rem] text-muted-foreground">
            <span>
              <span className="text-amber-300">{completedCount}</span> completed
              {" · "}
              <span className="text-cyan-300">{totalCompletions}</span> total
              completions across repeats
            </span>
            <span>Max repeats: {maxRepeats}</span>
          </div>
        </div>

        {/* Challenge cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {CHALLENGES.map((c) => (
            <ChallengeCard
              key={c.id}
              challenge={c}
              active={activeChallenge === c.id}
              completed={!!completedChallenges[c.id]}
              repeatCount={challengeRepeatCounts[c.id] || 0}
              maxRepeats={maxRepeats}
              anyActive={!!activeChallenge}
              onBegin={() => setActiveChallenge(c.id)}
              onAbandon={() => setActiveChallenge(null)}
            />
          ))}
        </div>

        <div className="flex justify-end pt-2">
          <Button variant="outline" onClick={() => setShowChallenges(false)}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ChallengeCard({
  challenge,
  active,
  completed,
  repeatCount,
  maxRepeats,
  anyActive,
  onBegin,
  onAbandon,
}: {
  challenge: ChallengeDef;
  active: boolean;
  completed: boolean;
  repeatCount: number;
  maxRepeats: number;
  anyActive: boolean;
  onBegin: () => void;
  onAbandon: () => void;
}) {
  const maxed = repeatCount >= maxRepeats;
  // The NEXT repeat would be at index `repeatCount` (0-based), which scales
  // the debuff/mastery by (1 + per_repeat * repeatCount).
  const nextDebuff = getChallengeDebuffAtRepeat(challenge.id, repeatCount);
  const nextMastery = getChallengeMasteryAtRepeat(challenge.id, repeatCount);
  const hasDebuff = challenge.debuff.effects.length > 0;

  return (
    <div
      className={cn(
        "stat-card transition-all",
        active && "border-orange-400/60 ring-1 ring-orange-400/40",
        maxed && "opacity-70"
      )}
    >
      {/* Header: icon + name + state badge */}
      <div className="flex items-start justify-between gap-2 mb-1">
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-xl shrink-0">{challenge.icon}</span>
          <div className="min-w-0">
            <div className="text-sm font-semibold truncate flex items-center gap-1.5">
              {challenge.name}
              {active && (
                <Badge className="text-[0.6rem] bg-orange-500/20 border-orange-400/50 text-orange-200">
                  Active
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-1 mt-0.5 flex-wrap">
              {completed && !maxed && (
                <Badge
                  variant="outline"
                  className="text-[0.6rem] text-cyan-300 border-cyan-500/40"
                  title={`Completed ${repeatCount} time(s)`}
                >
                  <Repeat className="w-2.5 h-2.5" /> {repeatCount}/{maxRepeats}
                </Badge>
              )}
              {maxed && (
                <Badge
                  variant="outline"
                  className="text-[0.6rem] text-amber-300 border-amber-500/40"
                  title="Fully mastered"
                >
                  <CheckCircle2 className="w-2.5 h-2.5" /> Maxed
                </Badge>
              )}
            </div>
          </div>
        </div>
      </div>

      <p className="text-xs text-muted-foreground leading-snug mb-2">
        {challenge.desc}
      </p>

      {/* Scaled debuff + mastery for the NEXT repeat */}
      <div className="space-y-1 mb-2">
        {hasDebuff ? (
          <div className="flex items-start gap-1.5 text-[0.7rem]">
            <AlertCircle className="w-3 h-3 text-red-400 shrink-0 mt-0.5" />
            <span className="text-red-300 leading-tight">
              {nextDebuff.label}
              {repeatCount > 0 && (
                <span className="text-muted-foreground ml-1">
                  (next repeat, scaled +{repeatCount * 20}%)
                </span>
              )}
            </span>
          </div>
        ) : (
          <div className="flex items-start gap-1.5 text-[0.7rem]">
            <AlertCircle className="w-3 h-3 text-muted-foreground shrink-0 mt-0.5" />
            <span className="text-muted-foreground italic">No debuff</span>
          </div>
        )}
        <div className="flex items-start gap-1.5 text-[0.7rem]">
          <Sparkles className="w-3 h-3 text-emerald-400 shrink-0 mt-0.5" />
          <span className="text-emerald-300 leading-tight">
            {nextMastery.label}
            {repeatCount > 0 && (
              <span className="text-muted-foreground ml-1">
                (next reward, +{repeatCount * 50}%)
              </span>
            )}
          </span>
        </div>
      </div>

      {/* Action button */}
      <div className="flex justify-end">
        {active ? (
          <Button
            size="sm"
            variant="destructive"
            className="h-7"
            onClick={onAbandon}
          >
            Abandon
          </Button>
        ) : maxed ? (
          <Badge
            variant="outline"
            className="text-[0.65rem] text-amber-300 border-amber-500/40"
          >
            <CheckCircle2 className="w-2.5 h-2.5" /> Maxed
          </Badge>
        ) : completed ? (
          <Button
            size="sm"
            className="h-7"
            disabled={anyActive}
            onClick={onBegin}
            title={
              anyActive
                ? "Abandon the active challenge first"
                : `Start repeat ${repeatCount + 1} of ${maxRepeats}`
            }
          >
            Repeat ({repeatCount + 1}/{maxRepeats})
          </Button>
        ) : (
          <Button
            size="sm"
            className="h-7"
            disabled={anyActive}
            onClick={onBegin}
            title={
              anyActive ? "Abandon the active challenge first" : "Begin challenge"
            }
          >
            Begin Challenge
          </Button>
        )}
      </div>
    </div>
  );
}
