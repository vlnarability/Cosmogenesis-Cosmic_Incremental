// Evolution Challenges — Layer 1 prestige content
//
// Each Challenge is a debuff + mastery pairing: the player runs the game under
// a handicap, and on success they earn a permanent mastery bonus. Challenges
// can be repeated (up to BASE_MAX_REPEATS, or 10 with the "challenge_mastery"
// prestige upgrade). Repeats scale the debuff 20% stronger per repeat and the
// mastery 50% bigger per repeat, so risk and reward both compound.
//
// State fields (already in GameState — see worklog §11):
//   - unlockedChallenges: boolean
//   - activeChallenge: string | null
//   - completedChallenges: Record<string, boolean>   (ever completed at least once)
//   - challengeRepeatCounts: Record<string, number>  (how many times completed)
//
// Reference: /home/z/my-project/upload/data.js DATA.EVOLUTION_CHALLENGES (lines 511-547)
// for the original vanilla-JS challenge shape.

import type { StageId } from "../state/types";

// ----- Types -----

/**
 * A single debuff or mastery effect.
 *
 * `mode`:
 *   - "mult":           multiply the target's output by (1 + value). value is signed.
 *                       e.g. { target: "food", mode: "mult", value: -0.5 } → food output ×0.5
 *   - "flat_per_sec":   add `value` to the target's per-second generation. value is signed.
 *                       e.g. { target: "happiness", mode: "flat_per_sec", value: -0.5 } → -0.5 happiness/s
 *   - "flat":           a flat adjustment to a starting pool / cap. value is signed.
 *                       e.g. { target: "starting_pop", mode: "flat", value: -10 } → start with -10 pop
 *                       e.g. { target: "starting_pop", mode: "flat", value: 10 } → +10 starting pop (mastery)
 *
 * `target` keys are effect handles consumed by the game loop, not ResourceIds.
 * They are plain strings to allow new effect targets without type churn.
 */
export interface ChallengeEffect {
  target: string;
  mode: "mult" | "flat_per_sec" | "flat";
  value: number;
}

export interface ChallengeDebuff {
  /** Short human-readable label, e.g. "−50% Food production". */
  label: string;
  /** Effect list applied while the challenge is active. Empty list = no debuff. */
  effects: ChallengeEffect[];
}

export interface ChallengeMastery {
  /** Short human-readable label, e.g. "+20% Food mastery (permanent)". */
  label: string;
  /** Permanent bonus granted on completion. */
  bonus: ChallengeEffect[];
}

export interface ChallengeCompleteWhen {
  /** Condition type the player must satisfy to clear the challenge. */
  type: "population" | "stage" | "stage_clear" | "stockpile_any";
  /** Numeric threshold (population / stockpile count) or StageId (stage / stage_clear). */
  value: number | StageId;
}

export type ChallengeCategory =
  | "growth" | "food" | "happiness" | "science" | "production"
  | "military" | "starting" | "caps" | "speed";

export interface ChallengeDef {
  id: string;
  name: string;
  desc: string;
  icon: string; // emoji
  category: ChallengeCategory;
  debuff: ChallengeDebuff;
  mastery: ChallengeMastery;
  completeWhen: ChallengeCompleteWhen;
}

// ----- Constants: repeat scaling -----

/** Base maximum number of times any single challenge can be completed. */
export const BASE_MAX_REPEATS = 5;

/** Per-repeat debuff strength multiplier (additive). 0.20 → +20% per repeat. */
export const DEBUFF_SCALE_PER_REPEAT = 0.20;

/** Per-repeat mastery size multiplier (additive). 0.50 → +50% per repeat. */
export const MASTERY_SCALE_PER_REPEAT = 0.50;

// ----- The 10 Evolution challenges -----

export const CHALLENGES: ChallengeDef[] = [
  {
    id: "trial_of_growth",
    name: "Trial of Growth",
    desc: "Population grows sluggishly. Reach a stable body of 100 anyway.",
    icon: "🌱",
    category: "growth",
    debuff: {
      label: "−50% Population Growth",
      effects: [
        { target: "population_growth", mode: "mult", value: -0.50 },
      ],
    },
    mastery: {
      label: "+15% Population Growth (permanent)",
      bonus: [
        { target: "population_growth", mode: "mult", value: 0.15 },
      ],
    },
    completeWhen: { type: "population", value: 100 },
  },
  {
    id: "trial_of_famine",
    name: "Trial of Famine",
    desc: "Food yields wither. Survive the drought long enough to reach the Tribal stage.",
    icon: "🌾",
    category: "food",
    debuff: {
      label: "−50% Food Production",
      effects: [
        { target: "food", mode: "mult", value: -0.50 },
      ],
    },
    mastery: {
      label: "+20% Food Production (permanent)",
      bonus: [
        { target: "food", mode: "mult", value: 0.20 },
      ],
    },
    completeWhen: { type: "stage", value: "tribal" },
  },
  {
    id: "trial_of_discontent",
    name: "Trial of Discontent",
    desc: "Happiness bleeds away every second. Hold civilization together to the Civilization stage.",
    icon: "😔",
    category: "happiness",
    debuff: {
      label: "−0.5 Happiness / sec",
      effects: [
        { target: "happiness", mode: "flat_per_sec", value: -0.5 },
      ],
    },
    mastery: {
      label: "+10% Production (permanent)",
      bonus: [
        { target: "production", mode: "mult", value: 0.10 },
      ],
    },
    completeWhen: { type: "stage", value: "civilization" },
  },
  {
    id: "trial_of_ignorance",
    name: "Trial of Ignorance",
    desc: "Science is dimmed. Build an empire that still learns.",
    icon: "📖",
    category: "science",
    debuff: {
      label: "−50% Science Output",
      effects: [
        { target: "science", mode: "mult", value: -0.50 },
      ],
    },
    mastery: {
      label: "+25% Science Output (permanent)",
      bonus: [
        { target: "science", mode: "mult", value: 0.25 },
      ],
    },
    completeWhen: { type: "stage", value: "empire" },
  },
  {
    id: "trial_of_stagnation",
    name: "Trial of Stagnation",
    desc: "Production chains run thin. Push through to the Solar stage anyway.",
    icon: "⚙️",
    category: "production",
    debuff: {
      label: "−40% Production",
      effects: [
        { target: "production", mode: "mult", value: -0.40 },
      ],
    },
    mastery: {
      label: "+20% Production (permanent)",
      bonus: [
        { target: "production", mode: "mult", value: 0.20 },
      ],
    },
    completeWhen: { type: "stage", value: "solar" },
  },
  {
    id: "trial_of_weakness",
    name: "Trial of Weakness",
    desc: "Military power is sapped. Reach the Galactic stage with a fragile grip on force.",
    icon: "🛡️",
    category: "military",
    debuff: {
      label: "−60% Military Power",
      effects: [
        { target: "military_power", mode: "mult", value: -0.60 },
      ],
    },
    mastery: {
      label: "+30% Military Power (permanent)",
      bonus: [
        { target: "military_power", mode: "mult", value: 0.30 },
      ],
    },
    completeWhen: { type: "stage", value: "galactic" },
  },
  {
    id: "trial_of_the_late_bloom",
    name: "Trial of the Late Bloom",
    desc: "The cycle opens with half its starting population. Catch up to the Galactic stage.",
    icon: "🐣",
    category: "starting",
    debuff: {
      label: "−50% Starting Population",
      effects: [
        { target: "starting_pop", mode: "mult", value: -0.50 },
      ],
    },
    mastery: {
      label: "+10 Starting Population (permanent)",
      bonus: [
        { target: "starting_pop", mode: "flat", value: 10 },
      ],
    },
    completeWhen: { type: "stage", value: "galactic" },
  },
  {
    id: "trial_of_purity",
    name: "Trial of Purity",
    desc: "Resource caps are tightened. Stockpile 500 of any single resource to prove discipline.",
    icon: "💎",
    category: "caps",
    debuff: {
      label: "−30% Resource Caps",
      effects: [
        { target: "caps", mode: "mult", value: -0.30 },
      ],
    },
    mastery: {
      label: "+25% Resource Caps (permanent)",
      bonus: [
        { target: "caps", mode: "mult", value: 0.25 },
      ],
    },
    completeWhen: { type: "stockpile_any", value: 500 },
  },
  {
    id: "trial_of_the_ascetic",
    name: "Trial of the Ascetic",
    desc: "Caps are crushed further. Stockpile 200 of any single resource to prove mastery over want.",
    icon: "🕯️",
    category: "caps",
    debuff: {
      label: "−60% Resource Caps",
      effects: [
        { target: "caps", mode: "mult", value: -0.60 },
      ],
    },
    mastery: {
      label: "+40% Resource Caps (permanent)",
      bonus: [
        { target: "caps", mode: "mult", value: 0.40 },
      ],
    },
    completeWhen: { type: "stockpile_any", value: 200 },
  },
  {
    id: "trial_of_swiftness",
    name: "Trial of Swiftness",
    desc: "No handicap — only speed. Clear the Cell stage to claim the reward.",
    icon: "⏱️",
    category: "speed",
    debuff: {
      label: "No Debuff",
      effects: [],
    },
    mastery: {
      label: "+15% All Production (permanent)",
      bonus: [
        { target: "all_production", mode: "mult", value: 0.15 },
      ],
    },
    completeWhen: { type: "stage_clear", value: "cell" },
  },
];

export const CHALLENGE_MAP: Record<string, ChallengeDef> = Object.fromEntries(
  CHALLENGES.map((c) => [c.id, c])
);

export const CHALLENGE_COUNT: number = CHALLENGES.length;

// ----- Repeat scaling helpers -----

/**
 * Maximum number of times a challenge can be completed.
 * Base is 5; the "challenge_mastery" prestige upgrade raises the cap to 10.
 */
export function getMaxRepeats(hasUpgrade: boolean): number {
  return hasUpgrade ? 10 : BASE_MAX_REPEATS;
}

/**
 * Repeat-count → additive scale multiplier.
 *   repeat 0 → 1.0×  (first run, no prior completions)
 *   repeat 1 → 1.2×  (one prior completion)
 *   repeat 2 → 1.4×
 *   ...
 * Linear (additive) rather than exponential so the curve stays bounded.
 */
function repeatScale(repeatCount: number, perRepeat: number): number {
  // Guard against negative or non-integer repeats.
  const n = Math.max(0, Math.floor(repeatCount));
  return 1 + perRepeat * n;
}

/**
 * Returns a deep-cloned debuff with all effect values scaled by
 * (1 + DEBUFF_SCALE_PER_REPEAT * repeatCount). For a challenge with no debuff
 * (e.g. Trial of Swiftness) the empty effects list is returned as-is.
 */
export function getChallengeDebuffAtRepeat(
  challengeId: string,
  repeatCount: number
): ChallengeDebuff {
  const challenge = CHALLENGE_MAP[challengeId];
  if (!challenge) {
    return { label: "Unknown Challenge", effects: [] };
  }
  const scale = repeatScale(repeatCount, DEBUFF_SCALE_PER_REPEAT);
  return {
    label: challenge.debuff.label,
    effects: challenge.debuff.effects.map((e) => ({
      target: e.target,
      mode: e.mode,
      value: e.value * scale,
    })),
  };
}

/**
 * Returns a deep-cloned mastery with all bonus values scaled by
 * (1 + MASTERY_SCALE_PER_REPEAT * repeatCount). For a challenge whose mastery
 * list is empty, an empty bonus list is returned.
 */
export function getChallengeMasteryAtRepeat(
  challengeId: string,
  repeatCount: number
): ChallengeMastery {
  const challenge = CHALLENGE_MAP[challengeId];
  if (!challenge) {
    return { label: "Unknown Challenge", bonus: [] };
  }
  const scale = repeatScale(repeatCount, MASTERY_SCALE_PER_REPEAT);
  return {
    label: challenge.mastery.label,
    bonus: challenge.mastery.bonus.map((e) => ({
      target: e.target,
      mode: e.mode,
      value: e.value * scale,
    })),
  };
}

/**
 * Aggregate mastery bonus for a given `target` (e.g. "food", "production",
 * "caps") across all completed challenges — assuming each completed challenge
 * was done exactly once (base mastery, repeat 0).
 *
 * Returns the sum of all matching bonus values. Use this for simple
 * "did they earn it?" totals; use {@link challengeMasteryBonusFromRepeats}
 * when you need to credit repeat scaling.
 *
 * @param completed   Record of challengeId → completed-at-least-once flag.
 * @param target      The effect target to aggregate (e.g. "food").
 */
export function challengeMasteryBonus(
  completed: Record<string, boolean>,
  target: string
): number {
  let total = 0;
  for (const challenge of CHALLENGES) {
    if (!completed[challenge.id]) continue;
    for (const effect of challenge.mastery.bonus) {
      if (effect.target === target) {
        total += effect.value;
      }
    }
  }
  return total;
}

/**
 * Aggregate mastery bonus for a given `target` across all challenges,
 * properly accounting for repeat counts. Each completion grants the mastery
 * at the repeat level it was earned at, so a challenge with N completions
 * contributes:
 *
 *   sum over i = 0..(N-1) of base_value * (1 + MASTERY_SCALE_PER_REPEAT * i)
 *
 * @param repeatCounts  Record of challengeId → number of completions.
 * @param target        The effect target to aggregate (e.g. "food").
 */
export function challengeMasteryBonusFromRepeats(
  repeatCounts: Record<string, number>,
  target: string
): number {
  let total = 0;
  for (const challenge of CHALLENGES) {
    const completions = repeatCounts[challenge.id] || 0;
    if (completions <= 0) continue;
    for (const effect of challenge.mastery.bonus) {
      if (effect.target !== target) continue;
      // Sum mastery_at_repeat(i) for i = 0 .. completions - 1.
      for (let i = 0; i < completions; i++) {
        const scale = repeatScale(i, MASTERY_SCALE_PER_REPEAT);
        total += effect.value * scale;
      }
    }
  }
  return total;
}
