// Prestige layers — the 10 ascending tiers of godhood (Evolution → Eternity)
//
// Each layer is a self-contained prestige reset that introduces its own
// mechanics, currency, and unlock criteria. The list is ordered 1..10; the
// next layer unlocks when the player meets the current layer's `unlockNext`
// condition. Layer 1 (Evolution) is the active starting layer; the rest
// remain "locked" / "planned" until the player reaches them.
//
// Reference: /home/z/my-project/upload/data.js DATA.PRESTIGE_LAYERS (lines 6-17).

import type { StageId } from "../state/types";

export type PrestigeLayerUnlockStage = StageId | "future";

export interface PrestigeLayerDef {
  /** Stable identifier (matches `unlockedLayers` keys in GameState). */
  id: string;
  /** Human-readable layer name. */
  name: string;
  /** 1-based ordinal in the prestige chain (Evolution = 1, Eternity = 10). */
  order: number;
  /** Narrative blurb — what the god is becoming at this layer. */
  story: string;
  /** Short human-readable description of the unlock requirement. */
  unlockCondition: string;
  /** Stage the layer is gated on, or `"future"` for layers past the Galactic stage. */
  unlockStage: PrestigeLayerUnlockStage;
  /** Currency earned and spent at this layer (e.g. "Evolution Points"). */
  currency: string;
  /** Button label shown on the prestige reset prompt. */
  resetLabel: string;
  /** Longer flavour description of what the layer is about. */
  desc: string;
  /** Sub-mechanic group labels (e.g. ["Offerings", "Rituals", "Scripts", "Blood Pact"]). */
  mechanic: string[];
  /** What counts as "completing" this layer — used to gate the next layer. */
  completeState: string;
  /** Persistent reward that carries forward to subsequent layers / runs. */
  persistentReward: string;
  /** Trigger condition (human-readable) that unlocks the next prestige layer. */
  unlockNext: string;
}

export const PRESTIGE_LAYERS: PrestigeLayerDef[] = [
  {
    id: "evolution",
    name: "Evolution",
    order: 1,
    story:
      "The god is barely awake. It learns by testing life through hardship, challenges, and mastery — " +
      "watching the first cells struggle upward and remembering every defeat as a piece of itself.",
    unlockCondition: "Available from the start",
    unlockStage: "cell",
    currency: "Evolution Points",
    resetLabel: "Seed New Life",
    desc:
      "The first awakening. Test life through Challenges. Each cleared Trial grants mastery that " +
      "carries forward into every subsequent run and ascension.",
    mechanic: ["Challenges"],
    completeState: "Complete 3 of 10 Challenges",
    persistentReward: "+5% production per Challenge mastered (stacks across runs)",
    unlockNext: "Complete 3 Challenges to awaken Enlightenment",
  },
  {
    id: "enlightenment",
    name: "Enlightenment",
    order: 2,
    story:
      "The god becomes self-aware and begins interpreting reality. Enlightenment strengthens foresight, " +
      "route control, and the reading of fate — Divinity flows during the run itself.",
    unlockCondition: "Complete 3 Evolution Challenges",
    unlockStage: "galactic",
    currency: "Enlightenment",
    resetLabel: "Awaken to Foresight",
    desc:
      "A 20-node Foresight tree with 6 routes through it. Buy nodes to chart the path the god wills " +
      "for creation. Routes unlock permanent bonuses that persist into later layers.",
    mechanic: ["Foresight", "Routes"],
    completeState: "Buy 10 of 20 Foresight nodes",
    persistentReward: "Each Foresight node bought grants a small permanent production bonus",
    unlockNext: "Buy 10 Foresight nodes to step beyond causality into Transcendence",
  },
  {
    id: "transcendence",
    name: "Transcendence",
    order: 3,
    story:
      "The god separates from creation and begins drawing power from offerings, rituals, and scripts. " +
      "The world becomes a vessel, and what is poured into it returns as divinity.",
    unlockCondition: "Buy 10 Foresight nodes (Enlightenment)",
    unlockStage: "galactic",
    currency: "Transcendence",
    resetLabel: "Step Beyond Causality",
    desc:
      "Convert worldly resources into Transcendence via Offerings, automate the flow with Rituals, " +
      "script repeatable sacrifice loops, and seal the highest yield with a Blood Pact.",
    mechanic: ["Offerings", "Rituals", "Scripts", "Blood Pact"],
    completeState: "Perform a Blood Pact",
    persistentReward: "Each Ritual authored grants a permanent +2% offering yield",
    unlockNext: "Perform a Blood Pact to descend into the world as its Genesis author",
  },
  {
    id: "genesis",
    name: "Genesis",
    order: 4,
    story:
      "The god becomes a true creator. Before life begins, it defines cradle worlds, sacred geography, " +
      "and dormant seeds — the conditions under which the next universe will wake.",
    unlockCondition: "Perform a Blood Pact (Transcendence)",
    unlockStage: "future",
    currency: "Genesis",
    resetLabel: "Author a Cradle World",
    desc:
      "Design a world from scratch: choose cradle worlds, prime conditions, sacred geography, " +
      "dormant seeds, and a difficulty rating. The next run inherits these author choices.",
    mechanic: ["Cradle Worlds", "Prime Conditions", "Geography", "Dormant Seeds", "Difficulty"],
    completeState: "Author a complete Cradle World (all 5 facets set)",
    persistentReward: "Authored Cradle World traits seed into every subsequent run's starting conditions",
    unlockNext: "Author a complete Cradle World to be recognized as Apotheosis",
  },
  {
    id: "apotheosis",
    name: "Apotheosis",
    order: 5,
    story:
      "Civilization recognizes the god. Divine laws, worship modes, miracles, and heresy define the run — " +
      "the creator is no longer silent, and creation responds.",
    unlockCondition: "Author a complete Cradle World (Genesis)",
    unlockStage: "future",
    currency: "Apotheosis",
    resetLabel: "Reveal the Divine",
    desc:
      "Issue Divine Laws that bind the run, choose Worship Modes for how civilizations pray, perform " +
      "Miracles for direct intervention, and manage Heresy when belief fractures.",
    mechanic: ["Divine Laws", "Worship Modes", "Miracles", "Heresy Management"],
    completeState: "Codify 3 Divine Laws and resolve a Heresy schism",
    persistentReward: "Each codified Divine Law grants a permanent +3% production at all later layers",
    unlockNext: "Resolve a Heresy schism to ascend into the Singularity",
  },
  {
    id: "singularity",
    name: "Singularity",
    order: 6,
    story:
      "The god enters the machinery of reality itself. Relic loadouts, compression, and logic cores " +
      "let it shape the substrate beneath creation.",
    unlockCondition: "Resolve a Heresy schism (Apotheosis)",
    unlockStage: "future",
    currency: "Singularity",
    resetLabel: "Merge With the System",
    desc:
      "Equip Relic Loadouts for passive bonuses, Compress redundant systems into denser cores, and " +
      "deploy Logic Cores that execute scheduled divine actions on a tick loop.",
    mechanic: ["Relic Loadouts", "Compression", "Logic Cores"],
    completeState: "Install 3 Logic Cores and Compress one system tier",
    persistentReward: "Installed Logic Cores carry their automation into all future runs",
    unlockNext: "Compress one system tier to wield Omnipotence over natural boundaries",
  },
  {
    id: "omnipotence",
    name: "Omnipotence",
    order: 7,
    story:
      "Lineage bindings, unstable fusions, and narrow rule rewrites let the god sustain contradiction. " +
      "Power and paradox grow in the same hand.",
    unlockCondition: "Compress one system tier (Singularity)",
    unlockStage: "future",
    currency: "Omnipotence",
    resetLabel: "Deny Natural Boundaries",
    desc:
      "Bind a Hybrid Lineage (a primary + rare archetype fusion), watch the Instability meter rise " +
      "with each paradox, and toggle between 3 Stances (Builder / Destroyer / Weaver) to shape the run.",
    mechanic: ["Hybrid Lineage", "Instability Meter", "3 Stances"],
    completeState: "Survive an Instability peak without the meter overflowing",
    persistentReward: "Each sustained Stance peak grants a permanent +5% to that Stance's domain",
    unlockNext: "Survive an Instability peak to choose the Divine Face",
  },
  {
    id: "divinity",
    name: "Divinity",
    order: 8,
    story:
      "Prayer routing, divine masks, and worship polarity decide how creation perceives and feeds the god. " +
      "The creator's face becomes a question with more than one answer.",
    unlockCondition: "Survive an Instability peak (Omnipotence)",
    unlockStage: "future",
    currency: "Divinity",
    resetLabel: "Choose the Divine Face",
    desc:
      "Open Prayer Channels that route worship into different divine currencies, wear Divine Masks that " +
      "shift the god's perceived nature, and set Worship Polarity (Bright / Dark / Void) for run-long effects.",
    mechanic: ["Prayer Channels", "Divine Masks", "Worship Polarity"],
    completeState: "Open 3 Prayer Channels and align Worship Polarity",
    persistentReward: "Each open Prayer Channel permanently raises the cap of its divine currency",
    unlockNext: "Align Worship Polarity to bind many histories into Infinity",
  },
  {
    id: "infinity",
    name: "Infinity",
    order: 9,
    story:
      "Echo runs, forks, and future debt turn the god into a curator of timelines rather than one " +
      "civilization. Every choice has already been made — somewhere.",
    unlockCondition: "Align Worship Polarity (Divinity)",
    unlockStage: "future",
    currency: "Infinity",
    resetLabel: "Bind Many Histories",
    desc:
      "Spawn Echo runs that mirror your save state, Fork timelines to test divergent choices, and " +
      "borrow against Future Debt for immediate power that compounds into later layers.",
    mechanic: ["Echoes", "Forks", "Future Debt"],
    completeState: "Fork a timeline and repay the resulting Future Debt",
    persistentReward: "Each repaid Future Debt grants a permanent +5% production bonus",
    unlockNext: "Repay a Future Debt to author the Final Testament",
  },
  {
    id: "eternity",
    name: "Eternity",
    order: 10,
    story:
      "The story ends with canon, permanence, and the final authored universe. The god stops creating " +
      "long enough to look back at everything it has been.",
    unlockCondition: "Repay a Future Debt (Infinity)",
    unlockStage: "future",
    currency: "Eternity",
    resetLabel: "Write the Final Testament",
    desc:
      "Author Testament Clauses that lock the canon of your run history, Canonize specific achievements " +
      "as eternal truths, weave Permanence into the world's fabric, and finally choose an Ending " +
      "(Silence, Cycle, or Open Hand) for the universe you leave behind.",
    mechanic: ["Testament Clauses", "Canonization", "Permanence Weaves", "Ending Choice"],
    completeState: "Choose an Ending (Silence / Cycle / Open Hand)",
    persistentReward: "Each Testament Clause permanently boosts one system across all future ascensions",
    unlockNext: "Terminal layer — choosing an Ending closes the loop",
  },
];

export const PRESTIGE_LAYER_MAP: Record<string, PrestigeLayerDef> = Object.fromEntries(
  PRESTIGE_LAYERS.map((l) => [l.id, l])
);

export const PRESTIGE_LAYER_COUNT: number = PRESTIGE_LAYERS.length;

export function getPrestigeLayer(id: string): PrestigeLayerDef | undefined {
  return PRESTIGE_LAYER_MAP[id];
}

export function nextPrestigeLayer(id: string): PrestigeLayerDef | null {
  const idx = PRESTIGE_LAYERS.findIndex((l) => l.id === id);
  if (idx < 0 || idx >= PRESTIGE_LAYERS.length - 1) return null;
  return PRESTIGE_LAYERS[idx + 1];
}
