"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { GameState, GameStore, StageId, TabId } from "./types";
import { emptyResources, emptyCapacities } from "../data/resources";
import { STAGES, STAGE_IDS, nextStage } from "../data/stages";
import { ACTION_MAP } from "../data/actions";
import { SYSTEMS, SYSTEM_MAP, systemCost } from "../data/systems";
import { TECH_MAP, TECHS } from "../data/techs";
import { UPGRADE_MAP, UPGRADES, upgradeCost } from "../data/upgrades";
import { STORY_MAP, STORY_TRIGGERS } from "../data/story";
import { ARCHETYPE_MAP, dominantArchetype } from "../data/archetypes";
import { ACHIEVEMENTS, achievementBonus, type AchievementCheckCtx } from "../data/achievements";
import { EVENTS, eventsForStage, EVENT_MAP } from "../data/events";
import {
  CHALLENGE_MAP,
  challengeMasteryBonusFromRepeats,
  getMaxRepeats,
  getChallengeDebuffAtRepeat,
} from "../data/challenges";
import { RESOURCES as ALL_RESOURCES } from "../data/resources";

const STORAGE_KEY = "evolution_idle_v2";

function initialRunState(): Partial<GameState> {
  const resources = emptyResources();
  const capacities = emptyCapacities();
  resources.atp = 15;
  resources.glucose = 20;
  resources.happiness = 75;
  return {
    stageIndex: 0,
    time: 0,
    population: 8,
    populationProgress: 0,
    maxPopulation: 8,
    resources,
    capacities,
    ownedSystems: {},
    systemEnabled: {},
    technologies: {},
    lockedTechs: {},
    archetypeAffinity: {},
    lockedArchetype: null,
    log: ["New run started. The first spark stirs."],
  };
}

function initialMetaState(): Partial<GameState> {
  return {
    evolutionPoints: 0,
    totalRuns: 0,
    galacticWins: 0,
    stageClearCounts: Object.fromEntries(STAGE_IDS.map((s) => [s, 0])) as Record<StageId, number>,
    fastestCellClear: 0,
    totalEventsResolved: 0,
    totalPlayTime: 0,
    totalActions: 0,
    totalSystemsBuilt: 0,
    totalTechResearched: 0,
    upgrades: Object.fromEntries(UPGRADES.map((u) => [u.id, 0])),
    storyUnlocked: { first_spark: true },
    storyAcknowledged: {},
    archive: [],
    archivedArchetypes: [],
    unlockedLayers: { evolution: true },
    achievements: {},
    newAchievements: [],
    unlockedChallenges: false,
    activeChallenge: null,
    completedChallenges: {},
    challengeRepeatCounts: {},
    showChallenges: false,
    showPrestigeTab: false,
    currentTab: "actions",
    speed: 1,
    paused: false,
    showShop: false,
    showEvolve: false,
    showSettings: false,
    activeStoryPopup: "first_spark",
    activeEvent: null,
    eventCooldown: 30, // first event fires sooner (30s) to hook new players
    eventHistory: [],
    hasSeenIntro: false,
    lastSaved: Date.now(),
    tutorialStep: 0,
    tutorialActive: true,
    tutorialDismissed: false,
    eventFrequency: "normal",
  };
}

export const useGameStore = create<GameStore>()(
  persist(
    (set, get) => ({
      ...initialRunState(),
      ...initialMetaState(),

      // ============ TICK ============
      tick: (dt) => {
        const s = get();
        if (s.paused) return;
        // Temporal Acceleration: permanent game-speed multiplier (Layer 1 upgrade)
        const speedMultLvl = s.upgrades["temporal_acceleration"] || 0;
        const permSpeedMult = 1 + speedMultLvl * 0.5;
        const realDt = dt * s.speed * permSpeedMult;

        const autoLvl = s.upgrades["inherited_efficiency"] || 0;
        // Deep Memory: +5% production per prestige (scales with totalRuns)
        const deepMemoryLvl = s.upgrades["deep_memory"] || 0;
        const prestigeMult = 1 + deepMemoryLvl * 0.05 * (s.totalRuns || 0);
        const autoMult = (1 + autoLvl * 0.15) * prestigeMult;
        const techMult = techMultiplier(s, "production");
        const capBoostLvl = s.upgrades["expansive_vaults"] || 0;
        const capMult = 1 + capBoostLvl * 0.20;
        const hasAutoBalancer = (s.upgrades["auto_balancer"] || 0) > 0;

        // Archetype bonus
        const archetype = s.lockedArchetype ? ARCHETYPE_MAP[s.lockedArchetype] : null;
        const archAllMult = archetype?.bonus.allProductionMult || 0;
        const archPopMult = archetype?.bonus.populationGrowthMult || 0;
        const archCapMult = archetype?.bonus.capMult || 0;

        // Challenge debuffs (Layer 1: Evolution) — scaled by repeat count.
        // Each effect is a {target, mode, value}. Modes: mult | flat_per_sec | flat.
        // Targets: food | science | production | military_power | population_growth |
        //          happiness | caps | starting_pop | all_production
        let challengeFoodMult = 1;
        let challengeScienceMult = 1;
        let challengeProdMult = 1;
        let challengeMilitaryMult = 1;
        let challengePopMult = 1;
        let challengeAllProdMult = 1;
        let challengeCapMult = 1;
        let challengeHappinessDrain = 0;
        if (s.activeChallenge) {
          const ch = CHALLENGE_MAP[s.activeChallenge];
          if (ch) {
            const currentRepeat = (s.challengeRepeatCounts || {})[s.activeChallenge] || 0;
            const nextRepeat = currentRepeat + 1;
            const scaledDebuff = getChallengeDebuffAtRepeat(s.activeChallenge, nextRepeat);
            for (const e of scaledDebuff.effects) {
              // Only mult and flat_per_sec effects apply mid-tick.
              // flat effects (e.g. starting_pop) are applied at run start, not here.
              if (e.mode === "mult") {
                const v = e.value;
                switch (e.target) {
                  case "food": challengeFoodMult *= (1 + v); break;
                  case "science": challengeScienceMult *= (1 + v); break;
                  case "production": challengeProdMult *= (1 + v); break;
                  case "military_power": challengeMilitaryMult *= (1 + v); break;
                  case "population_growth": challengePopMult *= (1 + v); break;
                  case "all_production": challengeAllProdMult *= (1 + v); break;
                  case "caps": challengeCapMult *= (1 + v); break;
                  default: break;
                }
              } else if (e.mode === "flat_per_sec") {
                if (e.target === "happiness") {
                  challengeHappinessDrain += e.value;
                }
              }
            }
          }
        }

        const resources = { ...s.resources };
        let capacities = recomputeCapacitiesFresh(s, capMult + archCapMult);
        // Apply challenge cap debuff after base capacity computation
        if (challengeCapMult !== 1) {
          for (const r of Object.keys(capacities)) {
            capacities[r] = Math.max(1, (capacities[r] || 0) * challengeCapMult);
          }
        }

        // Apply system production — with cap-aware pausing
        for (const [sysId, count] of Object.entries(s.ownedSystems)) {
          if (!count) continue;
          const sys = SYSTEM_MAP[sysId];
          if (!sys) continue;
          if (sys.requiredTech && !s.technologies[sys.requiredTech]) continue;

          // Check if system is manually disabled
          const manuallyEnabled = s.systemEnabled[sysId] !== false; // default true
          if (!manuallyEnabled && !hasAutoBalancer) continue;

          // Cap-aware logic: if all output resources are at cap, idle the system
          // (don't produce, don't consume upkeep — no waste)
          const outputsCapped = Object.keys(sys.produces).length > 0 &&
            Object.keys(sys.produces).every((r) => {
              const cap = capacities[r] || 0;
              return (resources[r] || 0) >= cap - 0.01;
            });

          if (outputsCapped) {
            // System idles — no production, no upkeep
            continue;
          }

          const stageMult = sys.stage === STAGES[s.stageIndex].id ? 1 : 0.5;
          const mult = autoMult * techMult * stageMult * (1 + archAllMult) * challengeAllProdMult;

          // Per-resource archetype bonus + challenge debuff
          const produces = sys.produces as Record<string, number>;
          for (const [r, v] of Object.entries(produces)) {
            const archResBonus = archetype?.bonus.productionMult?.[r] || 0;
            let resChallengeMult = 1;
            if (r === "food") resChallengeMult = challengeFoodMult;
            else if (r === "science") resChallengeMult = challengeScienceMult;
            else if (r === "production") resChallengeMult = challengeProdMult;
            else if (r === "military_power") resChallengeMult = challengeMilitaryMult;
            const rate = v * count * mult * (1 + archResBonus) * resChallengeMult;
            resources[r] = (resources[r] || 0) + rate * realDt;
          }
          // Upkeep
          if (sys.upkeep) {
            const upkeep = sys.upkeep as Record<string, number>;
            for (const [r, v] of Object.entries(upkeep)) {
              resources[r] = (resources[r] || 0) - v * count * realDt;
            }
          }
        }

        // Challenge: flat-per-second happiness drain
        if (challengeHappinessDrain !== 0) {
          const cap = capacities.happiness || 100;
          resources.happiness = Math.max(0, Math.min(cap, (resources.happiness || 0) + challengeHappinessDrain * realDt));
        }

        // Clamp resources to capacities (no overflow)
        for (const r of Object.keys(resources)) {
          const cap = capacities[r];
          if (cap != null && resources[r] > cap) resources[r] = cap;
          if (resources[r] < 0) resources[r] = 0;
        }

        // Slow passive ATP for cell (keeps early game from stalling)
        if (STAGES[s.stageIndex].id === "cell") {
          resources.atp = Math.min(capacities.atp || 30, resources.atp + 0.5 * realDt);
        }

        // Happiness drift toward 50 baseline if no source
        // (prevents permanent high happiness from start)
        // — disabled: let systems/tech maintain it

        // Population growth with progress bar
        // Growth rate scales with happiness and food/water availability
        let popGrowthRate = 0.015; // base per second
        const happiness = resources.happiness || 50;
        popGrowthRate *= (1 + (happiness - 40) / 200); // happiness 100 → +30%, happiness 20 → -10%
        popGrowthRate *= (1 + archPopMult);
        popGrowthRate *= challengePopMult;
        // Penalty if food/water are critically low (creature+)
        const curStage = STAGES[s.stageIndex];
        if (["creature", "tribal", "civilization", "empire"].includes(curStage.id)) {
          const foodCap = capacities.food || 1;
          const waterCap = capacities.water || 1;
          const foodPct = (resources.food || 0) / foodCap;
          const waterPct = (resources.water || 0) / waterCap;
          if (foodPct < 0.1) popGrowthRate *= 0.3;
          if (waterPct < 0.1) popGrowthRate *= 0.3;
        }

        let populationProgress = (s.populationProgress || 0) + popGrowthRate * realDt;
        let population = s.population;
        while (populationProgress >= 1) {
          populationProgress -= 1;
          population += 1;
        }

        const maxPopulation = Math.max(s.maxPopulation || 0, population);

        const newTime = s.time + realDt;

        // Check story triggers
        const newStory = { ...s.storyUnlocked };
        let activePopup = s.activeStoryPopup;
        const ctx = { ...s, resources, ownedSystems: s.ownedSystems };
        for (const trig of STORY_TRIGGERS) {
          if (!newStory[trig.id] && trig.condition(ctx)) {
            newStory[trig.id] = true;
            if (!activePopup) activePopup = trig.id;
          }
        }

        // Check achievements periodically (every ~2 seconds of game time)
        let achievements = s.achievements;
        let newAchievements = s.newAchievements;
        const checkInterval = 2.0;
        const lastCheck = (s as any)._lastAchCheck || 0;
        if (newTime - lastCheck >= checkInterval) {
          const curState = { ...s, resources, time: newTime } as GameState;
          const result = checkAchievements(curState);
          if (result.newOnes.length > 0) {
            achievements = result.earned;
            newAchievements = [...(newAchievements || []), ...result.newOnes];
          } else if (Object.keys(result.earned).length !== Object.keys(achievements || {}).length) {
            achievements = result.earned;
          }
          (s as any)._lastAchCheck = newTime; // not persisted, just a runtime marker
        }

        // Challenge completion check (every ~5 seconds of game time)
        // completeWhen types: population | stage | stage_clear | stockpile_any
        let activeChallenge = s.activeChallenge;
        let completedChallenges = s.completedChallenges;
        let challengeRepeatCounts = s.challengeRepeatCounts;
        if (activeChallenge && newTime - ((s as any)._lastChallengeCheck || 0) > 5) {
          (s as any)._lastChallengeCheck = newTime;
          const ch = CHALLENGE_MAP[activeChallenge];
          if (ch) {
            const cw = ch.completeWhen;
            let completed = false;
            if (cw.type === "population") {
              completed = population >= (cw.value as number);
            } else if (cw.type === "stage") {
              const targetIdx = STAGE_IDS.indexOf(cw.value as StageId);
              completed = targetIdx >= 0 && s.stageIndex >= targetIdx;
            } else if (cw.type === "stage_clear") {
              // "clear" means the player has cleared that stage at least once (this run or earlier)
              const stageId = cw.value as StageId;
              completed = (s.stageClearCounts?.[stageId] || 0) > 0 || s.stageIndex > STAGE_IDS.indexOf(stageId);
            } else if (cw.type === "stockpile_any") {
              const threshold = cw.value as number;
              completed = Object.values(resources).some((v) => (v || 0) >= threshold);
            }
            if (completed) {
              completedChallenges = { ...(s.completedChallenges || {}), [activeChallenge]: true };
              const newRepeatCounts = { ...(s.challengeRepeatCounts || {}) };
              const currentRepeat = (newRepeatCounts[activeChallenge] || 0) + 1;
              newRepeatCounts[activeChallenge] = currentRepeat;
              challengeRepeatCounts = newRepeatCounts;
              get().addToLog(`Challenge mastered: ${ch.name} (repeat ${currentRepeat}).`);
              activeChallenge = null;
            }
          }
        }

        // Auto-buyer logic (Layer 1 upgrades: auto_system_buyer, auto_tech_buyer, auto_evolver)
        // We compute desired purchases here and apply them via the pending state in set().
        const pendingAutoBuys: { systems: Record<string, number>; techs: string[] } = { systems: {}, techs: [] };
        let autoEvolveTrigger = false;
        const autoSystemLvl = s.upgrades["auto_system_buyer"] || 0;
        const autoTechLvl = s.upgrades["auto_tech_buyer"] || 0;
        const autoEvolverLvl = s.upgrades["auto_evolver"] || 0;
        if (autoSystemLvl > 0 && newTime - ((s as any)._lastAutoBuySystem || 0) > 8) {
          (s as any)._lastAutoBuySystem = newTime;
          // Find cheapest affordable system in the current stage that we don't own yet (or can buy more of)
          const stageId = STAGES[s.stageIndex].id;
          const costReduction = (s.upgrades["frugality"] || 0) * 0.04;
          let best: { sysId: string; totalCost: number } | null = null;
          for (const sys of SYSTEMS) {
            if (sys.stage !== stageId) continue;
            if (sys.requiredTech && !s.technologies[sys.requiredTech]) continue;
            const owned = s.ownedSystems[sys.id] || 0;
            if (sys.maxOwned && owned >= sys.maxOwned) continue;
            const cost = systemCost(sys, owned, costReduction);
            let totalCost = 0;
            let canAfford = true;
            for (const [r, v] of Object.entries(cost)) {
              if ((resources[r] || 0) < (v as number)) { canAfford = false; break; }
              totalCost += (v as number);
            }
            if (canAfford && (!best || totalCost < best.totalCost)) {
              best = { sysId: sys.id, totalCost };
            }
          }
          if (best) {
            pendingAutoBuys.systems[best.sysId] = (pendingAutoBuys.systems[best.sysId] || 0) + 1;
            // Deduct cost immediately so subsequent calculations in the same tick are consistent
            const sys = SYSTEM_MAP[best.sysId];
            const owned = s.ownedSystems[best.sysId] || 0;
            const cost = systemCost(sys, owned, costReduction);
            for (const [r, v] of Object.entries(cost)) {
              resources[r] = (resources[r] || 0) - (v as number);
            }
          }
        }
        if (autoTechLvl > 0 && newTime - ((s as any)._lastAutoBuyTech || 0) > 12) {
          (s as any)._lastAutoBuyTech = newTime;
          // Find cheapest affordable tech in the current stage that's not yet researched
          const stageId = STAGES[s.stageIndex].id;
          let best: { techId: string; totalCost: number } | null = null;
          for (const tech of TECHS) {
            if (tech.stage !== stageId) continue;
            if (s.technologies[tech.id]) continue;
            // Respect mutually-exclusive tech locks — both player-set and
            // implicit (any of the exclusiveWith partners already researched).
            if (s.lockedTechs && s.lockedTechs[tech.id]) continue;
            if (tech.exclusiveWith && tech.exclusiveWith.some((ex) => s.technologies[ex])) continue;
            if (tech.requires) {
              let reqMet = true;
              for (const req of tech.requires) {
                if (!s.technologies[req]) { reqMet = false; break; }
              }
              if (!reqMet) continue;
            }
            let totalCost = 0;
            let canAfford = true;
            for (const [r, v] of Object.entries(tech.cost)) {
              if ((resources[r] || 0) < (v as number)) { canAfford = false; break; }
              totalCost += (v as number);
            }
            if (canAfford && (!best || totalCost < best.totalCost)) {
              best = { techId: tech.id, totalCost };
            }
          }
          if (best) {
            pendingAutoBuys.techs.push(best.techId);
            const tech = TECH_MAP[best.techId];
            for (const [r, v] of Object.entries(tech.cost)) {
              resources[r] = (resources[r] || 0) - (v as number);
            }
          }
        }
        // Auto-Evolver: trigger evolve if requirements are met at threshold (100% + level*20%)
        if (autoEvolverLvl > 0) {
          const stage = STAGES[s.stageIndex];
          const next = nextStage(stage.id);
          if (next) {
            const reqs = stage.evolveRequires;
            const evolveBoost = 1 - Math.min(0.30, (s.upgrades["evolutionary_momentum"] || 0) * 0.05);
            const threshold = 1 + autoEvolverLvl * 0.20;
            const totalSystems = Object.values(s.ownedSystems).reduce((a, b) => a + b, 0);
            const totalTech = Object.keys(s.technologies).length;
            const score = computeScore(s);
            if (
              s.population >= reqs.minPopulation * evolveBoost * threshold &&
              totalSystems >= reqs.minSystems * evolveBoost * threshold &&
              totalTech >= reqs.minTech * evolveBoost * threshold
            ) {
              autoEvolveTrigger = true;
            }
          }
        }

        // Apply pending auto-buys to owned systems / technologies
        let ownedSystems = s.ownedSystems;
        let systemEnabled = s.systemEnabled;
        let technologies = s.technologies;
        let lockedTechs = s.lockedTechs;
        let archetypeAffinity = s.archetypeAffinity;
        let totalSystemsBuilt = s.totalSystemsBuilt || 0;
        let totalTechResearched = s.totalTechResearched || 0;
        if (Object.keys(pendingAutoBuys.systems).length > 0) {
          ownedSystems = { ...s.ownedSystems };
          systemEnabled = { ...s.systemEnabled };
          archetypeAffinity = { ...s.archetypeAffinity };
          for (const [sysId, count] of Object.entries(pendingAutoBuys.systems)) {
            const sys = SYSTEM_MAP[sysId];
            ownedSystems[sysId] = (ownedSystems[sysId] || 0) + count;
            if (systemEnabled[sysId] === undefined) systemEnabled[sysId] = true;
            if (sys.grantsAffinity) {
              archetypeAffinity[sys.grantsAffinity.archetype] =
                (archetypeAffinity[sys.grantsAffinity.archetype] || 0) + sys.grantsAffinity.amount * count;
            }
            totalSystemsBuilt += count;
            get().addToLog(`Auto-Builder purchased ${count}× ${sys.name}.`);
          }
        }
        if (pendingAutoBuys.techs.length > 0) {
          technologies = { ...s.technologies };
          archetypeAffinity = archetypeAffinity === s.archetypeAffinity ? { ...s.archetypeAffinity } : archetypeAffinity;
          for (const techId of pendingAutoBuys.techs) {
            technologies[techId] = true;
            const tech = TECH_MAP[techId];
            if (tech.grantsAffinity) {
              archetypeAffinity[tech.grantsAffinity.archetype] =
                (archetypeAffinity[tech.grantsAffinity.archetype] || 0) + tech.grantsAffinity.amount;
            }
            // Apply exclusiveWith lock when the auto-buyer picks an exclusive tech
            if (tech.exclusiveWith && tech.exclusiveWith.length > 0) {
              if (lockedTechs === s.lockedTechs) lockedTechs = { ...(s.lockedTechs || {}) };
              for (const ex of tech.exclusiveWith) {
                (lockedTechs as Record<string, boolean>)[ex] = true;
              }
            }
            totalTechResearched += 1;
            get().addToLog(`Auto-Researcher researched ${tech.name}.`);
          }
        }

        // Random event firing — only if no popup/modal is active
        let activeEvent = s.activeEvent;
        let eventCooldown = (s.eventCooldown || 0) - realDt;
        if (eventCooldown < 0) eventCooldown = 0;
        const eventFreq = s.eventFrequency || "normal";
        if (eventFreq !== "off" && !activeEvent && !activePopup && eventCooldown === 0) {
          const stageId = STAGES[s.stageIndex].id;
          const possible = eventsForStage(stageId, newTime);
          if (possible.length > 0) {
            // Weighted random selection
            const totalWeight = possible.reduce((sum, e) => sum + e.weight, 0);
            const roll = Math.random() * totalWeight;
            let cum = 0;
            for (const ev of possible) {
              cum += ev.weight;
              if (roll < cum) {
                activeEvent = ev.id;
                // Cooldown depends on frequency setting AND stage depth.
                // Early stages (Cell, Creature) get more events to keep the
                // opening engaging; later stages use the longer default.
                //   normal:   early 45-90s  · later 90-180s
                //   frequent: early 25-50s  · later 30-60s
                const isEarlyStage = stageId === "cell" || stageId === "creature";
                const base = eventFreq === "frequent"
                  ? (isEarlyStage ? 25 : 30)
                  : (isEarlyStage ? 45 : 90);
                const range = eventFreq === "frequent"
                  ? (isEarlyStage ? 25 : 30)
                  : (isEarlyStage ? 45 : 90);
                eventCooldown = base + Math.random() * range;
                break;
              }
            }
          }
        }

        set({
          resources,
          capacities,
          time: newTime,
          population,
          maxPopulation,
          populationProgress,
          storyUnlocked: newStory,
          activeStoryPopup: activePopup,
          achievements,
          newAchievements,
          activeEvent,
          eventCooldown,
          activeChallenge,
          completedChallenges,
          challengeRepeatCounts,
          ownedSystems,
          systemEnabled,
          technologies,
          lockedTechs,
          archetypeAffinity,
          totalSystemsBuilt,
          totalTechResearched,
          totalPlayTime: (s.totalPlayTime || 0) + realDt,
        });

        // Auto-Evolver: trigger evolve after state is committed
        if (autoEvolveTrigger) {
          get().evolveStage();
        }
      },

      // ============ ACTIONS ============
      performAction: (actionId) => {
        const s = get();
        const action = ACTION_MAP[actionId];
        if (!action) return;
        if (action.stage !== STAGES[s.stageIndex].id) return;

        const res = { ...s.resources };

        // Check if all output resources are at cap — if so, block (no waste)
        const outputs = Object.entries(action.produces);
        if (outputs.length > 0) {
          const allCapped = outputs.every(([r]) => {
            const cap = s.capacities[r] || 0;
            return (res[r] || 0) >= cap - 0.001;
          });
          if (allCapped) return; // action wasted — block it
        }

        // Check costs
        if (action.cost) {
          for (const [r, v] of Object.entries(action.cost)) {
            if ((res[r] || 0) < (v as number)) return;
          }
          for (const [r, v] of Object.entries(action.cost)) {
            res[r] -= v as number;
          }
        }

        // Manual action multiplier
        const manualLvl = s.upgrades["quickened_hands"] || 0;
        const mult = 1 + manualLvl * 0.25;
        const techMult = techMultiplier(s, "manual");
        const finalMult = mult * techMult;

        // Archetype per-resource bonus
        const archetype = s.lockedArchetype ? ARCHETYPE_MAP[s.lockedArchetype] : null;

        for (const [r, v] of Object.entries(action.produces)) {
          const cap = s.capacities[r] || 0;
          const archResBonus = archetype?.bonus.productionMult?.[r] || 0;
          const totalArchMult = 1 + archResBonus + (archetype?.bonus.allProductionMult || 0);
          const amount = (v as number) * finalMult * totalArchMult;
          res[r] = Math.min(cap, (res[r] || 0) + amount);
        }

        set({
          resources: res,
          totalActions: (s.totalActions || 0) + 1,
        });
      },

      buySystem: (systemId, qty) => {
        const s = get();
        const sys = SYSTEM_MAP[systemId];
        if (!sys) return;
        if (sys.stage !== STAGES[s.stageIndex].id) return;
        // Check tech prerequisite
        if (sys.requiredTech && !s.technologies[sys.requiredTech]) return;

        const costReduction = (s.upgrades["frugality"] || 0) * 0.04;
        let owned = s.ownedSystems[systemId] || 0;
        if (sys.maxOwned && owned >= sys.maxOwned) return;

        const res = { ...s.resources };
        const ownedSystems = { ...s.ownedSystems };
        const systemEnabled = { ...s.systemEnabled };
        const archetypeAffinity = { ...s.archetypeAffinity };

        let bought = 0;
        for (let i = 0; i < qty; i++) {
          if (sys.maxOwned && owned + bought >= sys.maxOwned) break;
          const cost = systemCost(sys, owned + bought, costReduction);
          let canAfford = true;
          for (const [r, v] of Object.entries(cost)) {
            if ((res[r] || 0) < (v as number)) {
              canAfford = false;
              break;
            }
          }
          if (!canAfford) break;
          for (const [r, v] of Object.entries(cost)) {
            res[r] -= v as number;
          }
          bought++;
        }

        if (bought === 0) return;

        ownedSystems[systemId] = owned + bought;
        // New systems are enabled by default
        if (systemEnabled[systemId] === undefined) systemEnabled[systemId] = true;

        // Apply archetype affinity grant
        if (sys.grantsAffinity) {
          const arch = sys.grantsAffinity.archetype;
          archetypeAffinity[arch] = (archetypeAffinity[arch] || 0) + sys.grantsAffinity.amount * bought;
        }

        // Trigger story
        const newStory = { ...s.storyUnlocked };
        let activePopup = s.activeStoryPopup;
        for (const trig of STORY_TRIGGERS) {
          if (!newStory[trig.id] && trig.condition({ ...s, resources: res, ownedSystems })) {
            newStory[trig.id] = true;
            if (!activePopup) activePopup = trig.id;
          }
        }

        set({
          resources: res,
          ownedSystems,
          systemEnabled,
          archetypeAffinity,
          storyUnlocked: newStory,
          activeStoryPopup: activePopup,
          totalSystemsBuilt: (s.totalSystemsBuilt || 0) + bought,
        });
        get().addToLog(`Built ${bought}× ${sys.name}.`);
      },

      toggleSystem: (systemId) => {
        const s = get();
        if (!s.ownedSystems[systemId]) return;
        const systemEnabled = { ...s.systemEnabled };
        systemEnabled[systemId] = systemEnabled[systemId] === false ? true : false;
        set({ systemEnabled });
      },

      enableAllSystems: (enabled) => {
        const s = get();
        const systemEnabled: Record<string, boolean> = {};
        for (const id of Object.keys(s.ownedSystems)) {
          systemEnabled[id] = enabled;
        }
        set({ systemEnabled });
      },

      buyTech: (techId) => {
        const s = get();
        const tech = TECH_MAP[techId];
        if (!tech) return;
        if (s.technologies[techId]) return;
        if (s.lockedTechs && s.lockedTechs[techId]) return;
        if (tech.stage !== STAGES[s.stageIndex].id) return;
        if (tech.requires) {
          for (const req of tech.requires) {
            if (!s.technologies[req]) return;
          }
        }
        // Exclusive path check — if any mutually-exclusive tech is already
        // researched, block the purchase. (The "lock the others on buy"
        // step below ensures this also fires for the second pick.)
        if (tech.exclusiveWith) {
          for (const ex of tech.exclusiveWith) {
            if (s.technologies[ex]) {
              get().addToLog(
                `Cannot research ${tech.name} — exclusive path already chosen (${TECH_MAP[ex]?.name || ex}).`
              );
              return;
            }
          }
        }
        const res = { ...s.resources };
        for (const [r, v] of Object.entries(tech.cost)) {
          if ((res[r] || 0) < (v as number)) return;
        }
        for (const [r, v] of Object.entries(tech.cost)) {
          res[r] -= v as number;
        }
        const technologies = { ...s.technologies, [techId]: true };
        const archetypeAffinity = { ...s.archetypeAffinity };
        if (tech.grantsAffinity) {
          archetypeAffinity[tech.grantsAffinity.archetype] =
            (archetypeAffinity[tech.grantsAffinity.archetype] || 0) + tech.grantsAffinity.amount;
        }
        // Lock mutually-exclusive techs after purchase — this makes the
        // choice permanent for the rest of the run.
        const lockedTechs = { ...(s.lockedTechs || {}) };
        if (tech.exclusiveWith) {
          for (const ex of tech.exclusiveWith) {
            lockedTechs[ex] = true;
          }
        }
        set({
          resources: res,
          technologies,
          lockedTechs,
          archetypeAffinity,
          totalTechResearched: (s.totalTechResearched || 0) + 1,
        });
        get().addToLog(`Researched ${tech.name}.`);
        if (tech.exclusiveWith && tech.exclusiveWith.length > 0) {
          const names = tech.exclusiveWith
            .map((id) => TECH_MAP[id]?.name || id)
            .join(", ");
          get().addToLog(`Locked exclusive paths: ${names}.`);
        }
      },

      buyUpgrade: (upgradeId) => {
        const s = get();
        const up = UPGRADE_MAP[upgradeId];
        if (!up) return;
        if (up.requiresWins && s.galacticWins < up.requiresWins) return;
        const owned = s.upgrades[upgradeId] || 0;
        if (owned >= up.maxLevel) return;
        const cost = upgradeCost(up, owned);
        if (s.evolutionPoints < cost) return;
        const upgrades = { ...s.upgrades, [upgradeId]: owned + 1 };
        set({
          evolutionPoints: s.evolutionPoints - cost,
          upgrades,
        });
        get().addToLog(`Purchased ${up.name} (Lv ${owned + 1}).`);
      },

      evolveStage: () => {
        const s = get();
        const stage = STAGES[s.stageIndex];
        const next = nextStage(stage.id);
        if (!next) {
          get().triggerPrestige();
          return;
        }
        const reqs = stage.evolveRequires;
        const evolveBoost = 1 - Math.min(0.30, (s.upgrades["evolutionary_momentum"] || 0) * 0.05);
        const totalSystems = Object.values(s.ownedSystems).reduce((a, b) => a + b, 0);
        const totalTech = Object.keys(s.technologies).length;
        const score = computeScore(s);

        if (s.population < reqs.minPopulation * evolveBoost) return;
        if (totalSystems < reqs.minSystems * evolveBoost) return;
        if (totalTech < reqs.minTech * evolveBoost) return;
        // Score is NOT a requirement — it only affects EP earned at prestige

        const nextStageIdx = s.stageIndex + 1;
        const nextStageDef = STAGES[nextStageIdx];

        const resources = { ...s.resources };
        const capBoostLvl = s.upgrades["expansive_vaults"] || 0;
        const capMult = 1 + capBoostLvl * 0.20;
        const archetype = s.lockedArchetype ? ARCHETYPE_MAP[s.lockedArchetype] : null;
        const archCapMult = archetype?.bonus.capMult || 0;
        const capacities = recomputeCapacitiesFresh(s, capMult + archCapMult);

        const newStory = { ...s.storyUnlocked };
        const storyId = STORY_MAP[
          nextStageDef.id === "creature" ? "first_body_stirs"
          : nextStageDef.id === "tribal" ? "fire_remembered"
          : nextStageDef.id === "civilization" ? "cities_learn_to_dream"
          : nextStageDef.id === "empire" ? "distance_begins_to_obey"
          : nextStageDef.id === "solar" ? "sky_stops_being_a_wall"
          : "galaxy_takes_a_shape"
        ];
        if (storyId) newStory[storyId.id] = true;

        // Lock archetype when evolving from Creature → Tribal
        let lockedArchetype = s.lockedArchetype;
        if (stage.id === "creature" && !lockedArchetype) {
          const dom = dominantArchetype(s.archetypeAffinity);
          if (dom) {
            lockedArchetype = dom;
            get().addToLog(`Lineage locked: ${ARCHETYPE_MAP[dom].name}.`);
          } else {
            lockedArchetype = "humanoid"; // default fallback
            get().addToLog(`Lineage locked: Humanoid (no drift).`);
          }
        }

        const stageClearCounts = { ...s.stageClearCounts, [stage.id]: (s.stageClearCounts[stage.id] || 0) + 1 };

        // Track fastest Cell clear
        let fastestCellClear = s.fastestCellClear || 0;
        if (stage.id === "cell") {
          const clearTime = s.time;
          if (fastestCellClear === 0 || clearTime < fastestCellClear) {
            fastestCellClear = clearTime;
          }
        }

        // Check achievements after stage clear
        const postEvolveState = { ...s, stageClearCounts, lockedArchetype, fastestCellClear } as GameState;
        const achResult = checkAchievements(postEvolveState);
        const newAchievements = achResult.newOnes.length > 0
          ? [...(s.newAchievements || []), ...achResult.newOnes]
          : s.newAchievements;

        set({
          stageIndex: nextStageIdx,
          resources,
          capacities,
          storyUnlocked: newStory,
          activeStoryPopup: storyId?.id || s.activeStoryPopup,
          stageClearCounts,
          fastestCellClear,
          lockedArchetype,
          achievements: achResult.earned,
          newAchievements,
        });
        get().addToLog(`Evolved to ${nextStageDef.name}. ${nextStageDef.tagline}`);
      },

      triggerPrestige: () => {
        const s = get();
        const stage = STAGES[s.stageIndex];
        const score = computeScore(s);
        const stageMult = [1, 2, 4, 8, 16, 32, 64][s.stageIndex] || 1;
        // Cosmic Understanding: +25% EP earned per level
        const epMultLvl = s.upgrades["cosmic_understanding"] || 0;
        const epMult = 1 + epMultLvl * 0.25;
        const epEarned = Math.max(1, Math.floor(Math.sqrt(score / 100) * stageMult * epMult));

        const archive = [...s.archive];
        const archName = s.lockedArchetype ? ARCHETYPE_MAP[s.lockedArchetype]?.name : "Humanoid";
        archive.unshift({
          runId: `run_${s.totalRuns + 1}`,
          timestamp: Date.now(),
          stage: stage.id,
          archetype: s.lockedArchetype || "humanoid",
          score,
          epEarned,
          duration: s.time,
          ending: s.stageIndex >= 6 ? "Galactic Ascension" : `${stage.name} Evolution (${archName})`,
        });

        const archivedArchetypes = Array.from(new Set([
          ...(s.archivedArchetypes || []),
          ...(s.lockedArchetype ? [s.lockedArchetype] : []),
        ]));

        const fresh = initialRunState();

        // Apply starting bonuses to fresh run state (Layer 1 upgrades)
        // - Warm Start: +5 per level to atp, glucose, proteins, lipids
        // - Frontier Spirit: +10 per level to starting population
        // - Ancestral Bounty: +10 per level to every primary resource
        const warmStartLvl = s.upgrades["warm_start"] || 0;
        const frontierLvl = s.upgrades["frontier_spirit"] || 0;
        const ancestralLvl = s.upgrades["ancestral_bounty"] || 0;
        if (warmStartLvl > 0 && fresh.resources) {
          const bonus = warmStartLvl * 5;
          fresh.resources.atp = (fresh.resources.atp || 0) + bonus;
          fresh.resources.glucose = (fresh.resources.glucose || 0) + bonus;
          fresh.resources.proteins = (fresh.resources.proteins || 0) + bonus;
          fresh.resources.lipids = (fresh.resources.lipids || 0) + bonus;
        }
        if (frontierLvl > 0) {
          const popBonus = frontierLvl * 10;
          fresh.population = (fresh.population || 0) + popBonus;
          fresh.maxPopulation = Math.max(fresh.maxPopulation || 0, fresh.population);
        }
        if (ancestralLvl > 0 && fresh.resources) {
          const resBonus = ancestralLvl * 10;
          for (const r of ALL_RESOURCES) {
            if (r.category === "primary") {
              fresh.resources[r.id] = (fresh.resources[r.id] || 0) + resBonus;
            }
          }
        }
        // Challenge: Trial of the Late Bloom — apply -50% starting pop debuff
        // (only if a challenge is currently active and has starting_pop mult effect)
        if (s.activeChallenge) {
          const ch = CHALLENGE_MAP[s.activeChallenge];
          if (ch) {
            const currentRepeat = (s.challengeRepeatCounts || {})[s.activeChallenge] || 0;
            const nextRepeat = currentRepeat + 1;
            const scaledDebuff = getChallengeDebuffAtRepeat(s.activeChallenge, nextRepeat);
            for (const e of scaledDebuff.effects) {
              if (e.mode === "mult" && e.target === "starting_pop" && fresh.population != null) {
                fresh.population = Math.max(1, Math.floor(fresh.population * (1 + e.value)));
                fresh.maxPopulation = Math.max(fresh.maxPopulation || 0, fresh.population);
              } else if (e.mode === "flat" && e.target === "starting_pop" && fresh.population != null) {
                fresh.population = Math.max(1, fresh.population + e.value);
                fresh.maxPopulation = Math.max(fresh.maxPopulation || 0, fresh.population);
              }
            }
          }
        }
        // Challenge mastery: +15 starting pop from Trial of Growth mastery (flat)
        // Apply via challengeMasteryBonusFromRepeats for repeat-aware stacking
        if (fresh.population != null) {
          const startPopFlat = challengeMasteryBonusFromRepeats(s.challengeRepeatCounts || {}, "starting_pop");
          if (startPopFlat > 0) {
            fresh.population = fresh.population + startPopFlat;
            fresh.maxPopulation = Math.max(fresh.maxPopulation || 0, fresh.population);
          }
        }

        // Determine if challenges should unlock (first Galactic win)
        const newGalacticWins = s.galacticWins + (s.stageIndex >= 6 ? 1 : 0);
        const unlockedChallenges = s.unlockedChallenges || newGalacticWins >= 1;

        const metaState: Partial<GameState> = {
          evolutionPoints: s.evolutionPoints + epEarned,
          totalRuns: s.totalRuns + 1,
          galacticWins: newGalacticWins,
          archive,
          archivedArchetypes,
          upgrades: s.upgrades,
          storyUnlocked: { ...s.storyUnlocked, god_opens_its_eyes: true },
          storyAcknowledged: s.storyAcknowledged,
          unlockedLayers: s.unlockedLayers,
          stageClearCounts: s.stageClearCounts,
          fastestCellClear: s.fastestCellClear,
          totalEventsResolved: s.totalEventsResolved,
          totalPlayTime: s.totalPlayTime,
          totalActions: s.totalActions,
          totalSystemsBuilt: s.totalSystemsBuilt,
          totalTechResearched: s.totalTechResearched,
          achievements: s.achievements,
          newAchievements: s.newAchievements,
          // Layer 1: Evolution — challenge state preserved across prestige
          unlockedChallenges,
          completedChallenges: s.completedChallenges || {},
          challengeRepeatCounts: s.challengeRepeatCounts || {},
          activeChallenge: null, // challenges reset their debuff on prestige (fresh run)
        };

        // Check achievements after prestige
        const postState = { ...s, ...metaState } as GameState;
        const achResult = checkAchievements(postState);
        metaState.achievements = achResult.earned;
        if (achResult.newOnes.length > 0) {
          metaState.newAchievements = [...(s.newAchievements || []), ...achResult.newOnes];
        }

        set({
          ...fresh,
          ...metaState,
          currentTab: "actions",
          speed: 1,
          paused: false,
          showShop: false,
          showEvolve: false,
          activeStoryPopup: s.totalRuns === 0 ? "god_opens_its_eyes" : null,
          hasSeenIntro: true,
          lastSaved: Date.now(),
          tutorialActive: false,
        });
        get().addToLog(`Prestige! Earned ${epEarned} Evolution Points.`);
      },

      setTab: (tab) => set({ currentTab: tab }),
      setSpeed: (speed) => set({ speed }),
      togglePause: () => set((s) => ({ paused: !s.paused })),
      setShowShop: (v) => set({ showShop: v }),
      setShowEvolve: (v) => set({ showEvolve: v }),
      setShowSettings: (v) => set({ showSettings: v }),
      dismissTutorial: () => set({ tutorialActive: false, tutorialDismissed: true }),
      setEventFrequency: (freq) => set({ eventFrequency: freq }),

      resolveEvent: (eventId, choiceId) => {
        const s = get();
        const ev = EVENT_MAP[eventId];
        if (!ev) {
          set({ activeEvent: null });
          return;
        }
        const choice = ev.choices.find((c) => c.id === choiceId);
        if (!choice) {
          set({ activeEvent: null });
          return;
        }
        // Apply effects
        const res = { ...s.resources };
        if (choice.resourceChanges) {
          for (const [r, v] of Object.entries(choice.resourceChanges)) {
            const cap = s.capacities[r] || Infinity;
            res[r] = Math.max(0, Math.min(cap, (res[r] || 0) + (v as number)));
          }
        }
        let pop = s.population;
        if (choice.populationChange) {
          pop = Math.max(0, pop + choice.populationChange);
        }
        if (choice.happinessChange) {
          const cap = s.capacities.happiness || 100;
          res.happiness = Math.max(0, Math.min(cap, (res.happiness || 0) + choice.happinessChange));
        }
        const archetypeAffinity = { ...s.archetypeAffinity };
        if (choice.affinityChange) {
          for (const ac of choice.affinityChange) {
            archetypeAffinity[ac.archetype] = (archetypeAffinity[ac.archetype] || 0) + ac.amount;
          }
        }
        // Record in event history
        const eventHistory = [
          {
            eventId: ev.id,
            eventName: ev.name,
            eventIcon: ev.icon,
            choiceId: choice.id,
            choiceLabel: choice.label,
            timestamp: Date.now(),
            gameTime: s.time,
          },
          ...(s.eventHistory || []),
        ].slice(0, 50); // keep last 50
        set({
          resources: res,
          population: pop,
          maxPopulation: Math.max(s.maxPopulation || 0, pop),
          archetypeAffinity,
          activeEvent: null,
          eventHistory,
          totalEventsResolved: (s.totalEventsResolved || 0) + 1,
        });
        if (choice.logMsg) get().addToLog(`${ev.name}: ${choice.logMsg}`);

        // Check achievements after event resolution
        const postEventState = get();
        const achResult = checkAchievements(postEventState);
        if (achResult.newOnes.length > 0) {
          set({
            achievements: achResult.earned,
            newAchievements: [...(postEventState.newAchievements || []), ...achResult.newOnes],
          });
        }
      },

      dismissStory: (id) => {
        const s = get();
        const ack = { ...s.storyAcknowledged, [id]: true };
        set({ activeStoryPopup: null, storyAcknowledged: ack });
      },

      dismissAchievementToast: () => {
        set({ newAchievements: [] });
      },

      applyOfflineProgress: () => {
        const s = get();
        if (!s.lastSaved) return null;
        const elapsedSec = Math.floor((Date.now() - s.lastSaved) / 1000);
        // Only apply if away for more than 30 seconds
        if (elapsedSec < 30) return null;
        // Cap: base 24h, +24h per temporal_reserves tier
        const tempReservesLvl = s.upgrades["temporal_reserves"] || 0;
        const maxBank = 86400 + tempReservesLvl * 86400;
        const appliedDt = Math.min(elapsedSec, maxBank);
        if (appliedDt < 30) return null;

        // Snapshot resources before to compute gains
        const before = { ...s.resources };

        // Apply tick at compressed speed (cap at 86400 per call to avoid huge loops)
        // We simulate in chunks of 3600s (1 hour) to stay performant
        const chunkSize = 3600;
        let remaining = appliedDt;
        // Temporarily set speed to 1 and call tick with large dt
        while (remaining > 0) {
          const chunk = Math.min(chunkSize, remaining);
          get().tick(chunk);
          remaining -= chunk;
          // Re-read state in case it changed
          const cur = get();
          if (cur.paused) break;
        }

        const after = get();
        const resourcesGained: Record<string, number> = {};
        for (const r of Object.keys(after.resources)) {
          const gain = (after.resources[r] || 0) - (before[r] || 0);
          if (Math.abs(gain) > 0.01) resourcesGained[r] = gain;
        }

        get().addToLog(`Offline progress: simulated ${Math.floor(appliedDt / 60)}m ${Math.floor(appliedDt % 60)}s away.`);

        return { elapsed: appliedDt, resourcesGained, applied: true };
      },

      addToLog: (msg) => {
        const s = get();
        const ts = new Date().toLocaleTimeString();
        const entry = `[${ts}] ${msg}`;
        const log = [entry, ...s.log].slice(0, 100);
        set({ log });
      },

      hardReset: () => {
        if (typeof window !== "undefined") {
          localStorage.removeItem(STORAGE_KEY);
        }
        const fresh = { ...initialRunState(), ...initialMetaState() };
        set(fresh);
      },

      saveGame: () => {
        set({ lastSaved: Date.now() });
      },

      loadGame: () => {
        // Handled by persist middleware
      },

      exportSave: () => {
        const s = get();
        return btoa(unescape(encodeURIComponent(JSON.stringify(s))));
      },

      importSave: (data) => {
        try {
          const parsed = JSON.parse(decodeURIComponent(escape(atob(data))));
          set(parsed);
          return true;
        } catch {
          return false;
        }
      },

      setShowChallenges: (v) => set({ showChallenges: v }),
      setActiveChallenge: (id) => {
        const s = get();
        if (id) {
          const ch = CHALLENGE_MAP[id];
          if (!ch) return;
          const hasMasteryUpgrade = (s.upgrades["challenge_mastery"] || 0) > 0;
          const maxRepeats = getMaxRepeats(hasMasteryUpgrade);
          const currentRepeats = (s.challengeRepeatCounts || {})[id] || 0;
          if (currentRepeats >= maxRepeats) {
            get().addToLog(`${ch.name} already mastered ${maxRepeats} times — cannot repeat further.`);
            return;
          }
          const nextRepeat = currentRepeats + 1;
          const scaledDebuff = getChallengeDebuffAtRepeat(id, nextRepeat);
          set({ activeChallenge: id });
          get().addToLog(
            `Challenge started: ${ch.name} (repeat ${nextRepeat}/${maxRepeats}). ${scaledDebuff.label}.`
          );
        } else {
          set({ activeChallenge: null });
          get().addToLog("Challenge abandoned.");
        }
      },
    }),
    {
      name: STORAGE_KEY,
      storage: createJSONStorage(() => {
        if (typeof window === "undefined") {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return window.localStorage;
      }),
      version: 3,
      partialize: (s) => s,
      // Migrate old saves (v1 → v2 → v3) to new structure
      migrate: (persisted: any, version: number) => {
        if (!persisted) return persisted;
        if (version < 2) {
          if (!persisted.systemEnabled) persisted.systemEnabled = {};
          if (!persisted.archetypeAffinity) persisted.archetypeAffinity = {};
          if (persisted.lockedArchetype === undefined) persisted.lockedArchetype = null;
          if (persisted.populationProgress === undefined) persisted.populationProgress = 0;
          if (!persisted.achievements) persisted.achievements = {};
          if (!persisted.newAchievements) persisted.newAchievements = [];
          if (persisted.upgrades) {
            if (persisted.upgrades.auto_balancer === undefined) persisted.upgrades.auto_balancer = 0;
            if (persisted.upgrades.archetype_insight === undefined) persisted.upgrades.archetype_insight = 0;
          }
        }
        // Always ensure achievements fields exist (even on v2)
        if (!persisted.achievements) persisted.achievements = {};
        if (!persisted.newAchievements) persisted.newAchievements = [];
        if (persisted.showSettings === undefined) persisted.showSettings = false;
        if (persisted.tutorialDismissed === undefined) persisted.tutorialDismissed = false;
        if (persisted.maxPopulation === undefined) persisted.maxPopulation = persisted.population || 8;
        if (persisted.fastestCellClear === undefined) persisted.fastestCellClear = 0;
        if (persisted.activeEvent === undefined) persisted.activeEvent = null;
        if (persisted.eventCooldown === undefined) persisted.eventCooldown = 30;
        if (!persisted.eventHistory) persisted.eventHistory = [];
        if (persisted.totalEventsResolved === undefined) persisted.totalEventsResolved = 0;
        if (persisted.totalPlayTime === undefined) persisted.totalPlayTime = 0;
        if (persisted.totalActions === undefined) persisted.totalActions = 0;
        if (persisted.totalSystemsBuilt === undefined) persisted.totalSystemsBuilt = 0;
        if (persisted.totalTechResearched === undefined) persisted.totalTechResearched = 0;
        if (!persisted.eventFrequency) persisted.eventFrequency = "normal";
        // v5: lockedTechs (exclusiveWith mechanic) — default to empty
        if (!persisted.lockedTechs) persisted.lockedTechs = {};
        // Layer 1 (Challenges/Prestige) migration
        if (persisted.unlockedChallenges === undefined) persisted.unlockedChallenges = false;
        if (persisted.activeChallenge === undefined) persisted.activeChallenge = null;
        if (!persisted.completedChallenges) persisted.completedChallenges = {};
        if (!persisted.challengeRepeatCounts) persisted.challengeRepeatCounts = {};
        if (persisted.showChallenges === undefined) persisted.showChallenges = false;
        if (persisted.showPrestigeTab === undefined) persisted.showPrestigeTab = false;
        // Upgrade roster migration: remove deprecated, add new defaults
        if (persisted.upgrades) {
          // Removed upgrades: quickened_hands (manual_mult — instant click), rival_insight (score-only)
          delete persisted.upgrades.quickened_hands;
          delete persisted.upgrades.rival_insight;
          // New upgrades default to level 0
          for (const id of [
            "auto_system_buyer", "auto_tech_buyer", "auto_evolver",
            "frontier_spirit", "ancestral_bounty",
            "challenge_mastery", "stage_compression",
            "temporal_acceleration", "deep_memory", "cosmic_understanding",
          ]) {
            if (persisted.upgrades[id] === undefined) persisted.upgrades[id] = 0;
          }
        }
        return persisted;
      },
    }
  )
);

// ============ HELPERS ============

function techMultiplier(s: GameState, target: "production" | "manual" | "capacity"): number {
  let mult = 1;
  for (const [techId, owned] of Object.entries(s.technologies)) {
    if (!owned) continue;
    const tech = TECH_MAP[techId];
    if (!tech || !tech.multiplier) continue;
    if (tech.multiplier.target === target || tech.multiplier.target === "production") {
      mult += tech.multiplier.value;
    }
  }
  // Achievement production bonus
  const ctx = buildAchievementCtx(s);
  mult += achievementBonus(s.achievements || {}, ctx, "production");
  // Challenge mastery bonus (Layer 1) — repeat-aware aggregation
  if (target === "production") {
    // "production" target covers the Trial of Discontent/Stagnation mastery
    mult += challengeMasteryBonusFromRepeats(s.challengeRepeatCounts || {}, "production");
    // "all_production" mastery (Trial of Swiftness) applies to all production
    mult += challengeMasteryBonusFromRepeats(s.challengeRepeatCounts || {}, "all_production");
  }
  return mult;
}

function buildAchievementCtx(s: GameState): AchievementCheckCtx {
  const systemsDiscoveredCount = Object.keys(s.ownedSystems).filter((id) => (s.ownedSystems[id] || 0) > 0).length;
  const techResearchedCount = Object.keys(s.technologies).filter((id) => s.technologies[id]).length;
  const upgradesOwnedCount = Object.values(s.upgrades).filter((c) => c > 0).length;
  const storyUnlockedCount = Object.keys(s.storyUnlocked).filter((id) => s.storyUnlocked[id]).length;
  return {
    galacticWins: s.galacticWins,
    totalRuns: s.totalRuns,
    stageClearCounts: s.stageClearCounts,
    archivedArchetypes: s.archivedArchetypes || [],
    storyUnlockedCount,
    systemsDiscoveredCount,
    techResearchedCount,
    upgradesOwnedCount,
    maxPopulation: s.maxPopulation || 0,
    fastestCellClear: s.fastestCellClear || 0,
    totalEventsResolved: s.totalEventsResolved || 0,
  };
}

// Check all achievements; return new ones earned
function checkAchievements(s: GameState): { earned: Record<string, boolean>; newOnes: string[] } {
  const ctx = buildAchievementCtx(s);
  const earned = { ...(s.achievements || {}) };
  const newOnes: string[] = [];
  for (const ach of ACHIEVEMENTS) {
    if (!earned[ach.id] && ach.check(ctx)) {
      earned[ach.id] = true;
      newOnes.push(ach.id);
    }
  }
  return { earned, newOnes };
}

function computeScore(s: GameState): number {
  const totalSystems = Object.values(s.ownedSystems).reduce((a, b) => a + b, 0);
  const totalTech = Object.keys(s.technologies).length;
  const resourceSum = Object.values(s.resources).reduce((a, b) => a + b, 0);
  return Math.floor(
    s.population * 2 +
    totalSystems * 5 +
    totalTech * 10 +
    resourceSum * 0.5 +
    s.time * 0.1
  );
}

// Recompute all capacities from scratch based on owned systems
function recomputeCapacitiesFresh(s: GameState, capMult: number): Record<string, number> {
  const base = emptyCapacities();
  const caps: Record<string, number> = {};
  for (const r of Object.keys(base)) {
    let cap = (base[r] || 50) * capMult;
    for (const sys of SYSTEMS) {
      const count = s.ownedSystems[sys.id] || 0;
      if (!count || !sys.capacityBoost) continue;
      const boost = sys.capacityBoost[r];
      if (boost) cap += (boost as number) * count * capMult;
    }
    caps[r] = cap;
  }
  return caps;
}

// Export helper for components to compute whether an action is capped
export function isActionCapped(
  produces: Record<string, number>,
  resources: Record<string, number>,
  capacities: Record<string, number>
): boolean {
  const outputs = Object.entries(produces);
  if (outputs.length === 0) return false;
  return outputs.every(([r]) => {
    const cap = capacities[r] || 0;
    return (resources[r] || 0) >= cap - 0.001;
  });
}

// Export helper for whether a system is currently capped (idling)
export function isSystemCapped(
  sysId: string,
  resources: Record<string, number>,
  capacities: Record<string, number>
): boolean {
  const sys = SYSTEM_MAP[sysId];
  if (!sys) return false;
  const produces = Object.keys(sys.produces);
  if (produces.length === 0) return false;
  return produces.every((r) => {
    const cap = capacities[r] || 0;
    return (resources[r] || 0) >= cap - 0.01;
  });
}

// Export for components
export { STAGES, STAGE_IDS, SYSTEMS, TECHS, UPGRADES, ARCHETYPE_MAP };
