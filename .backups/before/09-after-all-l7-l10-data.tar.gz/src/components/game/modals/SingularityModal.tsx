"use client";

import { useGameStore } from "@/game/state/store";
import {
  RELIC_LOADOUTS,
  LOGIC_CORES,
  MAX_INSTALLED_LOGIC_CORES,
} from "@/game/data/singularity";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Gem, CheckCircle2, Cpu } from "lucide-react";
import { cn } from "@/lib/utils";

export function SingularityModal() {
  const showSingularity = useGameStore((s) => s.showSingularity);
  const setShowSingularity = useGameStore((s) => s.setShowSingularity);
  const activeRelicLoadout = useGameStore((s) => s.activeRelicLoadout);
  const activeLogicCores = useGameStore((s) => s.activeLogicCores || {});
  const bindRelicLoadout = useGameStore((s) => s.bindRelicLoadout);
  const toggleLogicCore = useGameStore((s) => s.toggleLogicCore);

  const installedCount = Object.keys(activeLogicCores).filter((k) => activeLogicCores[k]).length;

  return (
    <Dialog open={showSingularity} onOpenChange={setShowSingularity}>
      <DialogContent className="max-w-3xl max-h-[88vh] overflow-y-auto glass-strong">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Gem className="w-5 h-5 text-fuchsia-400" />
            Singularity
          </DialogTitle>
          <DialogDescription>
            Equip one Relic Loadout for its upside / downside / special triple,
            and install up to {MAX_INSTALLED_LOGIC_CORES} Logic Cores for automation and passive bonuses.
          </DialogDescription>
        </DialogHeader>

        {/* Relic Loadouts */}
        <div className="space-y-1.5">
          <div className="text-[0.7rem] uppercase tracking-wide text-foreground/70 flex items-center gap-1.5">
            <Gem className="w-3 h-3" /> Relic Loadouts (one equipped at a time)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {RELIC_LOADOUTS.map((r) => {
              const equipped = activeRelicLoadout === r.id;
              return (
                <div
                  key={r.id}
                  className={cn(
                    "stat-card transition-all",
                    equipped && "border-fuchsia-400/60 ring-1 ring-fuchsia-400/40"
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{r.icon}</span>
                    <span className="text-sm font-semibold truncate">{r.name}</span>
                    {equipped && (
                      <Badge variant="outline" className="text-[0.6rem] ml-auto text-fuchsia-300 border-fuchsia-500/40">
                        Equipped
                      </Badge>
                    )}
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{r.desc}</p>
                  <div className="flex justify-end">
                    <Button
                      size="sm"
                      variant={equipped ? "destructive" : "default"}
                      className="h-7"
                      onClick={() => bindRelicLoadout(equipped ? null : r.id)}
                    >
                      {equipped ? "Unequip" : "Equip"}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Logic Cores */}
        <div className="space-y-1.5">
          <div className="text-[0.7rem] uppercase tracking-wide text-foreground/70 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Cpu className="w-3 h-3" /> Logic Cores
            </span>
            <span className="font-mono text-foreground/60">
              {installedCount}/{MAX_INSTALLED_LOGIC_CORES} installed
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {LOGIC_CORES.map((c) => {
              const installed = !!activeLogicCores[c.id];
              return (
                <div
                  key={c.id}
                  className={cn(
                    "stat-card transition-all",
                    installed && "border-cyan-400/60 ring-1 ring-cyan-400/30"
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{c.icon}</span>
                    <span className="text-sm font-semibold truncate">{c.name}</span>
                    {installed && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 ml-auto" />
                    )}
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{c.desc}</p>
                  <div className="flex justify-end">
                    <Button
                      size="sm"
                      variant={installed ? "destructive" : "default"}
                      className="h-7"
                      onClick={() => toggleLogicCore(c.id)}
                    >
                      {installed ? "Uninstall" : "Install"}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <Button variant="outline" onClick={() => setShowSingularity(false)}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
