"use client";

import { useGameStore } from "@/game/state/store";
import {
  ROUTES,
  FORESIGHT_NODES,
  FORESIGHT_NODE_MAP,
  ADVANCE_NODE_COUNT,
  FORESIGHT_NODE_COUNT,
} from "@/game/data/foresight";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Eye, Sparkles, Lock, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ForesightCategory } from "@/game/data/foresight";

const CATEGORY_LABELS: Record<ForesightCategory, string> = {
  route: "Route",
  pressure: "Pressure",
  conflict: "Conflict",
  continuity: "Continuity",
  solar: "Solar",
  synergy: "Synergy",
};

export function EnlightenmentModal() {
  const showEnlightenment = useGameStore((s) => s.showEnlightenment);
  const setShowEnlightenment = useGameStore((s) => s.setShowEnlightenment);
  const divinity = useGameStore((s) => s.resources.divinity || 0);
  const selectedRoute = useGameStore((s) => s.selectedRoute);
  const foresightNodes = useGameStore((s) => s.foresightNodes || {});
  const selectRoute = useGameStore((s) => s.selectRoute);
  const purchaseForesightNode = useGameStore((s) => s.purchaseForesightNode);

  const purchasedCount = Object.keys(foresightNodes).filter((k) => foresightNodes[k]).length;
  const advanceProgress = Math.min(ADVANCE_NODE_COUNT, purchasedCount);

  return (
    <Dialog open={showEnlightenment} onOpenChange={setShowEnlightenment}>
      <DialogContent className="max-w-4xl max-h-[88vh] overflow-y-auto glass-strong">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Eye className="w-5 h-5 text-cyan-400" />
            Enlightenment — Foresight
          </DialogTitle>
          <DialogDescription>
            Pick a Route to bind this run&rsquo;s destiny, then spend Divinity on the 20-node Foresight tree.
            Buy {ADVANCE_NODE_COUNT} of {FORESIGHT_NODE_COUNT} nodes to advance to Transcendence.
          </DialogDescription>
        </DialogHeader>

        {/* Divinity balance + advancement progress */}
        <div className="rounded-lg border border-border bg-muted/30 p-3 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground uppercase tracking-wide">Divinity</span>
            <span className="font-mono font-bold tabular-nums text-violet-300">
              {divinity.toFixed(2)} ✨
            </span>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground uppercase tracking-wide">Advancement</span>
            <span className="font-mono font-bold tabular-nums">
              {purchasedCount}/{ADVANCE_NODE_COUNT} to advance
            </span>
          </div>
          <Progress value={(advanceProgress / ADVANCE_NODE_COUNT) * 100} className="h-2" />
        </div>

        {/* Routes */}
        <div className="space-y-2">
          <div className="text-xs uppercase tracking-wide text-muted-foreground">Routes (pick one per run)</div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {ROUTES.map((route) => (
              <button
                key={route.id}
                onClick={() => selectRoute(selectedRoute === route.id ? null : route.id)}
                className={cn(
                  "stat-card text-left transition-all hover:scale-[1.01]",
                  selectedRoute === route.id && "border-cyan-400/60 ring-1 ring-cyan-400/40"
                )}
              >
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-lg">{route.icon}</span>
                  <span className="text-sm font-semibold">{route.name}</span>
                  {selectedRoute === route.id && (
                    <CheckCircle2 className="w-3 h-3 text-cyan-400 ml-auto" />
                  )}
                </div>
                <p className="text-[0.7rem] text-muted-foreground leading-snug">{route.desc}</p>
                <div className="mt-1 text-[0.65rem] text-cyan-300 font-mono">
                  +{Math.round(route.bonus.value * 100)}% {route.bonus.type}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Foresight tree — grouped by category */}
        <div className="space-y-3">
          <div className="text-xs uppercase tracking-wide text-muted-foreground">Foresight Tree</div>
          {(Object.keys(CATEGORY_LABELS) as ForesightCategory[]).map((cat) => {
            const nodes = FORESIGHT_NODES.filter((n) => n.category === cat);
            if (nodes.length === 0) return null;
            return (
              <div key={cat} className="space-y-1.5">
                <div className="text-[0.7rem] uppercase tracking-wide text-foreground/70">{CATEGORY_LABELS[cat]}</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {nodes.map((node) => {
                    const purchased = !!foresightNodes[node.id];
                    const prereqMet = !node.requires || node.requires.every((r) => foresightNodes[r]);
                    const canAfford = divinity >= node.cost;
                    const blocked = !purchased && (!prereqMet || !canAfford);
                    return (
                      <div
                        key={node.id}
                        className={cn(
                          "stat-card transition-all",
                          purchased && "border-emerald-500/60 ring-1 ring-emerald-500/30",
                          blocked && !purchased && "opacity-60"
                        )}
                      >
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <div className="min-w-0">
                            <div className="text-sm font-semibold truncate">{node.name}</div>
                            {node.bonus && (
                              <Badge
                                variant="outline"
                                className="text-[0.6rem] text-violet-300 border-violet-500/40 mt-0.5"
                              >
                                <Sparkles className="w-2.5 h-2.5 mr-0.5" />
                                +{Math.round(node.bonus.value * 100)}% {node.bonus.type}
                              </Badge>
                            )}
                          </div>
                          {purchased ? (
                            <Badge variant="outline" className="text-[0.6rem] text-emerald-300 border-emerald-500/40">
                              <CheckCircle2 className="w-2.5 h-2.5 mr-0.5" /> Owned
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-[0.6rem] text-amber-300 border-amber-500/40">
                              {node.cost} ✨
                            </Badge>
                          )}
                        </div>
                        <p className="text-[0.7rem] text-muted-foreground leading-snug mb-1.5">{node.desc}</p>
                        {node.requires && node.requires.length > 0 && (
                          <div className="text-[0.65rem] text-muted-foreground mb-1.5">
                            Requires:{" "}
                            {node.requires.map((req, i) => {
                              const r = FORESIGHT_NODE_MAP[req];
                              const met = !!foresightNodes[req];
                              return (
                                <span key={req}>
                                  <span
                                    className={cn(
                                      "font-mono",
                                      met ? "text-emerald-300" : "text-red-300"
                                    )}
                                  >
                                    {r?.name || req}
                                  </span>
                                  {i < node.requires!.length - 1 && <span>, </span>}
                                </span>
                              );
                            })}
                          </div>
                        )}
                        {!purchased && (
                          <div className="flex justify-end">
                            <Button
                              size="sm"
                              className="h-7"
                              disabled={blocked}
                              onClick={() => purchaseForesightNode(node.id)}
                              title={
                                !prereqMet
                                  ? "Prerequisites not met"
                                  : !canAfford
                                    ? "Not enough Divinity"
                                    : "Purchase node"
                              }
                            >
                              {!prereqMet ? (
                                <>
                                  <Lock className="w-3 h-3 mr-1" /> Locked
                                </>
                              ) : (
                                "Purchase"
                              )}
                            </Button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex justify-end pt-2">
          <Button variant="outline" onClick={() => setShowEnlightenment(false)}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
