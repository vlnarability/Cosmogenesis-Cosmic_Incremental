"use client";

import { useState } from "react";
import { useGameStore } from "@/game/state/store";
import {
  OFFERINGS,
  RITUALS,
  SCRIPTS,
  BLOOD_PACTS,
} from "@/game/data/transcendence";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Ghost, CheckCircle2, Lock, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

type SubTab = "offerings" | "rituals" | "scripts" | "bloodPact";

export function TranscendenceModal() {
  const showTranscendence = useGameStore((s) => s.showTranscendence);
  const setShowTranscendence = useGameStore((s) => s.setShowTranscendence);
  const divinity = useGameStore((s) => s.resources.divinity || 0);
  const offeringsUsedThisRun = useGameStore((s) => s.offeringsUsedThisRun || {});
  const ritualUsesThisRun = useGameStore((s) => s.ritualUsesThisRun || {});
  const activeScripts = useGameStore((s) => s.activeScripts || {});
  const bloodPactUsesThisRun = useGameStore((s) => s.bloodPactUsesThisRun || {});
  const activeRituals = useGameStore((s) => s.activeRituals || []);
  const makeOffering = useGameStore((s) => s.makeOffering);
  const performRitual = useGameStore((s) => s.performRitual);
  const toggleScript = useGameStore((s) => s.toggleScript);
  const performBloodPact = useGameStore((s) => s.performBloodPact);

  const [tab, setTab] = useState<SubTab>("offerings");

  const ritualTimers: Record<string, number> = {};
  for (const r of activeRituals) ritualTimers[r.id] = r.remaining;

  return (
    <Dialog open={showTranscendence} onOpenChange={setShowTranscendence}>
      <DialogContent className="max-w-3xl max-h-[88vh] overflow-y-auto glass-strong">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Ghost className="w-5 h-5 text-rose-400" />
            Transcendence
          </DialogTitle>
          <DialogDescription>
            Pour worldly resources into Divinity via Offerings, perform one-time Rituals,
            toggle Scripts for automation, and pay the dark price of a Blood Pact.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center justify-between rounded-lg border border-border bg-muted/30 px-3 py-2">
          <span className="text-xs text-muted-foreground uppercase tracking-wide">Divinity</span>
          <span className="font-mono font-bold tabular-nums text-violet-300">
            {divinity.toFixed(2)} ✨
          </span>
        </div>

        {/* Sub-tab buttons */}
        <div className="flex gap-1 border-b border-border pb-2">
          {(["offerings", "rituals", "scripts", "bloodPact"] as SubTab[]).map((t) => (
            <Button
              key={t}
              size="sm"
              variant={tab === t ? "default" : "ghost"}
              className="h-7 capitalize"
              onClick={() => setTab(t)}
            >
              {t === "bloodPact" ? "Blood Pact" : t}
            </Button>
          ))}
        </div>

        {/* Offerings */}
        {tab === "offerings" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {OFFERINGS.map((o) => {
              const uses = offeringsUsedThisRun[o.id] || 0;
              return (
                <div key={o.id} className="stat-card">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{o.icon}</span>
                    <span className="text-sm font-semibold truncate">{o.name}</span>
                    <Badge variant="outline" className="text-[0.6rem] ml-auto text-violet-300 border-violet-500/40">
                      +{o.divinityGain} ✨
                    </Badge>
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{o.desc}</p>
                  <div className="flex items-center justify-between text-[0.65rem]">
                    <span className="text-amber-300 font-mono">
                      Cost: {o.cost.amount} {o.cost.resource}
                    </span>
                    <span className="text-muted-foreground">Used {uses}× this run</span>
                  </div>
                  <div className="flex justify-end mt-2">
                    <Button size="sm" className="h-7" onClick={() => makeOffering(o.id)}>
                      Offer
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Rituals */}
        {tab === "rituals" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {RITUALS.map((r) => {
              const used = !!ritualUsesThisRun[r.id];
              const timer = ritualTimers[r.id] || 0;
              const isPermanent = r.duration === undefined;
              const isActive = isPermanent ? used : timer > 0;
              const canAfford = divinity >= r.cost;
              return (
                <div
                  key={r.id}
                  className={cn(
                    "stat-card transition-all",
                    used && isPermanent && "border-emerald-500/60 ring-1 ring-emerald-500/30",
                    isActive && !isPermanent && "border-cyan-400/60 ring-1 ring-cyan-400/30"
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{r.icon}</span>
                    <span className="text-sm font-semibold truncate">{r.name}</span>
                    <Badge variant="outline" className="text-[0.6rem] ml-auto text-amber-300 border-amber-500/40">
                      {r.cost} ✨
                    </Badge>
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{r.desc}</p>
                  <div className="flex items-center justify-between text-[0.65rem] mb-2">
                    <span className="text-muted-foreground">
                      {isPermanent ? "Permanent for run" : `${r.duration}s duration`}
                    </span>
                    {!isPermanent && isActive && (
                      <span className="text-cyan-300 font-mono">{Math.ceil(timer)}s left</span>
                    )}
                    {used && (
                      <Badge variant="outline" className="text-[0.6rem] text-emerald-300 border-emerald-500/40">
                        <CheckCircle2 className="w-2.5 h-2.5 mr-0.5" /> Performed
                      </Badge>
                    )}
                  </div>
                  <div className="flex justify-end">
                    {used ? (
                      <Badge variant="outline" className="text-[0.65rem] text-muted-foreground">
                        Already performed
                      </Badge>
                    ) : (
                      <Button
                        size="sm"
                        className="h-7"
                        disabled={!canAfford}
                        onClick={() => performRitual(r.id)}
                        title={canAfford ? "Perform ritual" : "Not enough Divinity"}
                      >
                        Perform
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Scripts */}
        {tab === "scripts" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {SCRIPTS.map((s) => {
              const active = !!activeScripts[s.id];
              return (
                <div
                  key={s.id}
                  className={cn(
                    "stat-card transition-all",
                    active && "border-cyan-400/60 ring-1 ring-cyan-400/30"
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{s.icon}</span>
                    <span className="text-sm font-semibold truncate">{s.name}</span>
                    {active && (
                      <Badge variant="outline" className="text-[0.6rem] ml-auto text-cyan-300 border-cyan-500/40">
                        Active
                      </Badge>
                    )}
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{s.desc}</p>
                  <div className="flex justify-end">
                    <Button
                      size="sm"
                      variant={active ? "destructive" : "default"}
                      className="h-7"
                      onClick={() => toggleScript(s.id)}
                    >
                      {active ? "Disable" : "Enable"}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Blood Pact */}
        {tab === "bloodPact" && (
          <div className="space-y-2">
            <div className="rounded-lg border border-rose-500/40 bg-rose-500/10 p-2 text-[0.7rem] text-rose-200 flex items-center gap-1.5">
              <Zap className="w-3 h-3" />
              <span>Dark path — sacrifices population for instant Divinity. Per-run limits shown per tier.</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {BLOOD_PACTS.map((p) => {
                const uses = bloodPactUsesThisRun[p.id] || 0;
                const atLimit = uses >= p.limitPerRun;
                return (
                  <div key={p.id} className="stat-card">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-lg">{p.icon}</span>
                      <span className="text-sm font-semibold truncate">{p.name}</span>
                      <Badge variant="outline" className="text-[0.6rem] ml-auto text-violet-300 border-violet-500/40">
                        +{p.divinityGain} ✨
                      </Badge>
                    </div>
                    <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{p.desc}</p>
                    <div className="text-[0.65rem] space-y-0.5 mb-2">
                      <div className="text-rose-300">
                        Pop cost: {p.populationCost !== undefined
                          ? `${p.populationCost} flat`
                          : `${Math.round((p.populationFraction || 0) * 100)}% of pop`}
                      </div>
                      <div className="text-amber-300">Happiness: {p.happinessCost}</div>
                      <div className="text-muted-foreground">
                        Used {uses}/{p.limitPerRun} this run
                      </div>
                    </div>
                    <div className="flex justify-end">
                      <Button
                        size="sm"
                        variant="destructive"
                        className="h-7"
                        disabled={atLimit}
                        onClick={() => performBloodPact(p.id)}
                      >
                        {atLimit ? (
                          <>
                            <Lock className="w-3 h-3 mr-1" /> At limit
                          </>
                        ) : (
                          "Sacrifice"
                        )}
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <div className="flex justify-end pt-2">
          <Button variant="outline" onClick={() => setShowTranscendence(false)}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
