"use client";

import { useState } from "react";
import { useGameStore } from "@/game/state/store";
import {
  DIVINE_LAWS,
  WORSHIP_MODES,
  MIRACLES,
  HERESY_RESPONSES,
  HERESY_MAX,
  APOTHEOSIS_COMPLETION_LAWS_REQUIRED,
} from "@/game/data/apotheosis";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Scroll, CheckCircle2, Lock } from "lucide-react";
import { cn } from "@/lib/utils";

type SubTab = "laws" | "worship" | "miracles" | "heresy";

export function ApotheosisModal() {
  const showApotheosis = useGameStore((s) => s.showApotheosis);
  const setShowApotheosis = useGameStore((s) => s.setShowApotheosis);
  const divinity = useGameStore((s) => s.resources.divinity || 0);
  const divineLawsEnactedThisRun = useGameStore((s) => s.divineLawsEnactedThisRun || {});
  const worshipMode = useGameStore((s) => s.worshipMode);
  const miracleUsesThisRun = useGameStore((s) => s.miracleUsesThisRun || {});
  const heresyLevel = useGameStore((s) => s.heresyLevel || 0);
  const heresyResponseUsesThisRun = useGameStore((s) => s.heresyResponseUsesThisRun || {});

  const enactDivineLaw = useGameStore((s) => s.enactDivineLaw);
  const setWorshipMode = useGameStore((s) => s.setWorshipMode);
  const performMiracle = useGameStore((s) => s.performMiracle);
  const respondToHeresy = useGameStore((s) => s.respondToHeresy);

  const [tab, setTab] = useState<SubTab>("laws");

  const lawsCount = Object.keys(divineLawsEnactedThisRun).filter((k) => divineLawsEnactedThisRun[k]).length;

  return (
    <Dialog open={showApotheosis} onOpenChange={setShowApotheosis}>
      <DialogContent className="max-w-3xl max-h-[88vh] overflow-y-auto glass-strong">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Scroll className="w-5 h-5 text-amber-400" />
            Apotheosis
          </DialogTitle>
          <DialogDescription>
            Codify Divine Laws, choose a Worship Mode, perform Miracles, and manage Heresy.
            Codify {APOTHEOSIS_COMPLETION_LAWS_REQUIRED} laws and resolve a schism to ascend to Singularity.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center justify-between rounded-lg border border-border bg-muted/30 px-3 py-2">
          <span className="text-xs text-muted-foreground uppercase tracking-wide">Divinity</span>
          <span className="font-mono font-bold tabular-nums text-violet-300">
            {divinity.toFixed(2)} ✨
          </span>
        </div>

        {/* Heresy meter — always visible */}
        <div className="rounded-lg border border-rose-500/40 bg-rose-500/5 p-2.5 space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-rose-200 uppercase tracking-wide">Heresy</span>
            <span className="font-mono font-bold tabular-nums text-rose-300">
              {heresyLevel.toFixed(1)} / {HERESY_MAX}
            </span>
          </div>
          <Progress value={(heresyLevel / HERESY_MAX) * 100} className="h-1.5" />
        </div>

        {/* Sub-tab buttons */}
        <div className="flex gap-1 border-b border-border pb-2 flex-wrap">
          {(["laws", "worship", "miracles", "heresy"] as SubTab[]).map((t) => (
            <Button
              key={t}
              size="sm"
              variant={tab === t ? "default" : "ghost"}
              className="h-7 capitalize"
              onClick={() => setTab(t)}
            >
              {t === "laws" ? `Divine Laws (${lawsCount})` : t}
            </Button>
          ))}
        </div>

        {/* Divine Laws */}
        {tab === "laws" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {DIVINE_LAWS.map((law) => {
              const codified = !!divineLawsEnactedThisRun[law.id];
              const canAfford = divinity >= law.cost;
              return (
                <div
                  key={law.id}
                  className={cn(
                    "stat-card transition-all",
                    codified && "border-emerald-500/60 ring-1 ring-emerald-500/30"
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{law.icon}</span>
                    <span className="text-sm font-semibold truncate">{law.name}</span>
                    <Badge variant="outline" className="text-[0.6rem] ml-auto text-amber-300 border-amber-500/40">
                      {law.cost} ✨
                    </Badge>
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{law.desc}</p>
                  <div className="flex justify-end">
                    {codified ? (
                      <Badge variant="outline" className="text-[0.65rem] text-emerald-300 border-emerald-500/40">
                        <CheckCircle2 className="w-2.5 h-2.5 mr-0.5" /> Codified
                      </Badge>
                    ) : (
                      <Button
                        size="sm"
                        className="h-7"
                        disabled={!canAfford}
                        onClick={() => enactDivineLaw(law.id)}
                      >
                        Codify
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Worship Modes */}
        {tab === "worship" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {WORSHIP_MODES.map((m) => {
              const active = worshipMode === m.id;
              return (
                <div
                  key={m.id}
                  className={cn(
                    "stat-card transition-all",
                    active && "border-amber-400/60 ring-1 ring-amber-400/40"
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{m.icon}</span>
                    <span className="text-sm font-semibold truncate">{m.name}</span>
                    {active && (
                      <Badge variant="outline" className="text-[0.6rem] ml-auto text-amber-300 border-amber-500/40">
                        Active
                      </Badge>
                    )}
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{m.desc}</p>
                  <div className="flex justify-end">
                    <Button
                      size="sm"
                      variant={active ? "destructive" : "default"}
                      className="h-7"
                      onClick={() => setWorshipMode(active ? null : m.id)}
                    >
                      {active ? "Clear" : "Choose"}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Miracles */}
        {tab === "miracles" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {MIRACLES.map((mir) => {
              const uses = miracleUsesThisRun[mir.id] || 0;
              const atLimit = uses >= mir.limitPerRun;
              const canAfford = divinity >= mir.cost;
              return (
                <div key={mir.id} className="stat-card">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{mir.icon}</span>
                    <span className="text-sm font-semibold truncate">{mir.name}</span>
                    <Badge variant="outline" className="text-[0.6rem] ml-auto text-amber-300 border-amber-500/40">
                      {mir.cost} ✨
                    </Badge>
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{mir.desc}</p>
                  <div className="flex items-center justify-between text-[0.65rem]">
                    <span className="text-muted-foreground">
                      Used {uses}/{mir.limitPerRun} this run
                    </span>
                    <Button
                      size="sm"
                      className="h-7"
                      disabled={atLimit || !canAfford}
                      onClick={() => performMiracle(mir.id)}
                    >
                      {atLimit ? (
                        <>
                          <Lock className="w-3 h-3 mr-1" /> At limit
                        </>
                      ) : (
                        "Invoke"
                      )}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Heresy responses */}
        {tab === "heresy" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {HERESY_RESPONSES.map((r) => {
              const uses = heresyResponseUsesThisRun[r.id] || 0;
              const atLimit = uses >= r.limitPerRun;
              const canAfford = divinity >= r.cost;
              return (
                <div key={r.id} className="stat-card">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{r.icon}</span>
                    <span className="text-sm font-semibold truncate">{r.name}</span>
                    {r.cost > 0 && (
                      <Badge variant="outline" className="text-[0.6rem] ml-auto text-amber-300 border-amber-500/40">
                        {r.cost} ✨
                      </Badge>
                    )}
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{r.desc}</p>
                  <div className="flex items-center justify-between text-[0.65rem]">
                    <span className="text-muted-foreground">
                      Used {uses}/{r.limitPerRun === Infinity ? "∞" : r.limitPerRun}
                    </span>
                    <Button
                      size="sm"
                      variant={r.id === "inquisition" ? "destructive" : "default"}
                      className="h-7"
                      disabled={atLimit || !canAfford}
                      onClick={() => respondToHeresy(r.id)}
                    >
                      {atLimit ? "At limit" : "Respond"}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="flex justify-end pt-2">
          <Button variant="outline" onClick={() => setShowApotheosis(false)}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
