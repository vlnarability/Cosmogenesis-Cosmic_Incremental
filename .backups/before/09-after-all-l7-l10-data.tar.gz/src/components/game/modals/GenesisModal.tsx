"use client";

import { useGameStore } from "@/game/state/store";
import {
  CRADLE_WORLDS,
  PRIME_CONDITIONS,
  SACRED_GEOGRAPHIES,
  DORMANT_SEEDS,
  DIFFICULTY_TIERS,
  type WorldConfig,
} from "@/game/data/genesis";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Globe, CheckCircle2, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

export function GenesisModal() {
  const showGenesis = useGameStore((s) => s.showGenesis);
  const setShowGenesis = useGameStore((s) => s.setShowGenesis);
  const worldConfig = useGameStore((s) => s.worldConfig);
  const setWorldConfig = useGameStore((s) => s.setWorldConfig);
  const clearWorldConfig = useGameStore((s) => s.clearWorldConfig);

  const cfg: WorldConfig = worldConfig || {
    cradleWorld: "",
    primeCondition: "",
    sacredGeography: "",
    dormantSeed: "",
    difficulty: "",
  };

  function update<K extends keyof WorldConfig>(key: K, value: string) {
    const next: WorldConfig = { ...cfg, [key]: value };
    setWorldConfig(next);
  }

  const allSet =
    !!cfg.cradleWorld &&
    !!cfg.primeCondition &&
    !!cfg.sacredGeography &&
    !!cfg.dormantSeed &&
    !!cfg.difficulty;

  return (
    <Dialog open={showGenesis} onOpenChange={setShowGenesis}>
      <DialogContent className="max-w-4xl max-h-[88vh] overflow-y-auto glass-strong">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Globe className="w-5 h-5 text-emerald-400" />
            Genesis — Author a Cradle World
          </DialogTitle>
          <DialogDescription>
            Compose the conditions under which the next universe will wake.
            All five facets must be set before the world can be authored.
          </DialogDescription>
        </DialogHeader>

        {/* Current config summary */}
        <div className="rounded-lg border border-border bg-muted/30 p-3 space-y-1.5">
          <div className="text-xs uppercase tracking-wide text-muted-foreground">Current Authoring</div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 text-[0.7rem]">
            <ConfigChip label="Cradle" value={cfg.cradleWorld} />
            <ConfigChip label="Prime" value={cfg.primeCondition} />
            <ConfigChip label="Geography" value={cfg.sacredGeography} />
            <ConfigChip label="Seed" value={cfg.dormantSeed} />
            <ConfigChip label="Difficulty" value={cfg.difficulty} />
          </div>
        </div>

        {/* Sections */}
        <Section title="Cradle World" items={CRADLE_WORLDS.map((c) => ({
          id: c.id, name: c.name, icon: c.icon, desc: c.desc,
          selected: cfg.cradleWorld === c.id, onSelect: () => update("cradleWorld", c.id),
        }))} />

        <Section title="Prime Condition" items={PRIME_CONDITIONS.map((c) => ({
          id: c.id, name: c.name, icon: c.icon, desc: c.desc,
          selected: cfg.primeCondition === c.id, onSelect: () => update("primeCondition", c.id),
        }))} />

        <Section title="Sacred Geography" items={SACRED_GEOGRAPHIES.map((c) => ({
          id: c.id, name: c.name, icon: c.icon, desc: c.desc,
          selected: cfg.sacredGeography === c.id, onSelect: () => update("sacredGeography", c.id),
        }))} />

        <Section title="Dormant Seed" items={DORMANT_SEEDS.map((c) => ({
          id: c.id, name: c.name, icon: c.icon, desc: c.desc,
          selected: cfg.dormantSeed === c.id, onSelect: () => update("dormantSeed", c.id),
        }))} />

        <Section title="Difficulty Tier" items={DIFFICULTY_TIERS.map((c) => ({
          id: c.id, name: c.name, icon: c.icon, desc: c.desc,
          selected: cfg.difficulty === c.id, onSelect: () => update("difficulty", c.id),
          extra: `EP ×${c.epMultiplier}`,
        }))} />

        {/* Action buttons */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-border">
          {worldConfig && (
            <Button variant="ghost" size="sm" className="h-7" onClick={clearWorldConfig}>
              Clear
            </Button>
          )}
          <div className="ml-auto flex items-center gap-2">
            {allSet && (
              <Badge variant="outline" className="text-[0.65rem] text-emerald-300 border-emerald-500/40">
                <CheckCircle2 className="w-2.5 h-2.5 mr-0.5" /> Ready to author
              </Badge>
            )}
            <Button variant="outline" onClick={() => setShowGenesis(false)}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ConfigChip({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded border border-border/60 bg-muted/20 px-1.5 py-1">
      <div className="text-[0.6rem] uppercase text-muted-foreground">{label}</div>
      <div className={cn("font-mono text-[0.7rem]", value ? "text-foreground" : "text-muted-foreground italic")}>
        {value || "—"}
      </div>
    </div>
  );
}

function Section({
  title,
  items,
}: {
  title: string;
  items: Array<{
    id: string;
    name: string;
    icon: string;
    desc: string;
    selected: boolean;
    onSelect: () => void;
    extra?: string;
  }>;
}) {
  return (
    <div className="space-y-1.5">
      <div className="text-[0.7rem] uppercase tracking-wide text-foreground/70">{title}</div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {items.map((item) => (
          <button
            key={item.id}
            onClick={item.onSelect}
            className={cn(
              "stat-card text-left transition-all hover:scale-[1.01]",
              item.selected && "border-emerald-400/60 ring-1 ring-emerald-400/40"
            )}
          >
            <div className="flex items-center gap-2 mb-1">
              <span className="text-lg">{item.icon}</span>
              <span className="text-sm font-semibold truncate">{item.name}</span>
              {item.selected && (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 ml-auto" />
              )}
            </div>
            <p className="text-[0.7rem] text-muted-foreground leading-snug">{item.desc}</p>
            {item.extra && (
              <div className="mt-1 text-[0.65rem] text-cyan-300 font-mono flex items-center gap-0.5">
                <Sparkles className="w-2.5 h-2.5" /> {item.extra}
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
