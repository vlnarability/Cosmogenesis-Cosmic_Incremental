"use client";

import { useGameStore } from "@/game/state/store";
import { PRESTIGE_LAYERS, type PrestigeLayerDef } from "@/game/data/prestigeLayers";
import { CHALLENGES } from "@/game/data/challenges";
import { FORESIGHT_NODES, ADVANCE_NODE_COUNT } from "@/game/data/foresight";
import { RITUALS, SCRIPTS, BLOOD_PACTS } from "@/game/data/transcendence";
import { CRADLE_WORLDS, DORMANT_SEEDS } from "@/game/data/genesis";
import { DIVINE_LAWS, WORSHIP_MODES, MIRACLES } from "@/game/data/apotheosis";
import { RELIC_LOADOUTS, LOGIC_CORES } from "@/game/data/singularity";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Crown,
  Eye,
  Ghost,
  Globe,
  Scroll,
  Gem,
  Lock,
  CheckCircle2,
  Circle,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";

const ADVANCE_THRESHOLD = 3;

type LayerStatus = "locked" | "inProgress" | "complete" | "available" | "planned";

interface LayerViewProps {
  layer: PrestigeLayerDef;
  status: LayerStatus;
  prevComplete: boolean;
  onOpen: () => void;
  children: React.ReactNode;
}

function LayerView({ layer, status, prevComplete, onOpen, children }: LayerViewProps) {
  const revealName = status !== "locked";
  return (
    <div
      className={cn(
        "relative rounded-lg border p-3 transition-all",
        status === "complete" && "border-emerald-500/40 bg-emerald-500/5",
        status === "inProgress" && "border-amber-500/40 bg-amber-500/5",
        status === "planned" && "border-violet-500/40 bg-violet-500/5",
        status === "locked" && "border-border bg-muted/20 opacity-75"
      )}
    >
      <div className="flex items-start gap-3">
        <div
          className={cn(
            "shrink-0 w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm border",
            status === "complete" && "bg-emerald-500/20 border-emerald-400/60 text-emerald-200",
            status === "inProgress" && "bg-amber-500/20 border-amber-400/60 text-amber-100",
            status === "planned" && "bg-violet-500/20 border-violet-400/60 text-violet-200",
            status === "locked" && "bg-muted/40 border-border text-muted-foreground"
          )}
        >
          {status === "complete" ? (
            <CheckCircle2 className="w-4 h-4" />
          ) : status === "locked" ? (
            <Lock className="w-3.5 h-3.5" />
          ) : (
            layer.order
          )}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <h3 className="text-sm font-bold leading-tight">
              {revealName ? layer.name : "???"}
            </h3>
            {revealName && (
              <Badge variant="outline" className="text-[0.6rem]">
                {layer.currency}
              </Badge>
            )}
            {status === "complete" && (
              <Badge variant="outline" className="text-[0.6rem] text-emerald-300 border-emerald-500/40">
                Complete
              </Badge>
            )}
            {status === "inProgress" && (
              <Badge variant="outline" className="text-[0.6rem] text-amber-200 border-amber-500/40">
                In Progress
              </Badge>
            )}
            {status === "planned" && (
              <Badge variant="outline" className="text-[0.6rem] text-violet-200 border-violet-500/40">
                Revealed
              </Badge>
            )}
          </div>
          {revealName ? (
            <p className="text-xs text-muted-foreground leading-snug italic">{layer.story}</p>
          ) : (
            <p className="text-xs text-muted-foreground italic leading-snug">
              Complete the previous layer to reveal.
            </p>
          )}
          <div className="mt-2 space-y-2">
            {children}
            {status === "locked" && (
              <p className="text-[0.7rem] text-muted-foreground italic">
                {prevComplete ? `Unlock by: ${layer.unlockCondition}` : "Complete the previous layer to reveal."}
              </p>
            )}
            {status !== "locked" && (
              <Button size="sm" variant="outline" className="h-7 gap-1" onClick={onOpen}>
                View {layer.name}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export function PrestigeTab() {
  const galacticWins = useGameStore((s) => s.galacticWins);
  const unlockedChallenges = useGameStore((s) => s.unlockedChallenges);
  const completedChallenges = useGameStore((s) => s.completedChallenges || {});
  const enlightenmentUnlocked = useGameStore((s) => s.enlightenmentUnlocked);
  const foresightNodes = useGameStore((s) => s.foresightNodes || {});
  const transcendenceUnlocked = useGameStore((s) => s.transcendenceUnlocked);
  const ritualsUsedAllTime = useGameStore((s) => s.ritualsUsedAllTime || {});
  const scriptsTriedAllTime = useGameStore((s) => s.scriptsTriedAllTime || {});
  const bloodPactUsedAllTime = useGameStore((s) => s.bloodPactUsedAllTime || false);
  const genesisUnlocked = useGameStore((s) => s.genesisUnlocked);
  const cradleWorldWins = useGameStore((s) => s.cradleWorldWins || {});
  const awakenedSeedsAllTime = useGameStore((s) => s.awakenedSeedsAllTime || {});
  const apotheosisUnlocked = useGameStore((s) => s.apotheosisUnlocked);
  const divineLawsEnactedAllTime = useGameStore((s) => s.divineLawsEnactedAllTime || {});
  const worshipModesUsedAllTime = useGameStore((s) => s.worshipModesUsedAllTime || {});
  const miracleUsesAllTime = useGameStore((s) => s.miracleUsesAllTime || {});
  const heresySurvivedAllTime = useGameStore((s) => s.heresySurvivedAllTime || false);
  const singularityUnlocked = useGameStore((s) => s.singularityUnlocked);
  const relicsBoundAllTime = useGameStore((s) => s.relicsBoundAllTime || {});
  const logicCoresEnabledAllTime = useGameStore((s) => s.logicCoresEnabledAllTime || {});

  const setShowChallenges = useGameStore((s) => s.setShowChallenges);
  const setShowEnlightenment = useGameStore((s) => s.setShowEnlightenment);
  const setShowTranscendence = useGameStore((s) => s.setShowTranscendence);
  const setShowGenesis = useGameStore((s) => s.setShowGenesis);
  const setShowApotheosis = useGameStore((s) => s.setShowApotheosis);
  const setShowSingularity = useGameStore((s) => s.setShowSingularity);

  // Layer 1 progress
  const completedCount = CHALLENGES.filter((c) => completedChallenges[c.id]).length;
  const layer1Complete = completedCount >= ADVANCE_THRESHOLD;

  // Layer 2 progress
  const foresightCount = Object.keys(foresightNodes).filter((k) => foresightNodes[k]).length;
  const layer2Complete = foresightCount >= ADVANCE_NODE_COUNT;

  // Layer 3 progress
  const ritualCategoriesUsed = RITUALS.filter((r) => (ritualsUsedAllTime[r.id] || 0) > 0).length;
  const scriptsTriedCount = Object.keys(scriptsTriedAllTime).filter((k) => scriptsTriedAllTime[k]).length;
  const layer3Complete =
    bloodPactUsedAllTime &&
    ritualCategoriesUsed >= RITUALS.length &&
    scriptsTriedCount >= SCRIPTS.length;

  // Layer 4 progress
  const cradleWorldsWonCount = CRADLE_WORLDS.filter((c) => cradleWorldWins[c.id]).length;
  const seedsAwakenedCount = DORMANT_SEEDS.filter((s) => awakenedSeedsAllTime[s.id]).length;
  const layer4Complete =
    cradleWorldsWonCount >= CRADLE_WORLDS.length &&
    seedsAwakenedCount >= DORMANT_SEEDS.length;

  // Layer 5 progress
  const lawsCodifiedAllTimeCount = Object.keys(divineLawsEnactedAllTime).length;
  const worshipModesTriedCount = Object.keys(worshipModesUsedAllTime).filter((k) => worshipModesUsedAllTime[k]).length;
  const miraclesUsedAllTimeCount = Object.keys(miracleUsesAllTime).length;
  const layer5Complete =
    lawsCodifiedAllTimeCount >= 3 &&
    worshipModesTriedCount >= WORSHIP_MODES.length &&
    miraclesUsedAllTimeCount >= MIRACLES.length &&
    heresySurvivedAllTime;

  // Layer 6 progress (singularity not "complete" without compression — show available)
  const relicsBoundCount = Object.keys(relicsBoundAllTime).filter((k) => relicsBoundAllTime[k]).length;
  const logicCoresEnabledCount = Object.keys(logicCoresEnabledAllTime).filter((k) => logicCoresEnabledAllTime[k]).length;

  // Build status per layer
  function layerStatus(order: number): LayerStatus {
    if (order === 1) {
      return !unlockedChallenges && galacticWins === 0
        ? "locked"
        : layer1Complete
          ? "complete"
          : "inProgress";
    }
    if (order === 2) {
      if (!layer1Complete) return "locked";
      return layer2Complete ? "complete" : enlightenmentUnlocked ? "inProgress" : "available";
    }
    if (order === 3) {
      if (!layer2Complete) return "locked";
      return layer3Complete ? "complete" : transcendenceUnlocked ? "inProgress" : "available";
    }
    if (order === 4) {
      if (!layer3Complete) return "locked";
      return layer4Complete ? "complete" : genesisUnlocked ? "inProgress" : "available";
    }
    if (order === 5) {
      if (!layer4Complete) return "locked";
      return layer5Complete ? "complete" : apotheosisUnlocked ? "inProgress" : "available";
    }
    if (order === 6) {
      if (!layer5Complete) return "locked";
      return singularityUnlocked ? "inProgress" : "available";
    }
    // Future layers (7-10) — locked unless previous complete
    const prev = PRESTIGE_LAYERS.find((l) => l.order === order - 1);
    if (!prev) return "locked";
    // All future layers locked for now (Layer 7+ not yet wired)
    return "locked";
  }

  const layerStatuses: Record<string, LayerStatus> = {};
  for (const layer of PRESTIGE_LAYERS) {
    layerStatuses[layer.id] = layerStatus(layer.order);
  }

  return (
    <div className="space-y-4">
      {/* Divine Awakening — top hero card */}
      <Card className="glass-panel relative overflow-hidden">
        <div
          className="absolute top-0 right-0 w-48 h-48 pointer-events-none"
          style={{
            background:
              "radial-gradient(circle at top right, rgba(192,132,252,0.25), transparent 70%)",
          }}
        />
        <CardHeader className="pb-2 relative">
          <CardTitle className="text-base flex items-center gap-2">
            <Crown className="w-5 h-5 text-violet-300" />
            Divine Awakening
          </CardTitle>
          <CardDescription>
            Ten ascending tiers of godhood — each a self-contained prestige
            reset with its own mechanics, currency, and unlock criteria.
            Master the current layer to reveal what lies beyond.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-center gap-1.5 text-[0.7rem]">
            {PRESTIGE_LAYERS.map((layer, i) => {
              const status = layerStatuses[layer.id];
              const isComplete = status === "complete";
              const isInProgress = status === "inProgress" || status === "available";
              const isLocked = status === "locked";
              const isPlanned = status === "planned";
              return (
                <span key={layer.id} className="flex items-center gap-1.5">
                  <span
                    className={cn(
                      "px-1.5 py-0.5 rounded border font-mono",
                      isComplete && "border-emerald-500/40 bg-emerald-500/10 text-emerald-300",
                      isInProgress && "border-amber-500/40 bg-amber-500/10 text-amber-200",
                      isPlanned && "border-violet-500/40 bg-violet-500/10 text-violet-200",
                      isLocked && "border-border bg-muted/30 text-muted-foreground"
                    )}
                  >
                    {isComplete && "✓ "}
                    {isLocked && "🔒 "}
                    {layer.name}
                  </span>
                  {i < PRESTIGE_LAYERS.length - 1 && (
                    <span className="text-muted-foreground/50">·</span>
                  )}
                </span>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Timeline of layers */}
      <div className="space-y-2">
        {PRESTIGE_LAYERS.map((layer, idx) => {
          const status = layerStatuses[layer.id];
          const prevComplete = idx === 0 ? false : layerStatuses[PRESTIGE_LAYERS[idx - 1].id] === "complete";
          // Layer 1 — challenge progress
          if (layer.order === 1) {
            return (
              <LayerView
                key={layer.id}
                layer={layer}
                status={status}
                prevComplete={prevComplete}
                onOpen={() => setShowChallenges(true)}
              >
                <div>
                  <div className="flex items-center justify-between text-[0.65rem] mb-1">
                    <span className="text-muted-foreground uppercase tracking-wide">
                      {layer.completeState}
                    </span>
                    <span className="font-mono font-bold tabular-nums">
                      {completedCount}/{ADVANCE_THRESHOLD}
                    </span>
                  </div>
                  <Progress
                    value={(Math.min(completedCount, ADVANCE_THRESHOLD) / ADVANCE_THRESHOLD) * 100}
                    className="h-1.5"
                  />
                </div>
                {status === "locked" && (
                  <p className="text-[0.7rem] text-muted-foreground flex items-center gap-1.5">
                    <Lock className="w-3 h-3" /> Reach the Galactic stage once to unlock Challenges.
                  </p>
                )}
              </LayerView>
            );
          }
          // Layer 2 — foresight count
          if (layer.order === 2) {
            return (
              <LayerView
                key={layer.id}
                layer={layer}
                status={status}
                prevComplete={prevComplete}
                onOpen={() => setShowEnlightenment(true)}
              >
                {status !== "locked" && (
                  <>
                    <div>
                      <div className="flex items-center justify-between text-[0.65rem] mb-1">
                        <span className="text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                          <Eye className="w-3 h-3" /> {layer.completeState}
                        </span>
                        <span className="font-mono font-bold tabular-nums">
                          {foresightCount}/{ADVANCE_NODE_COUNT}
                        </span>
                      </div>
                      <Progress
                        value={(Math.min(foresightCount, ADVANCE_NODE_COUNT) / ADVANCE_NODE_COUNT) * 100}
                        className="h-1.5"
                      />
                    </div>
                    <div className="flex items-start gap-1.5 text-[0.7rem]">
                      <Sparkles className="w-2.5 h-2.5 text-violet-300 mt-1 shrink-0" />
                      <span className="text-muted-foreground">
                        <span className="text-foreground/80">Reward:</span> {layer.persistentReward}
                      </span>
                    </div>
                  </>
                )}
              </LayerView>
            );
          }
          // Layer 3 — rituals / scripts / blood pact
          if (layer.order === 3) {
            return (
              <LayerView
                key={layer.id}
                layer={layer}
                status={status}
                prevComplete={prevComplete}
                onOpen={() => setShowTranscendence(true)}
              >
                {status !== "locked" && (
                  <div className="space-y-1 text-[0.7rem]">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground flex items-center gap-1">
                        <Ghost className="w-3 h-3" /> Rituals performed (all-time)
                      </span>
                      <span className="font-mono font-bold tabular-nums">
                        {ritualCategoriesUsed}/{RITUALS.length}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Scripts tried (all-time)</span>
                      <span className="font-mono font-bold tabular-nums">
                        {scriptsTriedCount}/{SCRIPTS.length}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Blood Pact performed</span>
                      <span className="font-mono font-bold tabular-nums">
                        {bloodPactUsedAllTime ? "✓" : "—"}
                      </span>
                    </div>
                    <div className="flex items-start gap-1.5 text-[0.7rem] pt-1">
                      <Sparkles className="w-2.5 h-2.5 text-violet-300 mt-1 shrink-0" />
                      <span className="text-muted-foreground">
                        <span className="text-foreground/80">Reward:</span> {layer.persistentReward}
                      </span>
                    </div>
                  </div>
                )}
              </LayerView>
            );
          }
          // Layer 4 — cradle worlds won / seeds awakened
          if (layer.order === 4) {
            return (
              <LayerView
                key={layer.id}
                layer={layer}
                status={status}
                prevComplete={prevComplete}
                onOpen={() => setShowGenesis(true)}
              >
                {status !== "locked" && (
                  <div className="space-y-1 text-[0.7rem]">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground flex items-center gap-1">
                        <Globe className="w-3 h-3" /> Cradle Worlds won
                      </span>
                      <span className="font-mono font-bold tabular-nums">
                        {cradleWorldsWonCount}/{CRADLE_WORLDS.length}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Dormant Seeds awakened</span>
                      <span className="font-mono font-bold tabular-nums">
                        {seedsAwakenedCount}/{DORMANT_SEEDS.length}
                      </span>
                    </div>
                    <div className="flex items-start gap-1.5 text-[0.7rem] pt-1">
                      <Sparkles className="w-2.5 h-2.5 text-violet-300 mt-1 shrink-0" />
                      <span className="text-muted-foreground">
                        <span className="text-foreground/80">Reward:</span> {layer.persistentReward}
                      </span>
                    </div>
                  </div>
                )}
              </LayerView>
            );
          }
          // Layer 5 — laws / worship / miracles / heresy
          if (layer.order === 5) {
            return (
              <LayerView
                key={layer.id}
                layer={layer}
                status={status}
                prevComplete={prevComplete}
                onOpen={() => setShowApotheosis(true)}
              >
                {status !== "locked" && (
                  <div className="space-y-1 text-[0.7rem]">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground flex items-center gap-1">
                        <Scroll className="w-3 h-3" /> Divine Laws codified (all-time)
                      </span>
                      <span className="font-mono font-bold tabular-nums">
                        {lawsCodifiedAllTimeCount}/{DIVINE_LAWS.length}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Worship Modes tried</span>
                      <span className="font-mono font-bold tabular-nums">
                        {worshipModesTriedCount}/{WORSHIP_MODES.length}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Miracles used (all-time)</span>
                      <span className="font-mono font-bold tabular-nums">
                        {miraclesUsedAllTimeCount}/{MIRACLES.length}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Heresy survived</span>
                      <span className="font-mono font-bold tabular-nums">
                        {heresySurvivedAllTime ? "✓" : "—"}
                      </span>
                    </div>
                    <div className="flex items-start gap-1.5 text-[0.7rem] pt-1">
                      <Sparkles className="w-2.5 h-2.5 text-violet-300 mt-1 shrink-0" />
                      <span className="text-muted-foreground">
                        <span className="text-foreground/80">Reward:</span> {layer.persistentReward}
                      </span>
                    </div>
                  </div>
                )}
              </LayerView>
            );
          }
          // Layer 6 — relics bound / logic cores enabled
          if (layer.order === 6) {
            return (
              <LayerView
                key={layer.id}
                layer={layer}
                status={status}
                prevComplete={prevComplete}
                onOpen={() => setShowSingularity(true)}
              >
                {status !== "locked" && (
                  <div className="space-y-1 text-[0.7rem]">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground flex items-center gap-1">
                        <Gem className="w-3 h-3" /> Relic Loadouts bound (all-time)
                      </span>
                      <span className="font-mono font-bold tabular-nums">
                        {relicsBoundCount}/{RELIC_LOADOUTS.length}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Logic Cores enabled (all-time)</span>
                      <span className="font-mono font-bold tabular-nums">
                        {logicCoresEnabledCount}/{LOGIC_CORES.length}
                      </span>
                    </div>
                    <div className="flex items-start gap-1.5 text-[0.7rem] pt-1">
                      <Sparkles className="w-2.5 h-2.5 text-violet-300 mt-1 shrink-0" />
                      <span className="text-muted-foreground">
                        <span className="text-foreground/80">Reward:</span> {layer.persistentReward}
                      </span>
                    </div>
                  </div>
                )}
              </LayerView>
            );
          }
          // Future layers (7-10)
          return (
            <div
              key={layer.id}
              className={cn(
                "relative rounded-lg border p-3 transition-all border-border bg-muted/20 opacity-75"
              )}
            >
              <div className="flex items-start gap-3">
                <div className="shrink-0 w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm border bg-muted/40 border-border text-muted-foreground">
                  <Lock className="w-3.5 h-3.5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <h3 className="text-sm font-bold leading-tight">???</h3>
                  </div>
                  <p className="text-xs text-muted-foreground italic leading-snug">
                    Complete the previous layer to reveal.
                  </p>
                  <div className="mt-2 space-y-2">
                    <p className="text-[0.7rem] text-muted-foreground italic">
                      {prevComplete ? `Unlock by: ${layer.unlockCondition}` : "Complete the previous layer to reveal."}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
