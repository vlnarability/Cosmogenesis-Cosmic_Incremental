// Omnipotence — Layer 7 prestige content
//
// When a god reaches Omnipotence it learns to deny natural boundaries. Two
// archetypes fuse into one run via a Hybrid Lineage — power and paradox
// growing in the same hand. The Instability meter rises with each
// contradiction; pick a Stance (Contained / Balanced / Embraced) to decide
// whether to suppress, accept, or feed the chaos. Survive a meter peak
// without overflowing and the god earns the right to choose its Divine Face.
//
// Three mechanic families live in this file:
//
//   1. Hybrid Lineages (8)  — bind two archetypes into one run; each pair
//                             grants an upside (production / caps / pop
//                             growth / military / science mults) at the
//                             cost of an instability-per-second gain.
//   2. Instability Meter    — a 0..100 resource that rises each tick at
//                             the bound hybrid's rate × the active stance's
//                             multiplier. At INSTABILITY_MAX the run ends
//                             (the paradox shatters the god). Until then
//                             the player races to prestige before overflow.
//   3. Stances (3)          — Contained (instability ×0.5, hybrid bonuses
//                             ×0.5), Balanced (×1.0, ×1.0), Embraced
//                             (×1.5, ×2.0). One active per run.
//
// State fields (planned for GameState — to be wired in a follow-up task):
//   - activeHybrid:                 string | null             // bound hybrid lineage id, or null before bind
//   - activeStance:                 string                    // active stance id (defaults to "balanced")
//   - instability:                  number                    // current instability meter (0..100)
//   - peakInstability:              number                    // max instability reached this run
//   - survivedPeaksAllTime:         Record<string, boolean>   // per-stance "peak survived" mastery (persistent)
//   - hybridLineagesBoundAllTime:   Record<string, boolean>   // cumulative hybrids ever bound (persistent)
//
// Reference: Omnipotence is new to the TS port — the vanilla JS had no
// Layer 7+ content. The 8 hybrid pair list, 3 stances, and INSTABILITY_MAX
// / BASE_INSTABILITY_RATE constants come straight from the L7-data task
// spec. The hybrid `archetypes` tuples reference the 13 archetype ids
// defined in `archetypes.ts` (9 basic + 4 rare) — each fusion pairs one
// or two rare archetypes with a basic one for the paradox to bite.
//
// Advancement to Layer 8 (Divinity) requires surviving an Instability
// peak without the meter overflowing — see prestigeLayers.ts
// `omnipotence.completeState: "Survive an Instability peak without the meter overflowing"`.

// =====================================================================
// Constants
// =====================================================================

/**
 * Maximum instability value. When `state.instability` reaches this number
 * the run ends — the paradox sustaining the Hybrid Lineage shatters and
 * the god is cast back. The player should manage instability via Stance
 * selection (Contained slows the rise) and time their prestige before
 * overflow. Matches `prestigeLayers.ts omnipotence.completeState` wording
 * "without the meter overflowing".
 */
export const INSTABILITY_MAX: number = 100;

/**
 * Base instability accumulation rate, in points per second, before the
 * bound hybrid and active stance modify it. Used by `instabilityRateMult`
 * as the fallback when no Hybrid Lineage is bound — the inherent paradox
 * of sustaining Omnipotence at all, even without a fusion to feed it.
 * Effective rate each tick is `instabilityRateMult(state.activeStance, state.activeHybrid)`.
 *
 * At 0.3/s in Balanced stance with no hybrid bound, the meter fills the
 * 0..100 range in 100 / 0.3 ≈ 333 seconds (~5.5 minutes). Contained
 * doubles that to ~11 minutes; Embraced cuts it to ~3.7 minutes. Bound
 * hybrids with higher `instabilityPerSec` fill the meter faster still.
 */
export const BASE_INSTABILITY_RATE: number = 0.3;

/**
 * Peak threshold for the Layer 7 completion check (`isOmnipotenceComplete`).
 * The peak must reach (or exceed) this value during the run to count as
 * "surviving a peak" — a meter that never came close to overflow doesn't
 * demonstrate the player has weathered a real paradox. Set at 80 to leave
 * a 20-point safety margin below INSTABILITY_MAX. Matches the spec wording
 * "Survive an Instability peak without the meter overflowing".
 *
 * Not exported (internal) — `isOmnipotenceComplete` is the only consumer.
 */
const OMNIPOTENCE_COMPLETION_PEAK_THRESHOLD: number = 80;

// =====================================================================
// 1. Hybrid Lineages (8) — bind two archetypes into one run
// =====================================================================

/**
 * A single Hybrid Lineage. Only one hybrid can be bound per run (mirrors
 * the Worship Mode / Relic Loadout pattern from earlier layers —
 * `activeHybrid` in GameState is a single id, not a set). The store
 * applies the bound hybrid's bonuses each tick via
 * `hybridBonus(state.activeHybrid)`, multiplied by the active stance's
 * `hybridMult`.
 *
 * Effect field → consumer wiring:
 *   - `productionMult`         → additive all-production mult
 *   - `populationGrowthMult`   → additive pop-growth mult
 *   - `scienceMult`            → additive science mult
 *   - `militaryMult`           → additive military mult
 *   - `capsMult`               → additive multiplier on every resource cap
 *   - `instabilityPerSec`     → the rate (points/sec) at which the
 *                                Instability meter rises while this
 *                                hybrid is bound, BEFORE the stance
 *                                modifier (see `instabilityRateMult`)
 *
 * `instabilityPerSec` is a cost, not a bonus — but it lives on the
 * hybrid (not the stance) because each fusion's paradox strength is
 * unique to the archetype pair. The stance modifier multiplies it; see
 * `instabilityRateMult(stanceId, hybridId)`.
 *
 * `archetypes` is informational (a 2-tuple of archetype ids from
 * `archetypes.ts`) — used by the UI to show the fusion. Not enforced by
 * the validator beyond "exactly two distinct entries".
 */
export interface HybridLineageDef {
  /** Stable identifier (used as a key in `activeHybrid` / `hybridLineagesBoundAllTime`). */
  id: string;
  /** Human-readable hybrid lineage name. */
  name: string;
  /** Narrative / mechanical flavour describing what the fusion creates. */
  desc: string;
  /** Emoji glyph shown on the hybrid card. */
  icon: string;
  /** The two archetype ids (lowercase, matching `archetypes.ts`) being fused. Order is informational. */
  archetypes: [string, string];
  /** Additive all-production multiplier (0.15 = +15% all production). */
  productionMult?: number;
  /** Additive population-growth multiplier (0.25 = +25% pop growth). */
  populationGrowthMult?: number;
  /** Additive science multiplier (0.30 = +30% science). */
  scienceMult?: number;
  /** Additive military-power multiplier (0.20 = +20% military). */
  militaryMult?: number;
  /** Additive multiplier on every resource's cap (0.20 = +20% caps). */
  capsMult?: number;
  /** Instability gain per second while bound, before the stance modifier (0.30 = +0.3/s). */
  instabilityPerSec: number;
}

export const HYBRID_LINEAGES: HybridLineageDef[] = [
  {
    id: "photosynthetic_crystal",
    name: "Photosynthetic Crystal",
    desc:
      "Plantoid × Lithoid. Living crystal drinks sunlight; roots drink stone. Caps swell and production " +
      "flows from a body that photosynthesizes through mineral skin.",
    icon: "💎",
    archetypes: ["plantoid", "lithoid"],
    capsMult: 0.20,
    productionMult: 0.15,
    instabilityPerSec: 0.30,
  },
  {
    id: "warm_blooded_hunter",
    name: "Warm-Blooded Hunter",
    desc:
      "Mammalian × Reptilian. Warm blood meets cold patience. Populations thrive and the hunt is " +
      "relentless — the predator that never needs to bask.",
    icon: "🐾",
    archetypes: ["mammalian", "reptilian"],
    populationGrowthMult: 0.25,
    militaryMult: 0.20,
    instabilityPerSec: 0.40,
  },
  {
    id: "plague_bearer",
    name: "Plague Bearer",
    desc:
      "Necroid × Toxoid. Death is contagious, and contagion is ingenious. Science surges as all " +
      "production thickens with the spore of the grave.",
    icon: "🦠",
    archetypes: ["necroid", "toxoid"],
    scienceMult: 0.30,
    productionMult: 0.15,
    instabilityPerSec: 0.50,
  },
  {
    id: "swarm_intelligence",
    name: "Swarm Intelligence",
    desc:
      "Humanoid × Arthropoid. A thousand adaptable minds think as one. Production multiplies and " +
      "caps bloat with the size of the herd.",
    icon: "🐜",
    archetypes: ["humanoid", "arthropoid"],
    productionMult: 0.20,
    capsMult: 0.25,
    instabilityPerSec: 0.30,
  },
  {
    id: "crystal_survivor",
    name: "Crystal Survivor",
    desc:
      "Extremophile × Lithoid. Life that should not be, in a body that will not break. Caps harden " +
      "and all production rises from a form that endures anything.",
    icon: "🪨",
    archetypes: ["extremophile", "lithoid"],
    productionMult: 0.15,
    capsMult: 0.30,
    instabilityPerSec: 0.35,
  },
  {
    id: "bloom_of_death",
    name: "Bloom of Death",
    desc:
      "Plantoid × Necroid. Roots feed on what they bury. Production and science bloom from the " +
      "grave — every harvest is also a funeral.",
    icon: "🥀",
    archetypes: ["plantoid", "necroid"],
    productionMult: 0.25,
    scienceMult: 0.20,
    instabilityPerSec: 0.45,
  },
  {
    id: "venomous_warmth",
    name: "Venomous Warmth",
    desc:
      "Mammalian × Toxoid. Nurture with a bite. Populations boom and the herd learns to defend " +
      "itself — the kindest poison is the one that protects its own.",
    icon: "🐍",
    archetypes: ["mammalian", "toxoid"],
    populationGrowthMult: 0.30,
    militaryMult: 0.15,
    instabilityPerSec: 0.40,
  },
  {
    id: "adaptive_genesis",
    name: "Adaptive Genesis",
    desc:
      "Humanoid × Extremophile. Adaptable life that survives anywhere. All production rises and " +
      "caps stretch gently — the safest fusion, and the slowest paradox.",
    icon: "🧬",
    archetypes: ["humanoid", "extremophile"],
    productionMult: 0.20,
    capsMult: 0.15,
    instabilityPerSec: 0.25,
  },
];

export const HYBRID_LINEAGE_MAP: Record<string, HybridLineageDef> = Object.fromEntries(
  HYBRID_LINEAGES.map((h) => [h.id, h])
);

export const HYBRID_LINEAGE_COUNT: number = HYBRID_LINEAGES.length;

// =====================================================================
// 2. Stances (3) — how to handle instability
// =====================================================================

/**
 * A single Stance. Only one stance can be active per run (mirrors the
 * Worship Mode / Relic Loadout / Hybrid Lineage "pick one" pattern). The
 * store reads `stance.instabilityMult` and `stance.hybridMult` each tick
 * via `STANCE_MAP[state.activeStance]`.
 *
 * Stance field → consumer wiring:
 *   - `instabilityMult`  → multiplier on the bound hybrid's `instabilityPerSec`
 *                          (or `BASE_INSTABILITY_RATE` if no hybrid is bound).
 *                          Contained ×0.5, Balanced ×1.0, Embraced ×1.5.
 *   - `hybridMult`       → multiplier on every bonus field returned by
 *                          `hybridBonus(activeHybrid)`. Contained ×0.5
 *                          (bonuses halved), Balanced ×1.0, Embraced ×2.0
 *                          (bonuses doubled).
 *
 * The two multipliers are intentionally coupled: Contained trades half
 * the hybrid's power for half the instability cost; Embraced doubles
 * the power at 1.5× the cost. Balanced is the no-trade baseline. The
 * asymmetry (Contained's cost/power ratio is 1:1, Embraced's is 0.75:1)
 * makes Embraced the higher-stakes, higher-reward pick — appropriate for
 * a layer whose completion condition is "survive a peak".
 */
export interface StanceDef {
  /** Stable identifier (used as `activeStance` in GameState). */
  id: string;
  /** Human-readable stance name. */
  name: string;
  /** Narrative / mechanical flavour describing the stance's trade-off. */
  desc: string;
  /** Emoji glyph shown on the stance card. */
  icon: string;
  /** Multiplier on the hybrid's instability-per-sec rate (0.5 = rises 50% slower). */
  instabilityMult: number;
  /** Multiplier on every bonus field from `hybridBonus` (0.5 = bonuses halved). */
  hybridMult: number;
}

export const STANCES: StanceDef[] = [
  {
    id: "contained",
    name: "Contained",
    desc:
      "Hold the paradox in check. Instability rises 50% slower — but the hybrid's bonuses are halved " +
      "as the fusion strains against its leash.",
    icon: "🛡",
    instabilityMult: 0.5,
    hybridMult: 0.5,
  },
  {
    id: "balanced",
    name: "Balanced",
    desc:
      "Accept the paradox at face value. Instability rises at the hybrid's natural rate and bonuses " +
      "apply in full. The baseline fusion.",
    icon: "⚖️",
    instabilityMult: 1.0,
    hybridMult: 1.0,
  },
  {
    id: "embraced",
    name: "Embraced",
    desc:
      "Feed the contradiction. Instability rises 50% faster — but the hybrid's bonuses double as the " +
      "fusion finally lets itself go.",
    icon: "🔥",
    instabilityMult: 1.5,
    hybridMult: 2.0,
  },
];

export const STANCE_MAP: Record<string, StanceDef> = Object.fromEntries(
  STANCES.map((s) => [s.id, s])
);

export const STANCE_COUNT: number = STANCES.length;

// =====================================================================
// Module-load sanity checks
// =====================================================================

/**
 * Validate the omnipotence data at module load:
 *   - INSTABILITY_MAX > 0 (must allow some meter rise).
 *   - BASE_INSTABILITY_RATE > 0 (must rise when no hybrid is bound).
 *   - OMNIPOTENCE_COMPLETION_PEAK_THRESHOLD is in (0, INSTABILITY_MAX).
 *   - All hybrid lineage ids are unique.
 *   - Each hybrid's `archetypes` tuple has exactly two distinct entries.
 *   - Each hybrid sets at least one bonus field (the upside half of the
 *     fusion; `instabilityPerSec` alone is a cost, not a fusion).
 *   - Each hybrid's `instabilityPerSec` is > 0 (no "free" fusion).
 *   - All mult fields (if set) on hybrids are > 0 (bonuses, never penalties).
 *   - Exactly 3 stances present.
 *   - All stance ids are unique.
 *   - Each stance's `instabilityMult` and `hybridMult` are > 0.
 *   - The "contained" stance slows instability and weakens bonuses (<1, <1).
 *   - The "balanced" stance is the no-trade baseline (==1, ==1).
 *   - The "embraced" stance accelerates instability and amplifies bonuses (>1, >1).
 *
 * Throws on any violation (programmer error, not a runtime / save data
 * error). The check is O(N) and runs once at module import, so it's a
 * no-op on the hot path. Matches the pattern established by `apotheosis.ts`,
 * `singularity.ts`, `transcendence.ts`, and `genesis.ts`.
 */
(function validateOmnipotenceData(): void {
  if (INSTABILITY_MAX <= 0) {
    throw new Error(
      `omnipotence.ts: INSTABILITY_MAX must be > 0 (got ${INSTABILITY_MAX})`
    );
  }
  if (BASE_INSTABILITY_RATE <= 0) {
    throw new Error(
      `omnipotence.ts: BASE_INSTABILITY_RATE must be > 0 (got ${BASE_INSTABILITY_RATE})`
    );
  }
  if (
    OMNIPOTENCE_COMPLETION_PEAK_THRESHOLD <= 0 ||
    OMNIPOTENCE_COMPLETION_PEAK_THRESHOLD >= INSTABILITY_MAX
  ) {
    throw new Error(
      `omnipotence.ts: OMNIPOTENCE_COMPLETION_PEAK_THRESHOLD must be in (0, ${INSTABILITY_MAX}) (got ${OMNIPOTENCE_COMPLETION_PEAK_THRESHOLD})`
    );
  }

  // ---- Hybrid lineages ----
  const seenHybrid = new Set<string>();
  for (const h of HYBRID_LINEAGES) {
    if (seenHybrid.has(h.id)) {
      throw new Error(`omnipotence.ts: duplicate hybrid lineage id "${h.id}"`);
    }
    seenHybrid.add(h.id);

    if (h.archetypes.length !== 2) {
      throw new Error(
        `omnipotence.ts: hybrid "${h.id}" archetypes must have exactly 2 entries (got ${h.archetypes.length})`
      );
    }
    if (h.archetypes[0] === h.archetypes[1]) {
      throw new Error(
        `omnipotence.ts: hybrid "${h.id}" archetypes must be distinct (got [${h.archetypes.join(", ")}])`
      );
    }

    const bonusCount = [
      h.productionMult,
      h.populationGrowthMult,
      h.scienceMult,
      h.militaryMult,
      h.capsMult,
    ].filter((v) => v !== undefined).length;

    if (bonusCount < 1) {
      throw new Error(
        `omnipotence.ts: hybrid "${h.id}" must set at least one bonus field (set ${bonusCount})`
      );
    }

    if (h.instabilityPerSec <= 0) {
      throw new Error(
        `omnipotence.ts: hybrid "${h.id}" instabilityPerSec must be > 0 (got ${h.instabilityPerSec})`
      );
    }

    if (h.productionMult !== undefined && h.productionMult <= 0) {
      throw new Error(
        `omnipotence.ts: hybrid "${h.id}" productionMult must be > 0 (got ${h.productionMult})`
      );
    }
    if (h.populationGrowthMult !== undefined && h.populationGrowthMult <= 0) {
      throw new Error(
        `omnipotence.ts: hybrid "${h.id}" populationGrowthMult must be > 0 (got ${h.populationGrowthMult})`
      );
    }
    if (h.scienceMult !== undefined && h.scienceMult <= 0) {
      throw new Error(
        `omnipotence.ts: hybrid "${h.id}" scienceMult must be > 0 (got ${h.scienceMult})`
      );
    }
    if (h.militaryMult !== undefined && h.militaryMult <= 0) {
      throw new Error(
        `omnipotence.ts: hybrid "${h.id}" militaryMult must be > 0 (got ${h.militaryMult})`
      );
    }
    if (h.capsMult !== undefined && h.capsMult <= 0) {
      throw new Error(
        `omnipotence.ts: hybrid "${h.id}" capsMult must be > 0 (got ${h.capsMult})`
      );
    }
  }

  // ---- Stances ----
  if (STANCE_COUNT !== 3) {
    throw new Error(
      `omnipotence.ts: expected exactly 3 stances (got ${STANCE_COUNT})`
    );
  }
  const seenStance = new Set<string>();
  for (const s of STANCES) {
    if (seenStance.has(s.id)) {
      throw new Error(`omnipotence.ts: duplicate stance id "${s.id}"`);
    }
    seenStance.add(s.id);

    if (s.instabilityMult <= 0) {
      throw new Error(
        `omnipotence.ts: stance "${s.id}" instabilityMult must be > 0 (got ${s.instabilityMult})`
      );
    }
    if (s.hybridMult <= 0) {
      throw new Error(
        `omnipotence.ts: stance "${s.id}" hybridMult must be > 0 (got ${s.hybridMult})`
      );
    }
  }

  // Verify the three stance ids are present with the spec's trade-offs.
  const contained = STANCE_MAP["contained"];
  const balanced = STANCE_MAP["balanced"];
  const embraced = STANCE_MAP["embraced"];
  if (!contained || !balanced || !embraced) {
    throw new Error(
      `omnipotence.ts: stances must include "contained", "balanced", and "embraced" (got [${STANCES.map((s) => s.id).join(", ")}])`
    );
  }
  if (!(contained.instabilityMult < 1 && contained.hybridMult < 1)) {
    throw new Error(
      `omnipotence.ts: "contained" stance must slow instability (<1) and halve bonuses (<1) — got instabilityMult=${contained.instabilityMult}, hybridMult=${contained.hybridMult}`
    );
  }
  if (balanced.instabilityMult !== 1 || balanced.hybridMult !== 1) {
    throw new Error(
      `omnipotence.ts: "balanced" stance must be the no-trade baseline (1.0, 1.0) — got instabilityMult=${balanced.instabilityMult}, hybridMult=${balanced.hybridMult}`
    );
  }
  if (!(embraced.instabilityMult > 1 && embraced.hybridMult > 1)) {
    throw new Error(
      `omnipotence.ts: "embraced" stance must accelerate instability (>1) and amplify bonuses (>1) — got instabilityMult=${embraced.instabilityMult}, hybridMult=${embraced.hybridMult}`
    );
  }
})();

// =====================================================================
// Helpers
// =====================================================================

/**
 * Aggregated bonus object returned by `hybridBonus`.
 *
 * All mult fields are additive on top of the baseline (0 = no change).
 * `instabilityPerSec` is the RAW per-second instability gain from the
 * bound hybrid (BEFORE the stance modifier — the consumer composes the
 * stance modifier via `instabilityRateMult`). The consumer applies the
 * mult fields in the tick loop:
 *
 *   - `productionMult`:        multiply production by `(1 + productionMult × stance.hybridMult)`
 *   - `populationGrowthMult`:  multiply pop growth by `(1 + populationGrowthMult × stance.hybridMult)`
 *   - `scienceMult`:           multiply science by `(1 + scienceMult × stance.hybridMult)`
 *   - `militaryMult`:          multiply military by `(1 + militaryMult × stance.hybridMult)`
 *   - `capsMult`:              multiply every resource cap by `(1 + capsMult × stance.hybridMult)`
 *   - `instabilityPerSec`:     compose with stance via `instabilityRateMult`, then add to `state.instability`
 *
 * Only one hybrid can be bound per run (`state.activeHybrid` is a single
 * id, not a set), so the aggregate is just the bound hybrid's fields
 * passed through with defaults. The consumer multiplies the bonus fields
 * by `stance.hybridMult` (Contained ×0.5, Balanced ×1.0, Embraced ×2.0)
 * at the call site — that coupling is what makes a Stance more than a
 * label. `instabilityPerSec` is returned raw (NOT pre-multiplied) so the
 * consumer can compose it with `stance.instabilityMult` via
 * `instabilityRateMult(stanceId, hybridId)` for the actual rate.
 */
export interface HybridBonus {
  /** Additive all-production multiplier (Photosynthetic Crystal +0.15, Plague Bearer +0.15, etc.). */
  productionMult: number;
  /** Additive population-growth multiplier (Warm-Blooded Hunter +0.25, Venomous Warmth +0.30). */
  populationGrowthMult: number;
  /** Additive science multiplier (Plague Bearer +0.30, Bloom of Death +0.20). */
  scienceMult: number;
  /** Additive military-power multiplier (Warm-Blooded Hunter +0.20, Venomous Warmth +0.15). */
  militaryMult: number;
  /** Additive multiplier on every resource's cap (Photosynthetic Crystal +0.20, Crystal Survivor +0.30). */
  capsMult: number;
  /** Raw per-second instability gain (BEFORE stance modifier). Adaptive Genesis +0.25, Plague Bearer +0.50. */
  instabilityPerSec: number;
}

/**
 * Return the bound hybrid lineage's bonuses as a single aggregate object.
 *
 * Only one hybrid can be bound per run (`state.activeHybrid` is a single
 * id, not a set — mirrors the Worship Mode / Relic Loadout pattern from
 * earlier layers). The aggregate is just the bound hybrid's stat fields
 * passed through with defaults (0 for all fields). The consumer
 * multiplies the bonus fields by the active stance's `hybridMult`
 * (Contained ×0.5, Balanced ×1.0, Embraced ×2.0) at the call site.
 *
 * Used by the tick loop to compute per-resource multipliers, the pop-
 * growth rate, and cap multipliers. `instabilityPerSec` is returned raw
 * so the consumer can compose it with the stance modifier separately via
 * `instabilityRateMult(stanceId, hybridId)` — that's where the
 * `× stance.instabilityMult` happens.
 *
 * @param hybridId  The bound hybrid lineage id, or `null` if none.
 * @returns Aggregated `HybridBonus` (all fields defaulted for null / unknown input).
 *
 * @example
 *   hybridBonus(null)
 *     // → { productionMult:0, ..., instabilityPerSec:0 }
 *   hybridBonus("photosynthetic_crystal")
 *     // → { productionMult:0.15, capsMult:0.20, instabilityPerSec:0.30, ... }
 *   hybridBonus("plague_bearer")
 *     // → { productionMult:0.15, scienceMult:0.30, instabilityPerSec:0.50, ... }
 *   hybridBonus("adaptive_genesis")
 *     // → { productionMult:0.20, capsMult:0.15, instabilityPerSec:0.25, ... }
 *   hybridBonus("nonexistent_id")
 *     // → { all defaults }  (unknown id treated as "no hybrid")
 */
export function hybridBonus(
  hybridId: string | null
): HybridBonus {
  const result: HybridBonus = {
    productionMult: 0,
    populationGrowthMult: 0,
    scienceMult: 0,
    militaryMult: 0,
    capsMult: 0,
    instabilityPerSec: 0,
  };
  if (!hybridId) return result;
  const hybrid = HYBRID_LINEAGE_MAP[hybridId];
  if (!hybrid) return result;
  if (hybrid.productionMult !== undefined) result.productionMult = hybrid.productionMult;
  if (hybrid.populationGrowthMult !== undefined) result.populationGrowthMult = hybrid.populationGrowthMult;
  if (hybrid.scienceMult !== undefined) result.scienceMult = hybrid.scienceMult;
  if (hybrid.militaryMult !== undefined) result.militaryMult = hybrid.militaryMult;
  if (hybrid.capsMult !== undefined) result.capsMult = hybrid.capsMult;
  if (hybrid.instabilityPerSec !== undefined) result.instabilityPerSec = hybrid.instabilityPerSec;
  return result;
}

/**
 * Effective per-second instability rate for the given stance + hybrid
 * combination. Composes the bound hybrid's `instabilityPerSec` (or
 * `BASE_INSTABILITY_RATE` if no hybrid is bound) with the active stance's
 * `instabilityMult`:
 *
 *   effectiveRate = (hybrid ? hybrid.instabilityPerSec : BASE_INSTABILITY_RATE) × stance.instabilityMult
 *
 * The consumer adds this value to `state.instability` each tick. When the
 * meter reaches `INSTABILITY_MAX`, the run ends (the paradox shatters).
 *
 * Used by the tick loop in conjunction with `hybridBonus` — the hybrid's
 * bonuses feed production / caps / pop growth / etc., while this function
 * feeds the instability rise. The two are intentionally separate so the
 * consumer can choose to apply one without the other (e.g. suppress the
 * instability rise during a "trial of stasis" event while keeping the
 * hybrid's bonuses active, or apply the stance's bonus multiplier to a
 * hybrid's production while holding the meter steady for a boss fight).
 *
 * @param stanceId  The active stance id, or `null` (treated as "balanced" ×1.0).
 * @param hybridId  The bound hybrid lineage id, or `null` (falls back to BASE_INSTABILITY_RATE).
 * @returns Per-second instability rate (always >= 0; stance × base rate).
 *
 * @example
 *   instabilityRateMult("balanced", "photosynthetic_crystal")
 *     // → 0.30 × 1.0 = 0.30  (Balanced stance, Plantoid×Lithoid hybrid)
 *   instabilityRateMult("contained", "plague_bearer")
 *     // → 0.50 × 0.5 = 0.25  (Contained halves Plague Bearer's paradox)
 *   instabilityRateMult("embraced", "adaptive_genesis")
 *     // → 0.25 × 1.5 = 0.375  (Embraced speeds the safest hybrid)
 *   instabilityRateMult("balanced", null)
 *     // → 0.30 × 1.0 = 0.30  (No hybrid bound: BASE_INSTABILITY_RATE)
 *   instabilityRateMult(null, "plague_bearer")
 *     // → 0.50 × 1.0 = 0.50  (No stance selected: defaults to balanced ×1.0)
 *   instabilityRateMult("nonexistent", null)
 *     // → 0.30 × 1.0 = 0.30  (Unknown stance: defaults to balanced; BASE rate applies)
 */
export function instabilityRateMult(
  stanceId: string | null,
  hybridId: string | null
): number {
  const stance = stanceId ? STANCE_MAP[stanceId] : null;
  const stanceMult = stance ? stance.instabilityMult : 1.0;
  const hybrid = hybridId ? HYBRID_LINEAGE_MAP[hybridId] : null;
  const baseRate = hybrid ? hybrid.instabilityPerSec : BASE_INSTABILITY_RATE;
  return baseRate * stanceMult;
}

/**
 * Whether the Layer 7 (Omnipotence) completion conditions are met.
 *
 * Conditions (both must be true):
 *   1. The instability meter reached a "peak" of at least
 *      `OMNIPOTENCE_COMPLETION_PEAK_THRESHOLD` (80) at some point during
 *      the run — the player weathered a real paradox, not a tame one.
 *   2. The peak never reached `INSTABILITY_MAX` (100) — the meter did not
 *      overflow (an overflow would have ended the run, so reaching this
 *      check at all means the player is still in control).
 *
 * Matches `prestigeLayers.ts omnipotence.completeState: "Survive an
 * Instability peak without the meter overflowing"`. Used by
 * `triggerPrestige()` to gate advancement to Layer 8 (Divinity).
 *
 * The "peak" is the maximum value `state.instability` reached during the
 * run — tracked as `state.peakInstability`, updated each tick via
 * `peakInstability = Math.max(peakInstability, instability)`. This is a
 * per-run field, reset to 0 on prestige.
 *
 * @param peakInstability  Maximum instability value reached this run.
 * @returns `true` if the peak reached the threshold without overflowing.
 *
 * @example
 *   isOmnipotenceComplete(0)
 *     // → false  (no peak weathered yet)
 *   isOmnipotenceComplete(50)
 *     // → false  (peak below threshold — too tame)
 *   isOmnipotenceComplete(79)
 *     // → false  (one short of the threshold)
 *   isOmnipotenceComplete(80)
 *     // → true  (threshold met, did not overflow)
 *   isOmnipotenceComplete(99)
 *     // → true  (peak just under overflow — the closest call)
 *   isOmnipotenceComplete(100)
 *     // → false  (meter overflowed — run would have ended)
 *   isOmnipotenceComplete(120)
 *     // → false  (impossible peak above max — defensive, treated as overflow)
 */
export function isOmnipotenceComplete(
  peakInstability: number
): boolean {
  return (
    peakInstability >= OMNIPOTENCE_COMPLETION_PEAK_THRESHOLD &&
    peakInstability < INSTABILITY_MAX
  );
}
