// Divinity — Layer 8 prestige content
//
// When a god reaches Divinity it learns that worship is a currency. Prayer
// flows upward from every population point — and the god decides where to
// route it. Six Prayer Channels turn raw prayer into directed divine effect
// (growth, war, knowledge, wealth, faith, harmony). Six Divine Masks let
// the god choose its perceived identity for the run. Five Worship Polarities
// shape how mortals feel about the god, with run-long trade-offs.
//
// Three mechanic families live in this file:
//
//   1. Prayer Channels (6)        — leveled conduits that route per-second
//                                    prayer into bonuses. Each channel has
//                                    a per-level effect; the player invests
//                                    prayer to raise channel levels. All
//                                    six can be opened simultaneously (the
//                                    "pick" is which to LEVEL, not which to
//                                    enable); the level cap is open-ended.
//   2. Divine Masks (6)            — pick one per run. Each mask is a
//                                    perceived divine identity with bonuses
//                                    and (except for The Sovereign) a
//                                    trade-off. The active mask's bonuses
//                                    apply throughout the run.
//   3. Worship Polarities (5)      — pick one per run. The polarity shapes
//                                    how mortals relate to the god and
//                                    applies run-long production / military
//                                    / science / happiness / heresy-rate
//                                    modifiers.
//
// Prayer generation: `prayerRate(population) = population × PRAYER_RATE_PER_POPULATION`
// (default 0.001 per pop per second). 1000 population → 1 prayer/sec.
// The consumer adds this to a `prayer` accumulator each tick; the player
// then spends prayer to open / level Prayer Channels. The exact cost curve
// is left to the wiring task (mirrors the precedent set by other layers:
// this file defines the data shapes and helpers, not the spending rules).
//
// State fields (planned for GameState — to be wired in a follow-up task):
//   - activeMask:                 string | null             // active Divine Mask id, or null before pick
//   - activePolarity:             string | null             // active Worship Polarity id, or null before pick
//   - prayerChannels:             Record<string, number>   // channel id → current level (0 = unopened)
//   - prayer:                     number                    // current prayer pool (spent to level channels)
//   - peakPrayer:                 number                    // max prayer accumulated this run (for diagnostics)
//   - masksWornAllTime:           Record<string, boolean>   // cumulative masks ever worn (persistent)
//   - polaritiesAlignedAllTime:   Record<string, boolean>   // cumulative polarities ever aligned (persistent)
//   - channelsOpenedAllTime:      Record<string, boolean>   // cumulative channels ever opened (persistent)
//
// Reference: Divinity is new to the TS port — the vanilla JS had no
// Layer 8+ content. The 6 / 6 / 5 spec, the per-level channel effects, and
// the `population × 0.001` base prayer rate come straight from the
// L8-data task spec. The Worship Polarity list (Reverence / Fear / Wonder
// / Ambition / Mystery) intentionally reuses the names from
// `apotheosis.ts WORSHIP_MODES` because Layer 8 is the apotheosis-era
// "Worship Modes" idea refined — a Divinity-layer god is choosing the
// *polarity* of its worship, not the mode. Effects overlap by design
// (Reverence in both layers boosts production) but the Divinity versions
// stack on top of the Apotheosis versions.
//
// Advancement to Layer 9 (Infinity) requires opening 3 Prayer Channels
// AND aligning a Worship Polarity — see prestigeLayers.ts
// `divinity.completeState: "Open 3 Prayer Channels and align Worship
// Polarity"`.

// =====================================================================
// Constants
// =====================================================================

/**
 * Base prayer generation rate, in prayer per population per second.
 * Effective per-second prayer gain is
 * `prayerRate(state.population) = state.population × PRAYER_RATE_PER_POPULATION`.
 *
 * At 0.001/pop/s, a population of 100 produces 0.1 prayer/sec; 1,000 pop
 * produces 1/sec; 10,000 pop produces 10/sec. The wiring task will define
 * how much each Prayer Channel level costs to open/raise — at a rough
 * scaling (e.g. cost = 10 × level² ), the first level of any channel costs
 * 10 prayer (~10 seconds at 1 prayer/sec), and the 10th level costs 1,000
 * prayer (~17 minutes). Channels can be opened and leveled freely; the
 * completion check just requires opening 3 distinct channels.
 */
export const PRAYER_RATE_PER_POPULATION: number = 0.001;

/**
 * Number of Prayer Channels the player must open (level >= 1) for the
 * Layer 8 completion check (`isDivinityComplete`). Matches the spec
 * wording "Open 3 Prayer Channels and align Worship Polarity" from
 * prestigeLayers.ts. The dataset defines 6 channels total, so this is half
 * of the available pool — a meaningful but not exhaustive commitment.
 */
export const DIVINITY_COMPLETION_CHANNELS_REQUIRED: number = 3;

// =====================================================================
// 1. Prayer Channels (6) — route per-second prayer into divine effects
// =====================================================================

/**
 * A single Prayer Channel. Each channel is leveled with prayer (the
 * player spends `prayer` to raise `prayerChannels[id]`). The bonus per
 * level is fixed; the consumer multiplies by the channel's current level
 * when aggregating via `prayerChannelBonus(channels)`.
 *
 * Effect field → consumer wiring (per-level magnitude):
 *   - `populationGrowthMultPerLevel`  → additive pop-growth mult per level
 *                                       (Growth: +0.10 / level → 10% / level)
 *   - `militaryMultPerLevel`         → additive military mult per level
 *                                       (War: +0.15 / level → 15% / level)
 *   - `scienceMultPerLevel`         → additive science mult per level
 *                                       (Knowledge: +0.15 / level → 15% / level)
 *   - `goldMultPerLevel`            → additive gold mult per level
 *                                       (Wealth: +0.15 / level → 15% / level)
 *   - `productionMultPerLevel`       → additive production mult per level
 *                                       (Wealth: +0.15 / level → 15% / level)
 *   - `divinityPerSecPerLevel`      → flat Divinity/sec per level
 *                                       (Faith: +0.01 / level → +0.01 Divinity/s)
 *   - `happinessFlatPerLevel`       → flat per-tick happiness per level
 *                                       (Harmony: +5 / level → +5 happiness/s, subject to cap)
 *
 * Each channel sets exactly ONE effect kind (enforced by the IIFE
 * validator). Wealth is the sole exception — it sets BOTH gold and
 * production at +0.15/level, because the spec phrasing "+15% gold/
 * production per prayer level" is a paired effect on a single channel.
 *
 * The "prayer level" is open-ended — there is no max-level cap in this
 * file. The wiring task may impose one (e.g. 10 or 100) and define the
 * cost curve. Channels remain active forever once opened (until prestige).
 */
export interface PrayerChannelDef {
  /** Stable identifier (used as a key in `prayerChannels` in GameState). */
  id: string;
  /** Human-readable channel name. */
  name: string;
  /** Narrative / mechanical flavour of what prayer routed here produces. */
  desc: string;
  /** Emoji glyph shown on the channel card. */
  icon: string;
  /** Additive population-growth multiplier per level (Growth: +0.10). */
  populationGrowthMultPerLevel?: number;
  /** Additive military-power multiplier per level (War: +0.15). */
  militaryMultPerLevel?: number;
  /** Additive science multiplier per level (Knowledge: +0.15). */
  scienceMultPerLevel?: number;
  /** Additive gold multiplier per level (Wealth: +0.15). */
  goldMultPerLevel?: number;
  /** Additive all-production multiplier per level (Wealth: +0.15). */
  productionMultPerLevel?: number;
  /** Flat Divinity per second per level (Faith: +0.01). */
  divinityPerSecPerLevel?: number;
  /** Flat per-tick happiness bonus per level (Harmony: +5, subject to cap). */
  happinessFlatPerLevel?: number;
}

export const PRAYER_CHANNELS: PrayerChannelDef[] = [
  {
    id: "growth",
    name: "Growth Channel",
    desc:
      "Route prayer into the wellspring of life. Each prayer level widens the cradle — populations " +
      "swell 10% faster for every level invested.",
    icon: "🌱",
    populationGrowthMultPerLevel: 0.10,
  },
  {
    id: "war",
    name: "War Channel",
    desc:
      "Route prayer into the forge of conflict. Each prayer level hardens every blade — military " +
      "power rises 15% for every level invested.",
    icon: "⚔️",
    militaryMultPerLevel: 0.15,
  },
  {
    id: "knowledge",
    name: "Knowledge Channel",
    desc:
      "Route prayer into the library of the divine. Each prayer level illuminates more of what is " +
      "knowable — science rises 15% for every level invested.",
    icon: "📚",
    scienceMultPerLevel: 0.15,
  },
  {
    id: "wealth",
    name: "Wealth Channel",
    desc:
      "Route prayer into the coffers of the world. Each prayer level gilds both coin and craft — " +
      "gold and production each rise 15% for every level invested.",
    icon: "🪙",
    goldMultPerLevel: 0.15,
    productionMultPerLevel: 0.15,
  },
  {
    id: "faith",
    name: "Faith Channel",
    desc:
      "Route prayer into itself — devotion begetting devotion. Each prayer level trickles 0.01 " +
      "Divinity per second back into the god, a closed loop of belief.",
    icon: "✨",
    divinityPerSecPerLevel: 0.01,
  },
  {
    id: "harmony",
    name: "Harmony Channel",
    desc:
      "Route prayer into the songs of the contented. Each prayer level lifts happiness by 5 per " +
      "second, softening every discontent that prayer cannot reach.",
    icon: "🎶",
    happinessFlatPerLevel: 5,
  },
];

export const PRAYER_CHANNEL_MAP: Record<string, PrayerChannelDef> = Object.fromEntries(
  PRAYER_CHANNELS.map((c) => [c.id, c])
);

export const PRAYER_CHANNEL_COUNT: number = PRAYER_CHANNELS.length;

// =====================================================================
// 2. Divine Masks (6) — choose the god's perceived identity (one active)
// =====================================================================

/**
 * A single Divine Mask. The player picks exactly one per run; it applies
 * for the entire run. The mask is the god's *perceived* face — the
 * bonuses reflect how creation responds to that face, not the god's true
 * nature (which is why the same god can be The Creator in one run and The
 * Destroyer in the next).
 *
 * Effect field → consumer wiring:
 *   - `productionMult`         → additive all-production mult
 *                                 (Creator +0.25, Sage +0.15, Sovereign +0.10)
 *   - `populationGrowthMult`  → additive pop-growth mult (Preserver +0.20, Sovereign +0.10)
 *   - `militaryMult`          → additive military mult (Destroyer +0.40, Sovereign +0.10)
 *   - `scienceMult`           → additive science mult (Trickster +0.30, Sovereign +0.10)
 *   - `goldMult`              → additive gold mult (Trickster +0.20, Sovereign +0.10)
 *   - `capsMult`              → additive caps mult (Creator +0.15, Preserver +0.30, Sovereign +0.10)
 *   - `divinityMult`          → multiplicative Divinity-gain mult (Sage +0.50 = ×1.5 Divinity)
 *   - `happinessFlat`         → signed flat per-tick happiness change (Destroyer -10)
 *
 * `divinityMult` is additive with other Divinity-gain modifiers — the
 * consumer multiplies all Divinity gains (per-tick grants, Faith Channel
 * output, etc.) by `(1 + sum_of_divinityMult)`. The Sage's +0.50 means
 * every source of Divinity produces 50% more.
 *
 * `happinessFlat` is signed — The Destroyer applies -10 per tick
 * (happiness drains 10/s, subject to floor at 0). The Sovereign has no
 * trade-off by design ("all bonuses +10%, no downside — balanced").
 */
export interface DivineMaskDef {
  /** Stable identifier (matches `activeMask` in GameState). */
  id: string;
  /** Human-readable mask name (always prefixed "The " — "The Creator", etc.). */
  name: string;
  /** Narrative / mechanical flavour of the mask's identity and trade-off. */
  desc: string;
  /** Emoji glyph shown on the mask card. */
  icon: string;
  /** Additive all-production multiplier (Creator +0.25, Sage +0.15, Sovereign +0.10). */
  productionMult?: number;
  /** Additive population-growth multiplier (Preserver +0.20, Sovereign +0.10). */
  populationGrowthMult?: number;
  /** Additive military-power multiplier (Destroyer +0.40, Sovereign +0.10). */
  militaryMult?: number;
  /** Additive science multiplier (Trickster +0.30, Sovereign +0.10). */
  scienceMult?: number;
  /** Additive gold multiplier (Trickster +0.20, Sovereign +0.10). */
  goldMult?: number;
  /** Additive multiplier on every resource's cap (Creator +0.15, Preserver +0.30, Sovereign +0.10). */
  capsMult?: number;
  /** Additive multiplier on all Divinity gains (Sage +0.50 = +50% Divinity). */
  divinityMult?: number;
  /** Signed flat per-tick happiness change (Destroyer -10). */
  happinessFlat?: number;
}

export const DIVINE_MASKS: DivineMaskDef[] = [
  {
    id: "creator",
    name: "The Creator",
    desc:
      "The god shows its making face. Production flows 25% richer and every cap widens by 15% — " +
      "the world bends toward being shaped. No trade-off: creation is its own reward.",
    icon: "🎨",
    productionMult: 0.25,
    capsMult: 0.15,
  },
  {
    id: "destroyer",
    name: "The Destroyer",
    desc:
      "The god shows its unmaking face. Military power surges 40% — but the world flinches, and " +
      "happiness drains by 10 per second. To be feared is also to be alone.",
    icon: "💥",
    militaryMult: 0.40,
    happinessFlat: -10,
  },
  {
    id: "preserver",
    name: "The Preserver",
    desc:
      "The god shows its holding face. Caps swell 30% and populations grow 20% faster — nothing " +
      "is lost, nothing is wasted. The world endures.",
    icon: "🛡️",
    capsMult: 0.30,
    populationGrowthMult: 0.20,
  },
  {
    id: "trickster",
    name: "The Trickster",
    desc:
      "The god shows its laughing face. Science surges 30% and gold flows 20% richer — the world " +
      "is fooled into working harder than it knows.",
    icon: "🃏",
    scienceMult: 0.30,
    goldMult: 0.20,
  },
  {
    id: "sage",
    name: "The Sage",
    desc:
      "The god shows its knowing face. All production rises 15% and Divinity itself flows 50% " +
      "richer — the god drinks from its own well.",
    icon: "🧙",
    productionMult: 0.15,
    divinityMult: 0.50,
  },
  {
    id: "sovereign",
    name: "The Sovereign",
    desc:
      "The god shows its balanced face. Every domain rises 10% — production, growth, military, " +
      "science, gold, caps. No downside, no specialization. The middle path.",
    icon: "👑",
    productionMult: 0.10,
    populationGrowthMult: 0.10,
    militaryMult: 0.10,
    scienceMult: 0.10,
    goldMult: 0.10,
    capsMult: 0.10,
  },
];

export const DIVINE_MASK_MAP: Record<string, DivineMaskDef> = Object.fromEntries(
  DIVINE_MASKS.map((m) => [m.id, m])
);

export const DIVINE_MASK_COUNT: number = DIVINE_MASKS.length;

// =====================================================================
// 3. Worship Polarities (5) — how mortals perceive the god (one active)
// =====================================================================

/**
 * A single Worship Polarity. The player picks exactly one per run; it
 * applies for the entire run. Where a Divine Mask shapes the god's
 * *identity*, the Worship Polarity shapes the *mortals' relationship* to
 * that identity — reverence, fear, wonder, ambition, or mystery.
 *
 * The polarity list intentionally reuses the names from `apotheosis.ts
 * WORSHIP_MODES` (Reverence / Fear / Wonder / Ambition / Mystery) because
 * Layer 8 is the apotheosis-era "Worship Modes" idea refined. Effects
 * overlap by design — a Divinity-layer god stacking "Fear polarity" on
 * top of "Fear worship mode" gets compounded bonuses.
 *
 * Effect field → consumer wiring:
 *   - `productionMult`         → additive all-production mult (Reverence +0.15, Mystery +0.10)
 *   - `populationGrowthMult`  → additive pop-growth mult
 *   - `militaryMult`          → additive military mult (Fear +0.25, Mystery +0.10)
 *   - `scienceMult`           → additive science mult (Wonder +0.20, Mystery +0.10)
 *   - `goldMult`              → additive gold mult (Ambition +0.25, Mystery +0.10)
 *   - `happinessFlat`         → flat per-tick happiness bonus (Wonder +10)
 *   - `happinessDrainMult`   → multiplicative happiness-drain multiplier (Fear 0.5 = half drain)
 *   - `heresyRateMult`        → additive mult on the heresy rate (Mystery -0.25 = 25% slower heresy)
 *
 * `happinessDrainMult` is multiplicative (0.5 = drain halved). `heresyRateMult`
 * is additive on the BASE_HERESY_RATE (matches the apotheosis.ts convention
 * for the same field). Mystery is the only polarity that touches the heresy
 * meter — "slower heresy" is its defining trait alongside the all-+10% spread.
 */
export interface WorshipPolarityDef {
  /** Stable identifier (matches `activePolarity` in GameState). */
  id: string;
  /** Human-readable polarity name. */
  name: string;
  /** Narrative / mechanical flavour of how mortals perceive the god. */
  desc: string;
  /** Emoji glyph shown on the polarity card. */
  icon: string;
  /** Additive all-production multiplier (Reverence +0.15, Mystery +0.10). */
  productionMult?: number;
  /** Additive population-growth multiplier. */
  populationGrowthMult?: number;
  /** Additive military-power multiplier (Fear +0.25, Mystery +0.10). */
  militaryMult?: number;
  /** Additive science multiplier (Wonder +0.20, Mystery +0.10). */
  scienceMult?: number;
  /** Additive gold multiplier (Ambition +0.25, Mystery +0.10). */
  goldMult?: number;
  /** Flat per-tick happiness bonus (Wonder +10). */
  happinessFlat?: number;
  /** Multiplicative happiness-drain multiplier (Fear 0.5 = half drain). */
  happinessDrainMult?: number;
  /** Additive multiplier on BASE_HERESY_RATE (Mystery: -0.25 = 25% slower heresy). */
  heresyRateMult?: number;
}

export const WORSHIP_POLARITIES: WorshipPolarityDef[] = [
  {
    id: "reverence",
    name: "Reverence",
    desc:
      "The faithful adore the god through gratitude and steady service. Production flows 15% " +
      "richer — the simplest and most sustaining polarity.",
    icon: "🙇",
    productionMult: 0.15,
  },
  {
    id: "fear",
    name: "Fear",
    desc:
      "The world obeys because it dreads divine judgment. +25% military; happiness drains half as " +
      "fast — a feared god is also a steady one.",
    icon: "😨",
    militaryMult: 0.25,
    happinessDrainMult: 0.5,
  },
  {
    id: "wonder",
    name: "Wonder",
    desc:
      "The god is marveled at more than obeyed. +20% science and happiness lifts by 10 — the " +
      "polarity of curiosity and awe.",
    icon: "🌟",
    scienceMult: 0.20,
    happinessFlat: 10,
  },
  {
    id: "ambition",
    name: "Ambition",
    desc:
      "Faith becomes a covenant of ascent. +25% gold and +10% production — the polarity of those " +
      "who worship what they hope to become.",
    icon: "💰",
    goldMult: 0.25,
    productionMult: 0.10,
  },
  {
    id: "mystery",
    name: "Mystery",
    desc:
      "The god hides behind signs and symbols. +10% to production, military, science, and gold — " +
      "and heresy spreads 25% slower, for what is hidden is harder to doubt.",
    icon: "🌫️",
    productionMult: 0.10,
    militaryMult: 0.10,
    scienceMult: 0.10,
    goldMult: 0.10,
    heresyRateMult: -0.25,
  },
];

export const WORSHIP_POLARITY_MAP: Record<string, WorshipPolarityDef> = Object.fromEntries(
  WORSHIP_POLARITIES.map((p) => [p.id, p])
);

export const WORSHIP_POLARITY_COUNT: number = WORSHIP_POLARITIES.length;

// =====================================================================
// Module-load sanity checks
// =====================================================================

/**
 * Validate the Divinity data at module load:
 *   - PRAYER_RATE_PER_POPULATION > 0 (must produce some prayer per pop).
 *   - DIVINITY_COMPLETION_CHANNELS_REQUIRED > 0 (must require some channels).
 *   - DIVINITY_COMPLETION_CHANNELS_REQUIRED ≤ PRAYER_CHANNEL_COUNT
 *     (must be satisfiable from the channel pool).
 *   - Exactly 6 Prayer Channels present.
 *   - All Prayer Channel ids are unique.
 *   - Each Prayer Channel sets at least one `*PerLevel` effect field.
 *   - Each Prayer Channel's `*PerLevel` values are > 0 (bonuses, never penalties).
 *   - Exactly 6 Divine Masks present.
 *   - All Divine Mask ids are unique.
 *   - Each Divine Mask sets at least one bonus field (upside required).
 *   - Each Divine Mask's mult fields are > 0 (signed; only happinessFlat
 *     may be negative, as a deliberate trade-off).
 *   - "sovereign" mask sets ALL six core mult fields (production / pop-
 *     growth / military / science / gold / caps) — its "all bonuses +10%"
 *     contract.
 *   - Exactly 5 Worship Polarities present.
 *   - All Worship Polarity ids are unique.
 *   - Each Worship Polarity sets at least one effect field.
 *   - Each Worship Polarity's mult fields (except happinessDrainMult /
 *     heresyRateMult, which are signed by design) are > 0.
 *   - "mystery" polarity sets at least 4 distinct mult fields AND a
 *     negative heresyRateMult (its "all +10%, slower heresy" contract).
 *
 * Throws on any violation (programmer error, not a runtime / save data
 * error). The check is O(N) and runs once at module import, so it's a
 * no-op on the hot path. Matches the pattern established by `apotheosis.ts`,
 * `singularity.ts`, `transcendence.ts`, `genesis.ts`, and `omnipotence.ts`.
 */
(function validateDivinityData(): void {
  if (PRAYER_RATE_PER_POPULATION <= 0) {
    throw new Error(
      `divinity_layer.ts: PRAYER_RATE_PER_POPULATION must be > 0 (got ${PRAYER_RATE_PER_POPULATION})`
    );
  }
  if (DIVINITY_COMPLETION_CHANNELS_REQUIRED <= 0) {
    throw new Error(
      `divinity_layer.ts: DIVINITY_COMPLETION_CHANNELS_REQUIRED must be > 0 (got ${DIVINITY_COMPLETION_CHANNELS_REQUIRED})`
    );
  }
  if (DIVINITY_COMPLETION_CHANNELS_REQUIRED > PRAYER_CHANNEL_COUNT) {
    throw new Error(
      `divinity_layer.ts: DIVINITY_COMPLETION_CHANNELS_REQUIRED (${DIVINITY_COMPLETION_CHANNELS_REQUIRED}) cannot exceed PRAYER_CHANNEL_COUNT (${PRAYER_CHANNEL_COUNT})`
    );
  }

  // ---- Prayer Channels ----
  if (PRAYER_CHANNEL_COUNT !== 6) {
    throw new Error(
      `divinity_layer.ts: expected exactly 6 prayer channels (got ${PRAYER_CHANNEL_COUNT})`
    );
  }
  const seenChannel = new Set<string>();
  for (const c of PRAYER_CHANNELS) {
    if (seenChannel.has(c.id)) {
      throw new Error(`divinity_layer.ts: duplicate prayer channel id "${c.id}"`);
    }
    seenChannel.add(c.id);

    const effectCount = [
      c.populationGrowthMultPerLevel,
      c.militaryMultPerLevel,
      c.scienceMultPerLevel,
      c.goldMultPerLevel,
      c.productionMultPerLevel,
      c.divinityPerSecPerLevel,
      c.happinessFlatPerLevel,
    ].filter((v) => v !== undefined).length;

    if (effectCount < 1) {
      throw new Error(
        `divinity_layer.ts: prayer channel "${c.id}" must set at least one *PerLevel effect field (set ${effectCount})`
      );
    }

    if (c.populationGrowthMultPerLevel !== undefined && c.populationGrowthMultPerLevel <= 0) {
      throw new Error(
        `divinity_layer.ts: prayer channel "${c.id}" populationGrowthMultPerLevel must be > 0 (got ${c.populationGrowthMultPerLevel})`
      );
    }
    if (c.militaryMultPerLevel !== undefined && c.militaryMultPerLevel <= 0) {
      throw new Error(
        `divinity_layer.ts: prayer channel "${c.id}" militaryMultPerLevel must be > 0 (got ${c.militaryMultPerLevel})`
      );
    }
    if (c.scienceMultPerLevel !== undefined && c.scienceMultPerLevel <= 0) {
      throw new Error(
        `divinity_layer.ts: prayer channel "${c.id}" scienceMultPerLevel must be > 0 (got ${c.scienceMultPerLevel})`
      );
    }
    if (c.goldMultPerLevel !== undefined && c.goldMultPerLevel <= 0) {
      throw new Error(
        `divinity_layer.ts: prayer channel "${c.id}" goldMultPerLevel must be > 0 (got ${c.goldMultPerLevel})`
      );
    }
    if (c.productionMultPerLevel !== undefined && c.productionMultPerLevel <= 0) {
      throw new Error(
        `divinity_layer.ts: prayer channel "${c.id}" productionMultPerLevel must be > 0 (got ${c.productionMultPerLevel})`
      );
    }
    if (c.divinityPerSecPerLevel !== undefined && c.divinityPerSecPerLevel <= 0) {
      throw new Error(
        `divinity_layer.ts: prayer channel "${c.id}" divinityPerSecPerLevel must be > 0 (got ${c.divinityPerSecPerLevel})`
      );
    }
    if (c.happinessFlatPerLevel !== undefined && c.happinessFlatPerLevel <= 0) {
      throw new Error(
        `divinity_layer.ts: prayer channel "${c.id}" happinessFlatPerLevel must be > 0 (got ${c.happinessFlatPerLevel})`
      );
    }
  }

  // ---- Divine Masks ----
  if (DIVINE_MASK_COUNT !== 6) {
    throw new Error(
      `divinity_layer.ts: expected exactly 6 divine masks (got ${DIVINE_MASK_COUNT})`
    );
  }
  const seenMask = new Set<string>();
  for (const m of DIVINE_MASKS) {
    if (seenMask.has(m.id)) {
      throw new Error(`divinity_layer.ts: duplicate divine mask id "${m.id}"`);
    }
    seenMask.add(m.id);

    const bonusCount = [
      m.productionMult,
      m.populationGrowthMult,
      m.militaryMult,
      m.scienceMult,
      m.goldMult,
      m.capsMult,
      m.divinityMult,
      m.happinessFlat,
    ].filter((v) => v !== undefined).length;

    if (bonusCount < 1) {
      throw new Error(
        `divinity_layer.ts: divine mask "${m.id}" must set at least one bonus field (set ${bonusCount})`
      );
    }

    // Mult fields must be > 0 (bonuses). Only `happinessFlat` may be
    // negative (signed trade-off — e.g. The Destroyer's -10).
    if (m.productionMult !== undefined && m.productionMult <= 0) {
      throw new Error(
        `divinity_layer.ts: divine mask "${m.id}" productionMult must be > 0 (got ${m.productionMult})`
      );
    }
    if (m.populationGrowthMult !== undefined && m.populationGrowthMult <= 0) {
      throw new Error(
        `divinity_layer.ts: divine mask "${m.id}" populationGrowthMult must be > 0 (got ${m.populationGrowthMult})`
      );
    }
    if (m.militaryMult !== undefined && m.militaryMult <= 0) {
      throw new Error(
        `divinity_layer.ts: divine mask "${m.id}" militaryMult must be > 0 (got ${m.militaryMult})`
      );
    }
    if (m.scienceMult !== undefined && m.scienceMult <= 0) {
      throw new Error(
        `divinity_layer.ts: divine mask "${m.id}" scienceMult must be > 0 (got ${m.scienceMult})`
      );
    }
    if (m.goldMult !== undefined && m.goldMult <= 0) {
      throw new Error(
        `divinity_layer.ts: divine mask "${m.id}" goldMult must be > 0 (got ${m.goldMult})`
      );
    }
    if (m.capsMult !== undefined && m.capsMult <= 0) {
      throw new Error(
        `divinity_layer.ts: divine mask "${m.id}" capsMult must be > 0 (got ${m.capsMult})`
      );
    }
    if (m.divinityMult !== undefined && m.divinityMult <= 0) {
      throw new Error(
        `divinity_layer.ts: divine mask "${m.id}" divinityMult must be > 0 (got ${m.divinityMult})`
      );
    }
    // happinessFlat may be negative (The Destroyer's -10 trade-off) — no sign check.
  }

  // Verify "sovereign" mask sets all six core mult fields (the "all
  // bonuses +10%, no downside" contract).
  const sovereign = DIVINE_MASK_MAP["sovereign"];
  if (!sovereign) {
    throw new Error(
      `divinity_layer.ts: divine masks must include "sovereign" (got [${DIVINE_MASKS.map((m) => m.id).join(", ")}])`
    );
  }
  const sovereignFields = [
    sovereign.productionMult,
    sovereign.populationGrowthMult,
    sovereign.militaryMult,
    sovereign.scienceMult,
    sovereign.goldMult,
    sovereign.capsMult,
  ];
  if (sovereignFields.some((v) => v === undefined || v <= 0)) {
    throw new Error(
      `divinity_layer.ts: "sovereign" mask must set all six core mult fields (production / pop-growth / military / science / gold / caps) — got ${JSON.stringify({
        productionMult: sovereign.productionMult,
        populationGrowthMult: sovereign.populationGrowthMult,
        militaryMult: sovereign.militaryMult,
        scienceMult: sovereign.scienceMult,
        goldMult: sovereign.goldMult,
        capsMult: sovereign.capsMult,
      })}`
    );
  }

  // ---- Worship Polarities ----
  if (WORSHIP_POLARITY_COUNT !== 5) {
    throw new Error(
      `divinity_layer.ts: expected exactly 5 worship polarities (got ${WORSHIP_POLARITY_COUNT})`
    );
  }
  const seenPolarity = new Set<string>();
  for (const p of WORSHIP_POLARITIES) {
    if (seenPolarity.has(p.id)) {
      throw new Error(`divinity_layer.ts: duplicate worship polarity id "${p.id}"`);
    }
    seenPolarity.add(p.id);

    const effectCount = [
      p.productionMult,
      p.populationGrowthMult,
      p.militaryMult,
      p.scienceMult,
      p.goldMult,
      p.happinessFlat,
      p.happinessDrainMult,
      p.heresyRateMult,
    ].filter((v) => v !== undefined).length;

    if (effectCount < 1) {
      throw new Error(
        `divinity_layer.ts: worship polarity "${p.id}" must set at least one effect field (set ${effectCount})`
      );
    }

    // Mult / flat bonus fields must be > 0 (bonuses). Only `happinessDrainMult`,
    // `heresyRateMult`, and `happinessFlat` may be signed by design.
    if (p.productionMult !== undefined && p.productionMult <= 0) {
      throw new Error(
        `divinity_layer.ts: worship polarity "${p.id}" productionMult must be > 0 (got ${p.productionMult})`
      );
    }
    if (p.populationGrowthMult !== undefined && p.populationGrowthMult <= 0) {
      throw new Error(
        `divinity_layer.ts: worship polarity "${p.id}" populationGrowthMult must be > 0 (got ${p.populationGrowthMult})`
      );
    }
    if (p.militaryMult !== undefined && p.militaryMult <= 0) {
      throw new Error(
        `divinity_layer.ts: worship polarity "${p.id}" militaryMult must be > 0 (got ${p.militaryMult})`
      );
    }
    if (p.scienceMult !== undefined && p.scienceMult <= 0) {
      throw new Error(
        `divinity_layer.ts: worship polarity "${p.id}" scienceMult must be > 0 (got ${p.scienceMult})`
      );
    }
    if (p.goldMult !== undefined && p.goldMult <= 0) {
      throw new Error(
        `divinity_layer.ts: worship polarity "${p.id}" goldMult must be > 0 (got ${p.goldMult})`
      );
    }
  }

  // Verify "mystery" polarity sets at least 4 distinct mult fields AND a
  // negative heresyRateMult (its "all +10%, slower heresy" contract).
  const mystery = WORSHIP_POLARITY_MAP["mystery"];
  if (!mystery) {
    throw new Error(
      `divinity_layer.ts: worship polarities must include "mystery" (got [${WORSHIP_POLARITIES.map((p) => p.id).join(", ")}])`
    );
  }
  const mysteryMultCount = [
    mystery.productionMult,
    mystery.militaryMult,
    mystery.scienceMult,
    mystery.goldMult,
  ].filter((v) => v !== undefined && v > 0).length;
  if (mysteryMultCount < 4) {
    throw new Error(
      `divinity_layer.ts: "mystery" polarity must set at least 4 mult fields (production / military / science / gold) — got ${mysteryMultCount}`
    );
  }
  if (mystery.heresyRateMult === undefined || mystery.heresyRateMult >= 0) {
    throw new Error(
      `divinity_layer.ts: "mystery" polarity must set a negative heresyRateMult (slower heresy) — got ${mystery.heresyRateMult}`
    );
  }
})();

// =====================================================================
// Helpers
// =====================================================================

/**
 * Aggregated bonus object returned by `prayerChannelBonus`.
 *
 * All mult fields are ADDITIVE on top of the baseline (0 = no change).
 * `divinityPerSec` is a flat per-second Divinity grant (not a mult).
 * `happinessFlat` is a flat per-tick (per-second) happiness bonus (signed,
 * but always positive in the current dataset). The consumer applies
 * these in the tick loop:
 *
 *   - `populationGrowthMult`:  multiply pop growth by `(1 + populationGrowthMult)`
 *   - `militaryMult`:         multiply military by `(1 + militaryMult)`
 *   - `scienceMult`:          multiply science by `(1 + scienceMult)`
 *   - `goldMult`:             multiply gold by `(1 + goldMult)`
 *   - `productionMult`:       multiply production by `(1 + productionMult)`
 *   - `divinityPerSec`:       add to `state.resources.divinity` per second
 *   - `happinessFlat`:         add to `state.resources.happiness` per second (subject to cap)
 *
 * Each field's value is the per-level effect × the channel's current
 * level, summed across all channels. For example, the Growth channel at
 * level 3 contributes `0.10 × 3 = 0.30` to `populationGrowthMult`.
 * Multiple channels contributing to the same field would sum their
 * contributions — but in the current dataset, each channel targets a
 * distinct field except Wealth (which targets BOTH gold and production).
 */
export interface PrayerChannelBonus {
  /** Additive population-growth multiplier (Growth channel × level × 0.10). */
  populationGrowthMult: number;
  /** Additive military-power multiplier (War channel × level × 0.15). */
  militaryMult: number;
  /** Additive science multiplier (Knowledge channel × level × 0.15). */
  scienceMult: number;
  /** Additive gold multiplier (Wealth channel × level × 0.15). */
  goldMult: number;
  /** Additive all-production multiplier (Wealth channel × level × 0.15). */
  productionMult: number;
  /** Flat Divinity per second (Faith channel × level × 0.01). */
  divinityPerSec: number;
  /** Flat per-tick happiness bonus (Harmony channel × level × 5). */
  happinessFlat: number;
}

/**
 * Sum the bonuses from all Prayer Channels at their current levels into a
 * single aggregate. Each channel's `*PerLevel` field is multiplied by the
 * channel's level (from the `channels` map) and added to the corresponding
 * result field.
 *
 * Used by the tick loop to compute per-resource multipliers, the Divinity/
 * sec grant, and the per-tick happiness bonus. The aggregate is recomputed
 * each tick (it's cheap — 6 entries) so the consumer doesn't need to
 * cache it.
 *
 * @param channels  Map of channel id → current level (0 / absent = unopened).
 * @returns Aggregated `PrayerChannelBonus` (all fields defaulted for empty input).
 *
 * @example
 *   prayerChannelBonus({})
 *     // → { populationGrowthMult:0, militaryMult:0, ..., divinityPerSec:0, happinessFlat:0 }
 *   prayerChannelBonus({ growth: 1 })
 *     // → { populationGrowthMult:0.10, ... }  (Growth level 1 = +10% pop growth)
 *   prayerChannelBonus({ growth: 3 })
 *     // → { populationGrowthMult:0.30, ... }  (Growth level 3 = +30% pop growth)
 *   prayerChannelBonus({ wealth: 2 })
 *     // → { goldMult:0.30, productionMult:0.30, ... }  (Wealth level 2 = +30% gold AND +30% production)
 *   prayerChannelBonus({ faith: 5 })
 *     // → { divinityPerSec:0.05, ... }  (Faith level 5 = +0.05 Divinity/s)
 *   prayerChannelBonus({ harmony: 4 })
 *     // → { happinessFlat:20, ... }  (Harmony level 4 = +20 happiness/s)
 *   prayerChannelBonus({ growth: 2, war: 1, faith: 3 })
 *     // → { populationGrowthMult:0.20, militaryMult:0.15, divinityPerSec:0.03, ... }
 *   prayerChannelBonus({ growth: 1, wealth: 1, harmony: 1 })
 *     // → { populationGrowthMult:0.10, goldMult:0.15, productionMult:0.15,
 *     //     happinessFlat:5, ... }
 *   prayerChannelBonus({ nonexistent: 5 })
 *     // → { all zeros }  (unknown channel id ignored)
 */
export function prayerChannelBonus(
  channels: Record<string, number>
): PrayerChannelBonus {
  const result: PrayerChannelBonus = {
    populationGrowthMult: 0,
    militaryMult: 0,
    scienceMult: 0,
    goldMult: 0,
    productionMult: 0,
    divinityPerSec: 0,
    happinessFlat: 0,
  };
  for (const channel of PRAYER_CHANNELS) {
    const level = channels[channel.id] ?? 0;
    if (level <= 0) continue;
    if (channel.populationGrowthMultPerLevel !== undefined) {
      result.populationGrowthMult += channel.populationGrowthMultPerLevel * level;
    }
    if (channel.militaryMultPerLevel !== undefined) {
      result.militaryMult += channel.militaryMultPerLevel * level;
    }
    if (channel.scienceMultPerLevel !== undefined) {
      result.scienceMult += channel.scienceMultPerLevel * level;
    }
    if (channel.goldMultPerLevel !== undefined) {
      result.goldMult += channel.goldMultPerLevel * level;
    }
    if (channel.productionMultPerLevel !== undefined) {
      result.productionMult += channel.productionMultPerLevel * level;
    }
    if (channel.divinityPerSecPerLevel !== undefined) {
      result.divinityPerSec += channel.divinityPerSecPerLevel * level;
    }
    if (channel.happinessFlatPerLevel !== undefined) {
      result.happinessFlat += channel.happinessFlatPerLevel * level;
    }
  }
  return result;
}

/**
 * Aggregated bonus object returned by `divineMaskBonus`.
 *
 * All mult fields are ADDITIVE on top of the baseline (0 = no change).
 * `divinityMult` is also additive on Divinity-gain modifiers — the
 * consumer multiplies all Divinity gains by `(1 + divinityMult)`.
 * `happinessFlat` is a signed flat per-tick happiness change (The
 * Destroyer applies -10/s; defaults to 0). The consumer applies these
 * in the tick loop:
 *
 *   - `productionMult`:        multiply production by `(1 + productionMult)`
 *   - `populationGrowthMult`:  multiply pop growth by `(1 + populationGrowthMult)`
 *   - `militaryMult`:          multiply military by `(1 + militaryMult)`
 *   - `scienceMult`:           multiply science by `(1 + scienceMult)`
 *   - `goldMult`:              multiply gold by `(1 + goldMult)`
 *   - `capsMult`:              multiply every resource cap by `(1 + capsMult)`
 *   - `divinityMult`:          multiply all Divinity gains by `(1 + divinityMult)`
 *   - `happinessFlat`:          add to `state.resources.happiness` per second (subject to floor 0)
 *
 * Only one mask can be active per run (`state.activeMask` is a single
 * id, not a set — mirrors the Worship Mode / Relic Loadout / Hybrid
 * Lineage "pick one" pattern from earlier layers). The aggregate is
 * just the active mask's stat fields passed through with defaults (0
 * for all fields, except `divinityMult` which defaults to 0 — not 1 —
 * because Divinity gains default to ×1.0 when no mask is active, and
 * `(1 + 0) = 1.0`).
 */
export interface DivineMaskBonus {
  /** Additive all-production multiplier (Creator +0.25, Sage +0.15, Sovereign +0.10). */
  productionMult: number;
  /** Additive population-growth multiplier (Preserver +0.20, Sovereign +0.10). */
  populationGrowthMult: number;
  /** Additive military-power multiplier (Destroyer +0.40, Sovereign +0.10). */
  militaryMult: number;
  /** Additive science multiplier (Trickster +0.30, Sovereign +0.10). */
  scienceMult: number;
  /** Additive gold multiplier (Trickster +0.20, Sovereign +0.10). */
  goldMult: number;
  /** Additive multiplier on every resource's cap (Creator +0.15, Preserver +0.30, Sovereign +0.10). */
  capsMult: number;
  /** Additive multiplier on all Divinity gains (Sage +0.50 = +50% Divinity). */
  divinityMult: number;
  /** Signed flat per-tick happiness change (Destroyer -10; defaults to 0). */
  happinessFlat: number;
}

/**
 * Return the active Divine Mask's bonuses as a single aggregate object.
 *
 * Only one mask can be active per run (`state.activeMask` is a single
 * id, not a set). The aggregate is just the active mask's stat fields
 * passed through with defaults (0 for all fields, including
 * `divinityMult` — see interface doc for the ×1.0 reasoning).
 *
 * Used by the tick loop to compute per-resource multipliers, cap
 * multipliers, the Divinity-gain multiplier, and the per-tick happiness
 * change.
 *
 * @param maskId  The active Divine Mask id, or `null` if none.
 * @returns Aggregated `DivineMaskBonus` (all fields defaulted for null / unknown input).
 *
 * @example
 *   divineMaskBonus(null)
 *     // → { productionMult:0, ..., divinityMult:0, happinessFlat:0 }
 *   divineMaskBonus("creator")
 *     // → { productionMult:0.25, capsMult:0.15, ..., divinityMult:0, happinessFlat:0 }
 *   divineMaskBonus("destroyer")
 *     // → { militaryMult:0.40, happinessFlat:-10, ..., divinityMult:0 }
 *   divineMaskBonus("sage")
 *     // → { productionMult:0.15, divinityMult:0.50, ..., happinessFlat:0 }
 *   divineMaskBonus("sovereign")
 *     // → { productionMult:0.10, populationGrowthMult:0.10, militaryMult:0.10,
 *     //     scienceMult:0.10, goldMult:0.10, capsMult:0.10,
 *     //     divinityMult:0, happinessFlat:0 }
 *   divineMaskBonus("nonexistent_id")
 *     // → { all defaults }  (unknown id treated as "no mask")
 */
export function divineMaskBonus(
  maskId: string | null
): DivineMaskBonus {
  const result: DivineMaskBonus = {
    productionMult: 0,
    populationGrowthMult: 0,
    militaryMult: 0,
    scienceMult: 0,
    goldMult: 0,
    capsMult: 0,
    divinityMult: 0,
    happinessFlat: 0,
  };
  if (!maskId) return result;
  const mask = DIVINE_MASK_MAP[maskId];
  if (!mask) return result;
  if (mask.productionMult !== undefined) result.productionMult = mask.productionMult;
  if (mask.populationGrowthMult !== undefined) result.populationGrowthMult = mask.populationGrowthMult;
  if (mask.militaryMult !== undefined) result.militaryMult = mask.militaryMult;
  if (mask.scienceMult !== undefined) result.scienceMult = mask.scienceMult;
  if (mask.goldMult !== undefined) result.goldMult = mask.goldMult;
  if (mask.capsMult !== undefined) result.capsMult = mask.capsMult;
  if (mask.divinityMult !== undefined) result.divinityMult = mask.divinityMult;
  if (mask.happinessFlat !== undefined) result.happinessFlat = mask.happinessFlat;
  return result;
}

/**
 * Aggregated bonus object returned by `worshipPolarityBonus`.
 *
 * All mult fields are ADDITIVE on top of the baseline (0 = no change).
 * `happinessFlat` is a flat per-tick happiness bonus (Wonder +10).
 * `happinessDrainMult` is MULTIPLICATIVE on happiness drain (Fear 0.5 =
 * drain halved; defaults to 1.0 = normal drain). `heresyRateMult` is
 * ADDITIVE on `BASE_HERESY_RATE` from apotheosis.ts (Mystery -0.25 =
 * 25% slower heresy; defaults to 0 = no change). The consumer applies
 * these in the tick loop:
 *
 *   - `productionMult`:        multiply production by `(1 + productionMult)`
 *   - `populationGrowthMult`:  multiply pop growth by `(1 + populationGrowthMult)`
 *   - `militaryMult`:          multiply military by `(1 + militaryMult)`
 *   - `scienceMult`:           multiply science by `(1 + scienceMult)`
 *   - `goldMult`:              multiply gold by `(1 + goldMult)`
 *   - `happinessFlat`:         add to `state.resources.happiness` per second (subject to cap)
 *   - `happinessDrainMult`:   multiply the happiness drain rate by this value (1.0 = normal)
 *   - `heresyRateMult`:        add to the additive mult on `BASE_HERESY_RATE`
 *
 * Only one polarity can be active per run (`state.activePolarity` is a
 * single id, not a set — mirrors the Divine Mask / Worship Mode "pick
 * one" pattern). The aggregate is just the active polarity's stat fields
 * passed through with defaults (0 for additive fields, 1.0 for
 * `happinessDrainMult` since it's multiplicative).
 */
export interface WorshipPolarityBonus {
  /** Additive all-production multiplier (Reverence +0.15, Mystery +0.10). */
  productionMult: number;
  /** Additive population-growth multiplier. */
  populationGrowthMult: number;
  /** Additive military-power multiplier (Fear +0.25, Mystery +0.10). */
  militaryMult: number;
  /** Additive science multiplier (Wonder +0.20, Mystery +0.10). */
  scienceMult: number;
  /** Additive gold multiplier (Ambition +0.25, Mystery +0.10). */
  goldMult: number;
  /** Flat per-tick happiness bonus (Wonder +10). */
  happinessFlat: number;
  /** Multiplicative happiness-drain multiplier (Fear 0.5 = half drain; defaults to 1.0). */
  happinessDrainMult: number;
  /** Additive multiplier on BASE_HERESY_RATE (Mystery: -0.25 = 25% slower heresy). */
  heresyRateMult: number;
}

/**
 * Return the active Worship Polarity's bonuses as a single aggregate
 * object.
 *
 * Only one polarity can be active per run (`state.activePolarity` is a
 * single id, not a set). The aggregate is just the active polarity's
 * stat fields passed through with defaults (0 for additive fields,
 * 1.0 for `happinessDrainMult` since the multiplicative identity is 1).
 *
 * Used by the tick loop to compute per-resource multipliers, the
 * per-tick happiness bonus, the happiness drain multiplier, and the
 * heresy-rate modifier.
 *
 * @param polarityId  The active Worship Polarity id, or `null` if none.
 * @returns Aggregated `WorshipPolarityBonus` (all fields defaulted for null / unknown input).
 *
 * @example
 *   worshipPolarityBonus(null)
 *     // → { productionMult:0, ..., happinessFlat:0, happinessDrainMult:1, heresyRateMult:0 }
 *   worshipPolarityBonus("reverence")
 *     // → { productionMult:0.15, ..., happinessDrainMult:1, heresyRateMult:0 }
 *   worshipPolarityBonus("fear")
 *     // → { militaryMult:0.25, happinessDrainMult:0.5, ..., heresyRateMult:0 }
 *   worshipPolarityBonus("wonder")
 *     // → { scienceMult:0.20, happinessFlat:10, ..., happinessDrainMult:1, heresyRateMult:0 }
 *   worshipPolarityBonus("ambition")
 *     // → { goldMult:0.25, productionMult:0.10, ..., happinessDrainMult:1, heresyRateMult:0 }
 *   worshipPolarityBonus("mystery")
 *     // → { productionMult:0.10, militaryMult:0.10, scienceMult:0.10, goldMult:0.10,
 *     //     ..., happinessDrainMult:1, heresyRateMult:-0.25 }
 *   worshipPolarityBonus("nonexistent_id")
 *     // → { all defaults, happinessDrainMult:1 }  (unknown id treated as "no polarity")
 */
export function worshipPolarityBonus(
  polarityId: string | null
): WorshipPolarityBonus {
  const result: WorshipPolarityBonus = {
    productionMult: 0,
    populationGrowthMult: 0,
    militaryMult: 0,
    scienceMult: 0,
    goldMult: 0,
    happinessFlat: 0,
    happinessDrainMult: 1, // multiplicative identity
    heresyRateMult: 0,
  };
  if (!polarityId) return result;
  const polarity = WORSHIP_POLARITY_MAP[polarityId];
  if (!polarity) return result;
  if (polarity.productionMult !== undefined) result.productionMult = polarity.productionMult;
  if (polarity.populationGrowthMult !== undefined) result.populationGrowthMult = polarity.populationGrowthMult;
  if (polarity.militaryMult !== undefined) result.militaryMult = polarity.militaryMult;
  if (polarity.scienceMult !== undefined) result.scienceMult = polarity.scienceMult;
  if (polarity.goldMult !== undefined) result.goldMult = polarity.goldMult;
  if (polarity.happinessFlat !== undefined) result.happinessFlat = polarity.happinessFlat;
  if (polarity.happinessDrainMult !== undefined) result.happinessDrainMult = polarity.happinessDrainMult;
  if (polarity.heresyRateMult !== undefined) result.heresyRateMult = polarity.heresyRateMult;
  return result;
}

/**
 * Compute the per-second prayer generation rate for the given population.
 *
 * Effective per-second prayer gain is
 * `population × PRAYER_RATE_PER_POPULATION` (default 0.001). The
 * consumer adds this to `state.prayer` each tick:
 *
 *   state.prayer += prayerRate(state.population) × dt;
 *
 * Negative populations (impossible, but defensive) return 0. A population
 * of 0 returns 0 (no faithful, no prayer).
 *
 * @param population  Current population (typically `state.population`).
 * @returns Per-second prayer gain (always >= 0).
 *
 * @example
 *   prayerRate(0)
 *     // → 0  (no population, no prayer)
 *   prayerRate(100)
 *     // → 0.1  (0.1 prayer/sec at 100 pop)
 *   prayerRate(1000)
 *     // → 1  (1 prayer/sec at 1,000 pop)
 *   prayerRate(10000)
 *     // → 10  (10 prayer/sec at 10,000 pop)
 *   prayerRate(-5)
 *     // → 0  (defensive: negative population clamped to 0)
 */
export function prayerRate(population: number): number {
  if (population <= 0) return 0;
  return population * PRAYER_RATE_PER_POPULATION;
}

/**
 * Whether the Layer 8 (Divinity) completion conditions are met.
 *
 * Conditions (both must be true):
 *   1. At least `DIVINITY_COMPLETION_CHANNELS_REQUIRED` (3) Prayer Channels
 *      are "opened" — i.e. have level >= 1 in the `channels` map.
 *   2. A Worship Polarity is aligned (`polarityId` is a non-null,
 *      recognized polarity id).
 *
 * Matches `prestigeLayers.ts divinity.completeState = "Open 3 Prayer
 * Channels and align Worship Polarity"`. Used by `triggerPrestige()`
 * to gate advancement to Layer 9 (Infinity).
 *
 * Note: opening a channel just means raising it to level >= 1 — the
 * spec wording "open" maps naturally to "has any level invested". A
 * channel at level 0 (or absent from the map) is "unopened". The
 * player can open all 6 channels; the completion check only requires 3.
 *
 * @param channels    Map of channel id → current level.
 * @param polarityId  The active Worship Polarity id, or `null` if none aligned.
 * @returns `true` if both conditions are met.
 *
 * @example
 *   isDivinityComplete({}, null)
 *     // → false  (no channels opened, no polarity aligned)
 *   isDivinityComplete({ growth: 1 }, null)
 *     // → false  (only 1 channel opened; no polarity aligned)
 *   isDivinityComplete({ growth: 1, war: 1, knowledge: 1 }, null)
 *     // → false  (3 channels but no polarity aligned)
 *   isDivinityComplete({}, "reverence")
 *     // → false  (polarity aligned but no channels opened)
 *   isDivinityComplete({ growth: 1 }, "reverence")
 *     // → false  (only 1 channel; polarity aligned)
 *   isDivinityComplete({ growth: 1, war: 1, knowledge: 1 }, "reverence")
 *     // → true  (3 channels + polarity aligned)
 *   isDivinityComplete({
 *     growth: 1, war: 1, knowledge: 1, wealth: 1, faith: 1, harmony: 1
 *   }, "mystery")
 *     // → true  (6 channels + polarity aligned — over-satisfied)
 *   isDivinityComplete({ growth: 1, war: 1, knowledge: 1 }, "nonexistent")
 *     // → false  (3 channels but unknown polarity id — treated as "no polarity")
 *   isDivinityComplete({ growth: 5, war: 0, knowledge: 1, wealth: 1 }, "reverence")
 *     // → true  (growth 5, knowledge 1, wealth 1 = 3 opened channels; "war" at level 0 is unopened)
 */
export function isDivinityComplete(
  channels: Record<string, number>,
  polarityId: string | null
): boolean {
  const openedCount = PRAYER_CHANNELS.filter((c) => {
    const level = channels[c.id] ?? 0;
    return level >= 1;
  }).length;
  const polarityAligned = polarityId !== null && WORSHIP_POLARITY_MAP[polarityId] !== undefined;
  return (
    openedCount >= DIVINITY_COMPLETION_CHANNELS_REQUIRED && polarityAligned
  );
}
