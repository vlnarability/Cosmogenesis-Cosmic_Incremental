// Infinity — Layer 9 prestige content
//
// When a god reaches Infinity it stops being a single civilization and
// becomes a curator of timelines. Completed runs leave behind Echoes that
// provide passive bonuses; Forks split decisions into two branches that
// each define a divergent run-long bonus; Future Debt lets the god borrow
// strength now and pay it back later — at compounding interest.
//
// Three mechanic families live in this file:
//
//   1. Echo Types (6)             — completed runs leave behind echoes that
//                                   provide passive bonuses. Each echo type
//                                   can be owned multiple times; the per-echo
//                                   bonus stacks linearly with the count
//                                   owned. Purchased with the Echoes currency
//                                   earned at Layer 9 prestige.
//   2. Fork Scenarios (4)         — split decisions that create two branches.
//                                   Each fork is resolved once per run by
//                                   picking branch A or B; the chosen branch
//                                   grants a run-long bonus. The Final
//                                   Divergence is the capstone fork: branch
//                                   B's "unlock a random divine law for free"
//                                   is dispatched by the consumer via the
//                                   `special` discriminated union.
//   3. Future Debt Tiers (4)       — borrow strength now, pay back later.
//                                   Each tier grants a production boost for
//                                   `boostDuration` seconds, then applies a
//                                   production penalty for `penaltyDuration`
//                                   seconds. Per-run limit caps how many
//                                   times a tier can be invoked per run.
//
// State fields (planned for GameState — to be wired in a follow-up task):
//   - echoesOwned:                Record<string, number>   // echo id → count owned (persistent across runs)
//   - echoes:                     number                    // current Echoes currency pool
//   - forksResolved:              Record<string, "A" | "B"> // fork id → chosen branch (per-run)
//   - activeFutureDebt:           string | null             // currently active debt tier id, or null
//   - futureDebtPhase:            "boost" | "penalty" | null  // current phase of the active debt
//   - futureDebtTimer:            number                    // seconds remaining in the current phase
//   - futureDebtUses:             Record<string, number>   // times each debt tier invoked this run
//   - futureDebtRepaid:           boolean                   // whether any debt has been fully repaid this run
//
// Reference: Infinity is new to the TS port — the vanilla JS had no
// Layer 9 content. The 6 / 4 / 4 spec, the echo bonus values, the fork
// branch magnitudes, and the future-debt durations come straight from
// the L9-data task spec. The Echoes currency is the Layer 9 prestige
// currency (the same `currency: "Infinity"` field on
// `prestigeLayers.ts infinity`); the Echo Type cost field is denominated
// in that currency.
//
// Advancement to Layer 10 (Eternity) requires forking a timeline AND
// repaying the resulting Future Debt — see prestigeLayers.ts
// `infinity.completeState: "Fork a timeline and repay the resulting
// Future Debt"`. See `isInfinityComplete` for the gating logic.

// =====================================================================
// Constants
// =====================================================================

/**
 * Number of Fork Scenarios the player must resolve for the Layer 9
 * completion check (`isInfinityComplete`). Matches the spec wording
 * "Fork a timeline and repay the resulting Future Debt" from
 * prestigeLayers.ts. The dataset defines 4 forks total, so this is a
 * quarter of the available pool — the minimum engagement to demonstrate
 * the player understands the divergence mechanic. Forks past the first
 * are optional mastery.
 */
export const INFINITY_COMPLETION_FORKS_REQUIRED: number = 1;

// =====================================================================
// 1. Echo Types (6) — completed runs leave behind echoes
// =====================================================================

/**
 * The per-echo bonus fields. Each echo type's `bonus` object can set any
 * subset of these; the consumer applies them additively (each owned copy
 * of the echo contributes its bonus once, summed via `echoBonus`).
 *
 * Effect field → consumer wiring:
 *   - `productionMult`         → additive all-production mult (Trade Echo +0.15)
 *   - `populationGrowthMult`   → additive pop-growth mult (Growth Echo +0.10)
 *   - `militaryMult`           → additive military mult (Conquest Echo +0.15)
 *   - `scienceMult`            → additive science mult (Science Echo +0.15)
 *   - `goldMult`               → additive gold mult (Trade Echo +0.15)
 *   - `capsMult`               → additive mult on every resource cap (Stability Echo +0.10)
 *   - `happinessFlat`          → flat per-tick happiness bonus (Stability Echo +10)
 *   - `divinityPerSec`         → flat per-second Divinity grant (Faith Echo +0.02)
 *
 * All mult fields are additive on top of the baseline (0 = no change).
 * `happinessFlat` is a signed flat per-tick grant (Stability Echo's +10
 * is positive; defaults to 0). `divinityPerSec` is a flat per-second
 * grant added directly to `state.resources.divinity` (Faith Echo's +0.02
 * produces 0.02 Divinity/s per copy owned; 5 copies → 0.1 Divinity/s).
 *
 * The `epMult` field is intentionally absent here — Echoes grant
 * production / growth / military / science / gold / caps / happiness /
 * Divinity, NOT evolution-point multipliers. EP multipliers are
 * exclusive to The Final Divergence fork (see `ForkBranchDef`).
 */
export interface EchoBonusFields {
  /** Additive all-production multiplier (0.15 = +15% all production). */
  productionMult?: number;
  /** Additive population-growth multiplier (0.10 = +10% pop growth). */
  populationGrowthMult?: number;
  /** Additive military-power multiplier (0.15 = +15% military). */
  militaryMult?: number;
  /** Additive science multiplier (0.15 = +15% science). */
  scienceMult?: number;
  /** Additive gold multiplier (0.15 = +15% gold). */
  goldMult?: number;
  /** Additive multiplier on every resource's cap (0.10 = +10% caps). */
  capsMult?: number;
  /** Flat per-tick happiness bonus (signed; +10 = +10 happiness/s). */
  happinessFlat?: number;
  /** Flat Divinity generated per second (+0.02 = +0.02 Divinity/s). */
  divinityPerSec?: number;
}

/**
 * A single Echo Type. Each echo can be owned multiple times — the
 * `echoesOwned` map (persistent across runs, see file header) records
 * the count per echo id. The `bonus` object is applied once per owned
 * copy (5 Growth Echoes → +50% pop growth via `echoBonus`).
 *
 * The `cost` is denominated in the Echoes currency (the Layer 9
 * prestige currency). The wiring task will decide the exact purchase
 * curve — typically each subsequent copy of an echo costs more (e.g.
 * `cost × (1 + count_owned)`), but that scaling is in the store, not
 * here. The base `cost` field is the first-copy price.
 *
 * Echo Types are intentionally NOT mutually exclusive — the player can
 * own all six simultaneously, and the bonuses stack additively across
 * types (Growth + Science + Conquest + Trade + Stability + Faith is a
 * valid end-game echo loadout). This mirrors the per-channel leveling
 * pattern in `divinity_layer.ts` (all six Prayer Channels can be
 * opened) rather than the pick-one pattern in `apotheosis.ts
 * WORSHIP_MODES`.
 */
export interface EchoTypeDef {
  /** Stable identifier (used as a key in `echoesOwned` in GameState). */
  id: string;
  /** Human-readable echo name. */
  name: string;
  /** Narrative / mechanical flavour describing what the echo reverberates with. */
  desc: string;
  /** Emoji glyph shown on the echo card. */
  icon: string;
  /** Per-echo bonus object (applied once per owned copy). */
  bonus: EchoBonusFields;
  /** Echoes currency cost for the first copy (subsequent copies may scale — see file header). */
  cost: number;
}

export const ECHO_TYPES: EchoTypeDef[] = [
  {
    id: "growth_echo",
    name: "Growth Echo",
    desc:
      "A run that boomed leaves a hum of vitality. Every copy grants +10% population growth — the " +
      "echo of births rippling forward through time.",
    icon: "🌱",
    bonus: {
      populationGrowthMult: 0.10,
    },
    cost: 5,
  },
  {
    id: "science_echo",
    name: "Science Echo",
    desc:
      "A run that sought knowledge leaves a lingering inquiry. Every copy grants +15% science — " +
      "the echo of curiosity compounding across timelines.",
    icon: "🔬",
    bonus: {
      scienceMult: 0.15,
    },
    cost: 6,
  },
  {
    id: "conquest_echo",
    name: "Conquest Echo",
    desc:
      "A run that warred leaves a drumbeat of arms. Every copy grants +15% military power — the " +
      "echo of banners raised and lowered across ages.",
    icon: "⚔️",
    bonus: {
      militaryMult: 0.15,
    },
    cost: 6,
  },
  {
    id: "trade_echo",
    name: "Trade Echo",
    desc:
      "A run that prospered leaves the chime of coin on coin. Every copy grants +15% gold AND +15% " +
      "production — the echo of commerce echoing through every market it ever touched.",
    icon: "🪙",
    bonus: {
      goldMult: 0.15,
      productionMult: 0.15,
    },
    cost: 8,
  },
  {
    id: "stability_echo",
    name: "Stability Echo",
    desc:
      "A run at peace leaves a deep calm. Every copy grants +10 happiness per tick AND widens every " +
      "cap by 10% — the echo of a civilization that never broke.",
    icon: "⚖️",
    bonus: {
      happinessFlat: 10,
      capsMult: 0.10,
    },
    cost: 7,
  },
  {
    id: "faith_echo",
    name: "Faith Echo",
    desc:
      "A run that believed leaves a quiet prayer on the wind. Every copy generates +0.02 Divinity per " +
      "second — the echo of worship, still rising long after the temple fell.",
    icon: "🙏",
    bonus: {
      divinityPerSec: 0.02,
    },
    cost: 9,
  },
];

export const ECHO_MAP: Record<string, EchoTypeDef> = Object.fromEntries(
  ECHO_TYPES.map((e) => [e.id, e])
);

export const ECHO_TYPE_COUNT: number = ECHO_TYPES.length;

// =====================================================================
// 2. Fork Scenarios (4) — split decisions that create two branches
// =====================================================================

/**
 * Discriminated union of fork "special interaction" behaviors. Most
 * fork branches grant a flat stat bonus (production / growth / military
 * / science / gold / caps / ep multipliers); a few instead (or also)
 * dispatch a one-time special action handled by the consumer.
 *
 * Known variants:
 *
 *   - `unlock_random_divine_law`   The Final Divergence branch B
 *                                   (unlocks a random divine law for free,
 *                                   bypassing its Divinity cost).
 */
export type ForkSpecial =
  /** Unlock a random Divine Law from apotheosis.ts for free (Divinity cost waived).
   *  The consumer picks one codifiable law at random (or from the
   *  player's preferred pool) and codifies it instantly. */
  | { kind: "unlock_random_divine_law" };

/**
 * A single branch of a fork scenario. Each fork has exactly two
 * branches — `branchA` and `branchB` — and the player picks one per run
 * (the chosen branch's bonus applies for the rest of the run). The
 * `label` is a short identifier shown on the fork card; `desc` is
 * optional narrative flavour.
 *
 * Effect field → consumer wiring:
 *   - `productionMult`         → additive all-production mult
 *   - `populationGrowthMult`   → additive pop-growth mult
 *   - `militaryMult`           → additive military mult
 *   - `scienceMult`             → additive science mult
 *   - `goldMult`                → additive gold mult
 *   - `capsMult`                → additive mult on every resource cap
 *   - `epMult`                  → additive evolution-points multiplier
 *                                 (exclusive to The Final Divergence branch A)
 *   - `special`                 → discriminated union dispatched by the
 *                                 consumer (see `ForkSpecial`)
 *
 * `epMult` is the only field not shared with `EchoBonusFields` — Echoes
 * never boost EP gain; only The Final Divergence fork can. This keeps
 * the EP economy gated behind a single, deliberate late-run decision
 * (matching the spec wording "choose between +100% EP OR unlock a
 * random divine law for free").
 *
 * At least one of the bonus fields or `special` must be set on each
 * branch (enforced by the IIFE validator). Most branches set exactly
 * one bonus field for a clean read; Crossroads of Evolution's branchA
 * and branchB each set one; The Final Divergence's branchB sets ONLY
 * `special` (the unlock action is its entire effect).
 */
export interface ForkBranchDef {
  /** Short label shown on the fork card (e.g. "Production Path"). */
  label: string;
  /** Optional narrative flavour for the branch (e.g. what the choice means). */
  desc?: string;
  /** Additive all-production multiplier (0.50 = +50% all production). */
  productionMult?: number;
  /** Additive population-growth multiplier (0.50 = +50% pop growth). */
  populationGrowthMult?: number;
  /** Additive military-power multiplier (0.40 = +40% military). */
  militaryMult?: number;
  /** Additive science multiplier (0.40 = +40% science). */
  scienceMult?: number;
  /** Additive gold multiplier. */
  goldMult?: number;
  /** Additive multiplier on every resource's cap (0.30 = +30% caps). */
  capsMult?: number;
  /** Additive Evolution Points multiplier (1.0 = +100% EP gain). Exclusive to The Final Divergence branch A. */
  epMult?: number;
  /** Optional special interaction (see `ForkSpecial`). */
  special?: ForkSpecial;
}

/**
 * A single Fork Scenario. Each fork is resolved once per run by picking
 * branch A or B (stored in `forksResolved[forkId]` in GameState). The
 * chosen branch's bonuses apply for the rest of the run via
 * `forkBonus(forkId, branch)`.
 *
 * Fork scenarios are NOT mutually exclusive with each other — the
 * player can resolve all 4 in a single run (the spec wording "split
 * decisions that create two branches" describes the within-fork
 * dichotomy, not a between-fork constraint). Each fork contributes its
 * chosen branch's bonuses to the aggregate.
 *
 * The four forks are deliberately ordered to escalate in scope and
 * consequence:
 *   - Crossroads of Evolution  — early-game fork over production vs growth
 *   - The Great Schism         — mid-game fork over military vs science
 *   - Realm of Mirrors         — late-game fork over caps vs all-production
 *   - The Final Divergence     — capstone fork over EP vs a free divine law
 */
export interface ForkScenarioDef {
  /** Stable identifier (used as a key in `forksResolved` in GameState). */
  id: string;
  /** Human-readable fork name. */
  name: string;
  /** Narrative / mechanical flavour describing the divergence and its stakes. */
  desc: string;
  /** Emoji glyph shown on the fork card. */
  icon: string;
  /** The first branch option. */
  branchA: ForkBranchDef;
  /** The second branch option. */
  branchB: ForkBranchDef;
}

export const FORK_SCENARIOS: ForkScenarioDef[] = [
  {
    id: "crossroads_of_evolution",
    name: "Crossroads of Evolution",
    desc:
      "The run reaches a fork in its evolutionary path. Choose: bend every system toward " +
      "production, or toward population growth — the choice holds for the rest of the run.",
    icon: "🛤️",
    branchA: {
      label: "Production Path",
      desc: "Machinery and metabolism align. All production flows 50% richer for the rest of the run.",
      productionMult: 0.50,
    },
    branchB: {
      label: "Growth Path",
      desc: "Every seed and womb quickens. Population grows 50% faster for the rest of the run.",
      populationGrowthMult: 0.50,
    },
  },
  {
    id: "the_great_schism",
    name: "The Great Schism",
    desc:
      "A fracture runs through the heart of the run. Choose: arm the faithful, or arm the " +
      "scholars — the choice holds for the rest of the run.",
    icon: "⚡",
    branchA: {
      label: "Sword Path",
      desc: "Military power surges 40% — the run becomes a campaign of conquest.",
      militaryMult: 0.40,
    },
    branchB: {
      label: "Tome Path",
      desc: "Science flows 40% richer — the run becomes a campaign of inquiry.",
      scienceMult: 0.40,
    },
  },
  {
    id: "realm_of_mirrors",
    name: "Realm of Mirrors",
    desc:
      "Two reflections of the run shimmer side by side. Choose: stretch the boundaries of " +
      "what can be held, or amplify everything that flows through them — for the rest of the run.",
    icon: "🪞",
    branchA: {
      label: "Vast Path",
      desc: "Every cap widens by 30% — the world holds more of everything it can become.",
      capsMult: 0.30,
    },
    branchB: {
      label: "Deep Path",
      desc: "All production flows 30% richer — what already runs runs deeper.",
      productionMult: 0.30,
    },
  },
  {
    id: "the_final_divergence",
    name: "The Final Divergence",
    desc:
      "The last fork before the run closes. Choose: bend the cosmos to double Evolution Point " +
      "gains, OR unlock a random Divine Law for free — the capstone divergence of a curator god.",
    icon: "🌟",
    branchA: {
      label: "Bounty Path",
      desc: "Evolution Point gains double (+100% EP) — every prestige this run reaps twice the harvest.",
      epMult: 1.0,
    },
    branchB: {
      label: "Revelation Path",
      desc: "A Divine Law reveals itself unbidden — codified for free, its Divinity cost waived.",
      special: { kind: "unlock_random_divine_law" },
    },
  },
];

export const FORK_MAP: Record<string, ForkScenarioDef> = Object.fromEntries(
  FORK_SCENARIOS.map((f) => [f.id, f])
);

export const FORK_SCENARIO_COUNT: number = FORK_SCENARIOS.length;

// =====================================================================
// 3. Future Debt Tiers (4) — borrow strength now, pay back later
// =====================================================================

/**
 * A single Future Debt tier. Invoking a debt tier grants a temporary
 * production boost (`boostMult`, additive on production) for
 * `boostDuration` seconds, then immediately applies a production
 * penalty (`penaltyMult`, additive — typically negative) for
 * `penaltyDuration` seconds. The player may invoke a tier up to
 * `perRunLimit` times per run.
 *
 * Effect field → consumer wiring:
 *   - `boostMult`         → during the boost phase, multiply production
 *                            by `(1 + boostMult)` (e.g. +0.50 = ×1.5)
 *   - `boostDuration`     → seconds the boost phase lasts
 *   - `penaltyMult`       → during the penalty phase, multiply
 *                            production by `(1 + penaltyMult)` (e.g.
 *                            -0.25 = ×0.75). Always negative.
 *   - `penaltyDuration`   → seconds the penalty phase lasts
 *   - `perRunLimit`       → max times this tier can be invoked per run
 *
 * The interest curve is intentionally punishing: each tier's penalty
 * duration grows faster than its boost duration, and the penalty
 * multiplier approaches -1.0 (production halted). Critical Debt's
 * -90% for 600s is a near-run-ending penalty — the god pays dearly for
 * the +500% burst. This makes Future Debt a "panic button" rather than
 * a routine accelerator.
 *
 * The completion check (`isInfinityComplete`) requires that at least
 * one debt has been fully repaid — meaning the player has survived a
 * complete boost + penalty cycle without resetting. This proves the
 * god can carry the weight of borrowed power.
 *
 * The tier progression:
 *   - Minor:     +50% for 120s, then -25% for 120s  (1:1 ratio, mild)
 *   - Moderate:  +100% for 120s, then -50% for 180s (1:1.5 ratio, sharp)
 *   - Severe:    +200% for 120s, then -75% for 300s (1:2.5 ratio, harsh)
 *   - Critical:  +500% for 60s, then -90% for 600s  (1:10 ratio, brutal)
 *
 * Per-run limits are inversely scaled to power: Minor can be invoked
 * 5× per run; Critical only once. This prevents stacking Critical
 * Debt boosts back-to-back to skip the penalty phase entirely.
 */
export interface FutureDebtTierDef {
  /** Stable identifier (used as a key in `futureDebtUses` in GameState). */
  id: string;
  /** Human-readable debt tier name. */
  name: string;
  /** Narrative / mechanical flavour describing the bargain and its cost. */
  desc: string;
  /** Emoji glyph shown on the debt card. */
  icon: string;
  /** Additive production multiplier during the boost phase (0.50 = +50% production). */
  boostMult: number;
  /** Duration of the boost phase in seconds. */
  boostDuration: number;
  /** Additive production multiplier during the penalty phase (-0.25 = -25% production). Always negative. */
  penaltyMult: number;
  /** Duration of the penalty phase in seconds. */
  penaltyDuration: number;
  /** Maximum times this tier can be invoked per run. */
  perRunLimit: number;
}

export const FUTURE_DEBT_TIERS: FutureDebtTierDef[] = [
  {
    id: "minor_debt",
    name: "Minor Debt",
    desc:
      "A small borrowing against the future. Production surges 50% for 120 seconds — then dips 25% " +
      "below baseline for another 120 seconds as the ledger rebalances. The gentlest bargain available.",
    icon: "💸",
    boostMult: 0.50,
    boostDuration: 120,
    penaltyMult: -0.25,
    penaltyDuration: 120,
    perRunLimit: 5,
  },
  {
    id: "moderate_debt",
    name: "Moderate Debt",
    desc:
      "A meaningful borrowing. Production doubles (+100%) for 120 seconds — then halves by half " +
      "(-50%) for 180 seconds as the interest compounds. A sharp bargain.",
    icon: "💰",
    boostMult: 1.00,
    boostDuration: 120,
    penaltyMult: -0.50,
    penaltyDuration: 180,
    perRunLimit: 3,
  },
  {
    id: "severe_debt",
    name: "Severe Debt",
    desc:
      "A heavy borrowing against what little remains. Production triples (+200%) for 120 seconds — " +
      "then withers by 75% for 300 seconds. The run bends under the weight of repayment.",
    icon: "🏦",
    boostMult: 2.00,
    boostDuration: 120,
    penaltyMult: -0.75,
    penaltyDuration: 300,
    perRunLimit: 2,
  },
  {
    id: "critical_debt",
    name: "Critical Debt",
    desc:
      "A borrowing that borders on sacrilege. Production quintuples (+500%) for 60 seconds — then " +
      "collapses by 90% for 600 seconds. The god drinks deep, and the world pays for ten minutes.",
    icon: "⚠️",
    boostMult: 5.00,
    boostDuration: 60,
    penaltyMult: -0.90,
    penaltyDuration: 600,
    perRunLimit: 1,
  },
];

export const FUTURE_DEBT_MAP: Record<string, FutureDebtTierDef> = Object.fromEntries(
  FUTURE_DEBT_TIERS.map((d) => [d.id, d])
);

export const FUTURE_DEBT_TIER_COUNT: number = FUTURE_DEBT_TIERS.length;

// =====================================================================
// Module-load sanity checks
// =====================================================================

/**
 * Validate the infinity data at module load:
 *   - INFINITY_COMPLETION_FORKS_REQUIRED >= 1.
 *   - All echo type ids are unique.
 *   - Each echo has cost >= 0.
 *   - Each echo's `bonus` object sets at least one field.
 *   - All mult fields on echoes (if set) are > 0 (echoes grant bonuses,
 *     never penalties — `happinessFlat` and `divinityPerSec` are also
 *     expected to be positive for an echo; negative values would make
 *     an echo a curse, not an echo).
 *   - All fork scenario ids are unique.
 *   - Each fork's branchA and branchB each set at least one bonus
 *     field OR a `special` (the XOR-style "the branch has SOME effect"
 *     check). Branches with both a bonus field AND a special are
 *     allowed but currently unused in the dataset.
 *   - All mult fields on fork branches (if set) are > 0 (branches
 *     grant bonuses; penalties live on Future Debt, not forks).
 *   - All future debt tier ids are unique.
 *   - Each debt tier has boostMult > 0 (the whole point of debt is to
 *     borrow strength).
 *   - Each debt tier has boostDuration > 0 and penaltyDuration > 0.
 *   - Each debt tier has penaltyMult < 0 (a penalty that's >= 0 would
 *     make the debt free).
 *   - Each debt tier has perRunLimit >= 1.
 *
 * Throws on any violation (programmer error, not a runtime / save data
 * error). The check is O(N) and runs once at module import, so it's a
 * no-op on the hot path. Matches the pattern established by
 * `apotheosis.ts`, `singularity.ts`, `omnipotence.ts`, and
 * `divinity_layer.ts`.
 */
(function validateInfinityData(): void {
  if (INFINITY_COMPLETION_FORKS_REQUIRED < 1) {
    throw new Error(
      `infinity.ts: INFINITY_COMPLETION_FORKS_REQUIRED must be >= 1 (got ${INFINITY_COMPLETION_FORKS_REQUIRED})`
    );
  }

  // ---- Echo types ----
  const seenEcho = new Set<string>();
  for (const e of ECHO_TYPES) {
    if (seenEcho.has(e.id)) {
      throw new Error(`infinity.ts: duplicate echo type id "${e.id}"`);
    }
    seenEcho.add(e.id);

    if (e.cost < 0) {
      throw new Error(`infinity.ts: echo "${e.id}" has negative cost (${e.cost})`);
    }

    const b = e.bonus;
    const effectCount = [
      b.productionMult !== undefined,
      b.populationGrowthMult !== undefined,
      b.militaryMult !== undefined,
      b.scienceMult !== undefined,
      b.goldMult !== undefined,
      b.capsMult !== undefined,
      b.happinessFlat !== undefined,
      b.divinityPerSec !== undefined,
    ].filter(Boolean).length;
    if (effectCount < 1) {
      throw new Error(
        `infinity.ts: echo "${e.id}" bonus must set at least one effect (set ${effectCount})`
      );
    }

    // Echo bonuses must be strictly positive — an echo is a passive bonus,
    // not a curse. Negative values would invert the design intent.
    if (b.productionMult !== undefined && b.productionMult <= 0) {
      throw new Error(
        `infinity.ts: echo "${e.id}" productionMult must be > 0 (got ${b.productionMult})`
      );
    }
    if (b.populationGrowthMult !== undefined && b.populationGrowthMult <= 0) {
      throw new Error(
        `infinity.ts: echo "${e.id}" populationGrowthMult must be > 0 (got ${b.populationGrowthMult})`
      );
    }
    if (b.militaryMult !== undefined && b.militaryMult <= 0) {
      throw new Error(
        `infinity.ts: echo "${e.id}" militaryMult must be > 0 (got ${b.militaryMult})`
      );
    }
    if (b.scienceMult !== undefined && b.scienceMult <= 0) {
      throw new Error(
        `infinity.ts: echo "${e.id}" scienceMult must be > 0 (got ${b.scienceMult})`
      );
    }
    if (b.goldMult !== undefined && b.goldMult <= 0) {
      throw new Error(
        `infinity.ts: echo "${e.id}" goldMult must be > 0 (got ${b.goldMult})`
      );
    }
    if (b.capsMult !== undefined && b.capsMult <= 0) {
      throw new Error(
        `infinity.ts: echo "${e.id}" capsMult must be > 0 (got ${b.capsMult})`
      );
    }
    if (b.happinessFlat !== undefined && b.happinessFlat <= 0) {
      throw new Error(
        `infinity.ts: echo "${e.id}" happinessFlat must be > 0 (got ${b.happinessFlat})`
      );
    }
    if (b.divinityPerSec !== undefined && b.divinityPerSec <= 0) {
      throw new Error(
        `infinity.ts: echo "${e.id}" divinityPerSec must be > 0 (got ${b.divinityPerSec})`
      );
    }
  }

  // ---- Fork scenarios ----
  const seenFork = new Set<string>();
  for (const f of FORK_SCENARIOS) {
    if (seenFork.has(f.id)) {
      throw new Error(`infinity.ts: duplicate fork scenario id "${f.id}"`);
    }
    seenFork.add(f.id);

    for (const branchKey of ["branchA", "branchB"] as const) {
      const branch = f[branchKey];
      if (!branch.label || branch.label.length === 0) {
        throw new Error(
          `infinity.ts: fork "${f.id}" ${branchKey} must have a non-empty label`
        );
      }

      const bonusCount = [
        branch.productionMult !== undefined,
        branch.populationGrowthMult !== undefined,
        branch.militaryMult !== undefined,
        branch.scienceMult !== undefined,
        branch.goldMult !== undefined,
        branch.capsMult !== undefined,
        branch.epMult !== undefined,
      ].filter(Boolean).length;

      if (bonusCount < 1 && branch.special === undefined) {
        throw new Error(
          `infinity.ts: fork "${f.id}" ${branchKey} must set at least one bonus field OR a special ` +
          `(set ${bonusCount} bonuses, special=${branch.special === undefined ? "none" : "set"})`
        );
      }

      // Branch bonuses must be strictly positive — branches grant bonuses,
      // never penalties. Penalties live on Future Debt, not forks.
      if (branch.productionMult !== undefined && branch.productionMult <= 0) {
        throw new Error(
          `infinity.ts: fork "${f.id}" ${branchKey}.productionMult must be > 0 (got ${branch.productionMult})`
        );
      }
      if (branch.populationGrowthMult !== undefined && branch.populationGrowthMult <= 0) {
        throw new Error(
          `infinity.ts: fork "${f.id}" ${branchKey}.populationGrowthMult must be > 0 (got ${branch.populationGrowthMult})`
        );
      }
      if (branch.militaryMult !== undefined && branch.militaryMult <= 0) {
        throw new Error(
          `infinity.ts: fork "${f.id}" ${branchKey}.militaryMult must be > 0 (got ${branch.militaryMult})`
        );
      }
      if (branch.scienceMult !== undefined && branch.scienceMult <= 0) {
        throw new Error(
          `infinity.ts: fork "${f.id}" ${branchKey}.scienceMult must be > 0 (got ${branch.scienceMult})`
        );
      }
      if (branch.goldMult !== undefined && branch.goldMult <= 0) {
        throw new Error(
          `infinity.ts: fork "${f.id}" ${branchKey}.goldMult must be > 0 (got ${branch.goldMult})`
        );
      }
      if (branch.capsMult !== undefined && branch.capsMult <= 0) {
        throw new Error(
          `infinity.ts: fork "${f.id}" ${branchKey}.capsMult must be > 0 (got ${branch.capsMult})`
        );
      }
      if (branch.epMult !== undefined && branch.epMult <= 0) {
        throw new Error(
          `infinity.ts: fork "${f.id}" ${branchKey}.epMult must be > 0 (got ${branch.epMult})`
        );
      }

      // Validate the special's shape (exhaustive over the union).
      if (branch.special !== undefined) {
        switch (branch.special.kind) {
          case "unlock_random_divine_law":
            // No parameters to validate.
            break;
          // No default — exhaustiveness enforced by TypeScript's discriminated union check.
        }
      }
    }
  }

  // ---- Future debt tiers ----
  const seenDebt = new Set<string>();
  for (const d of FUTURE_DEBT_TIERS) {
    if (seenDebt.has(d.id)) {
      throw new Error(`infinity.ts: duplicate future debt tier id "${d.id}"`);
    }
    seenDebt.add(d.id);

    if (d.boostMult <= 0) {
      throw new Error(
        `infinity.ts: future debt "${d.id}" boostMult must be > 0 (got ${d.boostMult})`
      );
    }
    if (d.boostDuration <= 0) {
      throw new Error(
        `infinity.ts: future debt "${d.id}" boostDuration must be > 0 (got ${d.boostDuration})`
      );
    }
    if (d.penaltyMult >= 0) {
      throw new Error(
        `infinity.ts: future debt "${d.id}" penaltyMult must be < 0 (got ${d.penaltyMult})`
      );
    }
    if (d.penaltyDuration <= 0) {
      throw new Error(
        `infinity.ts: future debt "${d.id}" penaltyDuration must be > 0 (got ${d.penaltyDuration})`
      );
    }
    if (d.perRunLimit < 1) {
      throw new Error(
        `infinity.ts: future debt "${d.id}" perRunLimit must be >= 1 (got ${d.perRunLimit})`
      );
    }
  }
})();

// =====================================================================
// Helpers
// =====================================================================

/**
 * Aggregated bonus object returned by `echoBonus`.
 *
 * All mult fields are additive on top of the baseline (0 = no change).
 * The consumer applies these in the tick loop:
 *
 *   - `productionMult`:        multiply production by `(1 + productionMult)`
 *   - `populationGrowthMult`:  multiply pop growth by `(1 + populationGrowthMult)`
 *   - `militaryMult`:         multiply military by `(1 + militaryMult)`
 *   - `scienceMult`:          multiply science by `(1 + scienceMult)`
 *   - `goldMult`:             multiply gold by `(1 + goldMult)`
 *   - `capsMult`:             multiply every resource cap by `(1 + capsMult)`
 *   - `happinessFlat`:        add to `state.resources.happiness` per tick
 *   - `divinityPerSec`:       add to `state.resources.divinity` per second
 *
 * Each owned echo copy contributes its `bonus` fields once; the
 * aggregate sums them all. With 5 Growth Echoes owned, the aggregate's
 * `populationGrowthMult` is `5 × 0.10 = 0.50` (+50% pop growth).
 *
 * Echoes are persistent across runs (the spec wording "completed runs
 * leave behind echoes that provide passive bonuses" implies they
 * carry forward — the `echoesOwned` map is part of the persistent
 * GameState, not the per-run state). The aggregate is recomputed each
 * tick (it's cheap — 6 entries) so the consumer doesn't need to cache
 * it.
 */
export interface EchoBonus {
  /** Additive all-production multiplier (Trade Echo × count × 0.15). */
  productionMult: number;
  /** Additive population-growth multiplier (Growth Echo × count × 0.10). */
  populationGrowthMult: number;
  /** Additive military-power multiplier (Conquest Echo × count × 0.15). */
  militaryMult: number;
  /** Additive science multiplier (Science Echo × count × 0.15). */
  scienceMult: number;
  /** Additive gold multiplier (Trade Echo × count × 0.15). */
  goldMult: number;
  /** Additive multiplier on every resource's cap (Stability Echo × count × 0.10). */
  capsMult: number;
  /** Flat per-tick happiness bonus (Stability Echo × count × 10). */
  happinessFlat: number;
  /** Flat Divinity generated per second (Faith Echo × count × 0.02). */
  divinityPerSec: number;
}

/**
 * Sum the bonuses from all owned Echo Types into a single aggregate.
 * Each echo type's `bonus` object is multiplied by the count owned
 * (from the `echoesOwned` map) and added to the corresponding result
 * field.
 *
 * Used by the tick loop to compute per-resource multipliers, the
 * pop-growth rate, the cap multipliers, the per-tick happiness bonus,
 * and the per-second Divinity grant. The aggregate is recomputed each
 * tick (it's cheap — 6 entries) so the consumer doesn't need to cache
 * it.
 *
 * @param echoesOwned  Map of echo id → count owned (0 / absent = none owned).
 * @returns Aggregated `EchoBonus` (all fields defaulted for empty input).
 *
 * @example
 *   echoBonus({})
 *     // → { productionMult:0, ..., happinessFlat:0, divinityPerSec:0 }
 *   echoBonus({ growth_echo: 1 })
 *     // → { populationGrowthMult:0.10, ... }  (1 Growth Echo = +10% pop growth)
 *   echoBonus({ growth_echo: 3 })
 *     // → { populationGrowthMult:0.30, ... }  (3 Growth Echoes = +30% pop growth)
 *   echoBonus({ trade_echo: 2 })
 *     // → { goldMult:0.30, productionMult:0.30, ... }  (2 Trade Echoes = +30% gold AND +30% production)
 *   echoBonus({ stability_echo: 2 })
 *     // → { happinessFlat:20, capsMult:0.20, ... }  (2 Stability Echoes = +20 happiness/s, +20% caps)
 *   echoBonus({ faith_echo: 5 })
 *     // → { divinityPerSec:0.10, ... }  (5 Faith Echoes = +0.10 Divinity/s)
 *   echoBonus({ growth_echo: 1, science_echo: 1, conquest_echo: 1 })
 *     // → { populationGrowthMult:0.10, scienceMult:0.15, militaryMult:0.15, ... }
 *   echoBonus({ nonexistent: 5 })
 *     // → { all zeros }  (unknown echo id ignored)
 *   echoBonus({ growth_echo: 0 })
 *     // → { all zeros }  (count <= 0 treated as unowned)
 */
export function echoBonus(
  echoesOwned: Record<string, number>
): EchoBonus {
  const result: EchoBonus = {
    productionMult: 0,
    populationGrowthMult: 0,
    militaryMult: 0,
    scienceMult: 0,
    goldMult: 0,
    capsMult: 0,
    happinessFlat: 0,
    divinityPerSec: 0,
  };
  for (const echo of ECHO_TYPES) {
    const count = echoesOwned[echo.id] ?? 0;
    if (count <= 0) continue;
    const b = echo.bonus;
    if (b.productionMult !== undefined) result.productionMult += b.productionMult * count;
    if (b.populationGrowthMult !== undefined) result.populationGrowthMult += b.populationGrowthMult * count;
    if (b.militaryMult !== undefined) result.militaryMult += b.militaryMult * count;
    if (b.scienceMult !== undefined) result.scienceMult += b.scienceMult * count;
    if (b.goldMult !== undefined) result.goldMult += b.goldMult * count;
    if (b.capsMult !== undefined) result.capsMult += b.capsMult * count;
    if (b.happinessFlat !== undefined) result.happinessFlat += b.happinessFlat * count;
    if (b.divinityPerSec !== undefined) result.divinityPerSec += b.divinityPerSec * count;
  }
  return result;
}

/**
 * Aggregated bonus object returned by `forkBonus`.
 *
 * All mult fields are additive on top of the baseline (0 = no change).
 * `epMult` is additive on the EP-gain multiplier (the consumer
 * multiplies all Evolution Point gains by `(1 + epMult)`; +1.0 means
 * double EP). The `special` field is the chosen branch's special
 * interaction, or `null` if the branch has no special.
 *
 * The consumer applies these in the tick loop:
 *
 *   - `productionMult`:        multiply production by `(1 + productionMult)`
 *   - `populationGrowthMult`:  multiply pop growth by `(1 + populationGrowthMult)`
 *   - `militaryMult`:         multiply military by `(1 + militaryMult)`
 *   - `scienceMult`:          multiply science by `(1 + scienceMult)`
 *   - `goldMult`:             multiply gold by `(1 + goldMult)`
 *   - `capsMult`:             multiply every resource cap by `(1 + capsMult)`
 *   - `epMult`:               multiply EP gains by `(1 + epMult)`
 *   - `special`:               the chosen branch's special interaction, or `null`
 *
 * Specials (e.g. The Final Divergence branch B's
 * `unlock_random_divine_law`) are dispatched separately by the consumer
 * reading `bonus.special.kind` — they're typically one-time actions
 * taken at fork resolution time, not per-tick effects.
 *
 * Only one branch per fork can be resolved per run
 * (`state.forksResolved[forkId]` is a single `"A" | "B"` value, not a
 * set). If the consumer wants the aggregate across ALL resolved forks,
 * they iterate `FORK_SCENARIOS` and call `forkBonus` per fork (see the
 * store wiring task — `forkBonus` is per-fork by design).
 */
export interface ForkBonus {
  /** Additive all-production multiplier (Crossroads A +0.50, Realm of Mirrors B +0.30). */
  productionMult: number;
  /** Additive population-growth multiplier (Crossroads B +0.50). */
  populationGrowthMult: number;
  /** Additive military-power multiplier (Great Schism A +0.40). */
  militaryMult: number;
  /** Additive science multiplier (Great Schism B +0.40). */
  scienceMult: number;
  /** Additive gold multiplier. */
  goldMult: number;
  /** Additive multiplier on every resource's cap (Realm of Mirrors A +0.30). */
  capsMult: number;
  /** Additive Evolution Points multiplier (Final Divergence A +1.0 = +100% EP). */
  epMult: number;
  /** The chosen branch's special interaction, or `null` if the branch has no special. */
  special: ForkSpecial | null;
}

/**
 * Return the chosen branch's bonuses for a single fork scenario.
 *
 * Only one branch per fork can be resolved per run
 * (`state.forksResolved[forkId]` is a single `"A" | "B"` value, not a
 * set). The aggregate is just the chosen branch's stat fields passed
 * through with defaults (0 for mults, `null` for special). The
 * `special` field is returned verbatim so the consumer can dispatch on
 * `special.kind` without a second lookup.
 *
 * Used by the tick loop to compute per-resource multipliers, the
 * pop-growth rate, cap multipliers, and the EP-gain multiplier. Special
 * interactions (The Final Divergence branch B's free Divine Law unlock)
 * are dispatched separately by the consumer reading `bonus.special.kind`.
 *
 * @param forkId   The fork scenario id, or `null` if no fork is being queried.
 * @param branch   The branch key (`"A"` or `"B"`), or `null` if no branch chosen.
 * @returns Aggregated `ForkBonus` (all fields defaulted for null / unknown input).
 *
 * @example
 *   forkBonus(null, null)
 *     // → { productionMult:0, ..., epMult:0, special:null }
 *   forkBonus("crossroads_of_evolution", "A")
 *     // → { productionMult:0.50, ..., epMult:0, special:null }  (+50% production)
 *   forkBonus("crossroads_of_evolution", "B")
 *     // → { populationGrowthMult:0.50, ..., epMult:0, special:null }  (+50% pop growth)
 *   forkBonus("the_great_schism", "A")
 *     // → { militaryMult:0.40, ..., epMult:0, special:null }  (+40% military)
 *   forkBonus("the_great_schism", "B")
 *     // → { scienceMult:0.40, ..., epMult:0, special:null }  (+40% science)
 *   forkBonus("realm_of_mirrors", "A")
 *     // → { capsMult:0.30, ..., epMult:0, special:null }  (+30% caps)
 *   forkBonus("realm_of_mirrors", "B")
 *     // → { productionMult:0.30, ..., epMult:0, special:null }  (+30% all production)
 *   forkBonus("the_final_divergence", "A")
 *     // → { epMult:1.0, ..., special:null }  (+100% EP)
 *   forkBonus("the_final_divergence", "B")
 *     // → { ..., special:{ kind:"unlock_random_divine_law" } }  (free Divine Law)
 *   forkBonus("nonexistent_id", "A")
 *     // → { all defaults, special:null }  (unknown id treated as "no fork")
 *   forkBonus("crossroads_of_evolution", null)
 *     // → { all defaults, special:null }  (no branch chosen yet)
 */
export function forkBonus(
  forkId: string | null,
  branch: "A" | "B" | null
): ForkBonus {
  const result: ForkBonus = {
    productionMult: 0,
    populationGrowthMult: 0,
    militaryMult: 0,
    scienceMult: 0,
    goldMult: 0,
    capsMult: 0,
    epMult: 0,
    special: null,
  };
  if (!forkId || !branch) return result;
  const fork = FORK_MAP[forkId];
  if (!fork) return result;
  const branchDef = branch === "A" ? fork.branchA : fork.branchB;
  if (branchDef.productionMult !== undefined) result.productionMult = branchDef.productionMult;
  if (branchDef.populationGrowthMult !== undefined) result.populationGrowthMult = branchDef.populationGrowthMult;
  if (branchDef.militaryMult !== undefined) result.militaryMult = branchDef.militaryMult;
  if (branchDef.scienceMult !== undefined) result.scienceMult = branchDef.scienceMult;
  if (branchDef.goldMult !== undefined) result.goldMult = branchDef.goldMult;
  if (branchDef.capsMult !== undefined) result.capsMult = branchDef.capsMult;
  if (branchDef.epMult !== undefined) result.epMult = branchDef.epMult;
  if (branchDef.special !== undefined) result.special = branchDef.special;
  return result;
}

/**
 * Whether the Layer 9 (Infinity) completion conditions are met.
 *
 * Conditions (both must be true):
 *   1. At least `INFINITY_COMPLETION_FORKS_REQUIRED` (1) Fork Scenarios
 *      have been resolved — i.e. have a `"A"` or `"B"` entry in the
 *      `forksResolved` map.
 *   2. A Future Debt has been fully repaid this run (`debtRepaid === true`).
 *
 * Matches `prestigeLayers.ts infinity.completeState = "Fork a timeline
 * and repay the resulting Future Debt"`. Used by `triggerPrestige()`
 * to gate advancement to Layer 10 (Eternity).
 *
 * Note: "repaid" means the player has survived a complete
 * boost + penalty cycle on any Future Debt tier — the penalty phase
 * ended without the player resetting. This proves the god can carry
 * the weight of borrowed power, which is the thematic crux of the
 * Infinity layer.
 *
 * @param forksResolved  Map of fork id → chosen branch ("A" | "B").
 * @param debtRepaid     Whether any Future Debt has been fully repaid this run.
 * @returns `true` if both conditions are met.
 *
 * @example
 *   isInfinityComplete({}, false)
 *     // → false  (no forks resolved, no debt repaid)
 *   isInfinityComplete({ crossroads_of_evolution: "A" }, false)
 *     // → false  (1 fork but no debt repaid)
 *   isInfinityComplete({}, true)
 *     // → false  (debt repaid but no fork resolved)
 *   isInfinityComplete({ crossroads_of_evolution: "A" }, true)
 *     // → true  (1 fork + debt repaid)
 *   isInfinityComplete({
 *     crossroads_of_evolution: "A",
 *     the_great_schism: "B",
 *     realm_of_mirrors: "A",
 *     the_final_divergence: "B"
 *   }, true)
 *     // → true  (4 forks + debt repaid — over-satisfied)
 *   isInfinityComplete({ nonexistent_fork: "A" }, true)
 *     // → false  (unknown fork id ignored; 0 recognized forks + debt repaid)
 *   isInfinityComplete({ crossroads_of_evolution: "A" }, false)
 *     // → false  (fork resolved but debt not repaid)
 */
export function isInfinityComplete(
  forksResolved: Record<string, "A" | "B">,
  debtRepaid: boolean
): boolean {
  const resolvedCount = FORK_SCENARIOS.filter((f) => {
    const branch = forksResolved[f.id];
    return branch === "A" || branch === "B";
  }).length;
  return (
    resolvedCount >= INFINITY_COMPLETION_FORKS_REQUIRED && debtRepaid
  );
}
