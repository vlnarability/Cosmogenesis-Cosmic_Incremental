// Eternity — Layer 10 prestige content (FINAL layer)
//
// When a god reaches Eternity it stops being a curator of timelines and
// becomes an author of canon. The run history hardens into Testament
// Clauses that lock the rules of reality; specific beats / archetypes /
// stage clears are Canonized into eternal truth; Permanence Weaves pin
// Divine Laws, Worship Modes, and Routes so they survive every future
// reset; and finally the god chooses an Ending — to Preserve the
// universe as a gallery of everything it has been, or to Reset it
// entirely and begin anew carrying a Cosmic Boon that strengthens each
// time the choice is made.
//
// Four mechanic families live in this file:
//
//   1. Testament Clauses (8)    — permanent rules of reality. Each clause
//                                  is a one-time purchase that grants a
//                                  permanent additive bonus to one
//                                  stat (production / caps / science /
//                                  military / pop growth / gold /
//                                  Divinity), OR — for the Clause of
//                                  Unity — a meta-multiplier that
//                                  amplifies ALL OTHER accumulated
//                                  bonuses. Permanent across all future
//                                  runs. Purchased with the Testament
//                                  Clauses currency earned at Layer 10
//                                  prestige.
//   2. Canonizations (3)        — declare events / archetypes permanent.
//                                  Each canonization type can be
//                                  purchased multiple times (once per
//                                  specific item). Canonizing a story
//                                  beat grants +5% all production
//                                  permanently per canonized beat.
//                                  Canonizing a stage clear grants
//                                  +10% Evolution Points from that stage
//                                  permanently per canonized clear.
//                                  Canonizing an archetype grants that
//                                  archetype's bonus to ALL future runs
//                                  regardless of drift (the consumer
//                                  queries `archetypes.ts ARCHETYPES`
//                                  directly for the bonus shape — no
//                                  flat stat is encoded here).
//   3. Permanence Weaves (3)    — pin laws through resets. Each weave
//                                  type lets the player pin one specific
//                                  item of that kind (a Divine Law, a
//                                  Worship Mode, a Route) so it
//                                  persists across all future prestiges
//                                  without re-purchase. The weave
//                                  itself grants no stat bonus — the
//                                  pinned item's bonus is applied by
//                                  the consumer reading its source
//                                  definition (apotheosis.ts
//                                  DIVINE_LAWS / WORSHIP_MODES,
//                                  foresight.ts ROUTES).
//   4. Ending Choices (2)       — the final decision. "Preserve
//                                  Universe" enters gallery mode (no
//                                  boon — the game becomes a museum of
//                                  the player's run history). "Reset
//                                  Universe" starts a completely fresh
//                                  run carrying a Cosmic Boon that
//                                  grants +100% all production, +100%
//                                  EP, and +50% all caps per stack —
//                                  and the boon stacks each time
//                                  "Reset Universe" is chosen, growing
//                                  stronger across every Eternity
//                                  layer reached.
//
// State fields (planned for GameState — to be wired in a follow-up task):
//   - clausesOwned:               Record<string, boolean>     // testament clause id → owned (persistent)
//   - canonizationsOwned:         Record<string, number>     // canonization id → count purchased (persistent)
//   - canonizedStoryBeats:        Record<string, boolean>    // story beat id → canonized (persistent)
//   - canonizedArchetypes:        Record<string, boolean>    // archetype id → canonized (persistent)
//   - canonizedStageClears:       Record<string, boolean>    // stage id → canonized (persistent)
//   - pinnedDivineLaws:           Record<string, boolean>    // divine law id → pinned via weave (persistent)
//   - pinnedWorshipModes:         Record<string, boolean>    // worship mode id → pinned via weave (persistent)
//   - pinnedRoutes:               Record<string, boolean>    // route id → pinned via weave (persistent)
//   - endingChosen:               EndingId | null            // null before choice made (per-run)
//   - cosmicBoonStacks:           number                     // total times "reset" ending ever chosen (persistent)
//   - testamentClauses:           number                     // current Testament Clauses currency pool
//
// Reference: Eternity is new to the TS port — the vanilla JS had no Layer
// 10 content. The 8 / 3 / 3 / 2 spec, the clause magnitudes, the
// canonization bonuses, and the Cosmic Boon values come straight from
// the L10-data task spec. The Testament Clauses currency is the Layer 10
// prestige currency (the `currency: "Eternity"` field on
// `prestigeLayers.ts eternity`); the Testament Clause / Canonization /
// Permanence Weave cost fields are denominated in that currency.
//
// Note on ending naming: `prestigeLayers.ts eternity.completeState`
// reads "Choose an Ending (Silence / Cycle / Open Hand)" — those were
// the original vanilla-JS ending names. The L10-data task spec
// supersedes them with two cleaner endings: "Preserve Universe" and
// "Reset Universe". The two are functionally distinct (Preserve =
// gallery mode, Reset = fresh start + stacking Cosmic Boon); the
// original Silence/Cycle/Open Hand trichotomy is collapsed into these
// two. The completion check (`isEternityComplete`) is unchanged in
// spirit — "an Ending has been chosen" — only the ending set differs.
//
// Advancement: Eternity is the terminal layer (see `prestigeLayers.ts
// eternity.unlockNext: "Terminal layer — choosing an Ending closes the
// loop"`). There is no Layer 11. Choosing "Reset Universe" restarts
// the game at Layer 1 (Evolution) carrying the Cosmic Boon; choosing
// "Preserve Universe" freezes the run in gallery mode and ends
// progression. See `isEternityComplete` for the (trivial) gating logic.

// =====================================================================
// 1. Testament Clauses (8) — permanent rules of reality
// =====================================================================

/**
 * A single Testament Clause. Each clause is a one-time purchase that
 * grants a permanent additive bonus to one stat (production / caps /
 * science / military / pop growth / gold / Divinity). The Clause of
 * Unity is the capstone exception: instead of granting a flat additive
 * bonus, its `allBonusesMult` field is a META-multiplier that
 * amplifies ALL OTHER accumulated bonuses (the consumer multiplies the
 * post-aggregate bonus by `(1 + allBonusesMult)`).
 *
 * Effect field → consumer wiring ( TestamentBonus aggregate → tick loop):
 *   - `productionMult`         → additive all-production mult (Abundance +0.50)
 *   - `capsMult`               → additive mult on every resource cap (Endurance +1.00)
 *   - `scienceMult`            → additive science mult (Wisdom +0.75)
 *   - `militaryMult`            → additive military mult (Dominion +1.00)
 *   - `populationGrowthMult`   → additive pop-growth mult (Fertility +1.00)
 *   - `goldMult`                → additive gold mult (Wealth +1.00)
 *   - `divinityMult`           → additive Divinity mult (Faith +2.00)
 *   - `allBonusesMult`         → META-multiplier on ALL other accumulated
 *                                 bonuses (Unity +0.25 = +25% to every
 *                                 other bonus field). The consumer applies
 *                                 this LAST, after summing all other
 *                                 bonuses from all sources — not just
 *                                 testament clauses, but also echoes,
 *                                 fork branches, divine laws, worship
 *                                 modes, foresight nodes, ascension
 *                                 upgrades, etc. This is the capstone
 *                                 design: Unity amplifies everything the
 *                                 god has built across all 10 layers.
 *
 * All mult fields are additive on top of the baseline (0 = no change).
 * `allBonusesMult` is also additive on the meta-multiplier (0 = no
 * meta-amplification; 0.25 = ×1.25 final multiplier on all bonuses).
 *
 * Clauses are permanent across ALL future runs — once purchased, they
 * apply to every subsequent run forever. The `clausesOwned` map is
 * part of the persistent GameState (not per-run state). The IIFE
 * validator enforces that each clause sets exactly one effect field
 * (a clause that mixes flat stat bonuses with `allBonusesMult` would
 * conflate two distinct design intents — flat-per-stat vs. meta-amp —
 * and is rejected).
 *
 * Clauses are NOT mutually exclusive — the player can (eventually)
 * own all eight simultaneously, and the bonuses stack additively
 * within their stat (Abundance +0.50 production + Unity's meta-amp
 * applied last = +62.5% production). The Clause of Unity's meta-amp
 * applies to the post-sum aggregate, not per-clause.
 *
 * The eight clauses are deliberately ordered by scope, escalating
 * from broad-but-shallow (Abundance's +50% production) through
 * domain-specific boons (Endurance, Wisdom, Dominion, Fertility,
 * Wealth, Faith) to the capstone meta-amp (Unity's +25% to ALL
 * bonuses). Costs scale accordingly — Unity is by far the most
 * expensive clause to author, reflecting its capstone status.
 */
export interface TestamentClauseDef {
  /** Stable identifier (used as a key in `clausesOwned` in GameState). */
  id: string;
  /** Human-readable clause name. */
  name: string;
  /** Narrative / mechanical flavour describing what the clause decrees. */
  desc: string;
  /** Emoji glyph shown on the clause card. */
  icon: string;
  /** Testament Clauses currency cost (one-time purchase). */
  cost: number;
  /** Additive all-production multiplier (0.50 = +50% all production). */
  productionMult?: number;
  /** Additive multiplier on every resource cap (1.00 = +100% caps). */
  capsMult?: number;
  /** Additive science multiplier (0.75 = +75% science). */
  scienceMult?: number;
  /** Additive military-power multiplier (1.00 = +100% military). */
  militaryMult?: number;
  /** Additive population-growth multiplier (1.00 = +100% pop growth). */
  populationGrowthMult?: number;
  /** Additive gold multiplier (1.00 = +100% gold). */
  goldMult?: number;
  /** Additive Divinity multiplier (2.00 = +200% Divinity gain). */
  divinityMult?: number;
  /**
   * META-multiplier on ALL OTHER accumulated bonuses (0.25 = +25% to
   * every other bonus field, applied last as `finalBonus × (1 + allBonusesMult)`).
   * Exclusive to the Clause of Unity.
   */
  allBonusesMult?: number;
}

export const TESTAMENT_CLAUSES: TestamentClauseDef[] = [
  {
    id: "clause_abundance",
    name: "Clause of Abundance",
    desc:
      "Decree that overflow is the natural state of every system the god has touched. All production " +
      "flows 50% richer, permanently, across every future ascension.",
    icon: "🌾",
    cost: 5,
    productionMult: 0.50,
  },
  {
    id: "clause_endurance",
    name: "Clause of Endurance",
    desc:
      "Decree that what can be held shall never overflow. Every cap — every resource, every currency, " +
      "every domain — doubles, permanently.",
    icon: "🛡️",
    cost: 6,
    capsMult: 1.00,
  },
  {
    id: "clause_wisdom",
    name: "Clause of Wisdom",
    desc:
      "Decree that inquiry is the steady state of every mind that will ever think. Science flows 75% " +
      "richer, permanently, across every future ascension.",
    icon: "📜",
    cost: 7,
    scienceMult: 0.75,
  },
  {
    id: "clause_dominion",
    name: "Clause of Dominion",
    desc:
      "Decree that the god's reach is the measure of the world. Military power doubles, permanently, " +
      "across every future ascension.",
    icon: "⚔️",
    cost: 8,
    militaryMult: 1.00,
  },
  {
    id: "clause_fertility",
    name: "Clause of Fertility",
    desc:
      "Decree that every seed and womb shall quicken. Population growth doubles, permanently, across " +
      "every future ascension.",
    icon: "🌱",
    cost: 8,
    populationGrowthMult: 1.00,
  },
  {
    id: "clause_wealth",
    name: "Clause of Wealth",
    desc:
      "Decree that every transaction carries the god's mark. Gold doubles, permanently, across every " +
      "future ascension.",
    icon: "🪙",
    cost: 9,
    goldMult: 1.00,
  },
  {
    id: "clause_faith",
    name: "Clause of Faith",
    desc:
      "Decree that the god's name is the first and final word. Divinity gain triples (+200%), " +
      "permanently, across every future ascension.",
    icon: "🙏",
    cost: 12,
    divinityMult: 2.00,
  },
  {
    id: "clause_unity",
    name: "Clause of Unity",
    desc:
      "The capstone clause. Decree that every blessing the god has authored — every echo, every law, " +
      "every fork, every clause — shall resound 25% louder. All accumulated bonuses amplify by 25%, " +
      "permanently, across every future ascension. The final rule of reality.",
    icon: "♾️",
    cost: 25,
    allBonusesMult: 0.25,
  },
];

export const TESTAMENT_CLAUSE_MAP: Record<string, TestamentClauseDef> = Object.fromEntries(
  TESTAMENT_CLAUSES.map((c) => [c.id, c])
);

export const TESTAMENT_CLAUSE_COUNT: number = TESTAMENT_CLAUSES.length;

// =====================================================================
// 2. Canonizations (3) — declare events / archetypes permanent
// =====================================================================

/**
 * The kind of thing being canonized. Each kind maps to a different
 * permanent reward structure:
 *
 *   - `story_beat`    Canonize a specific story beat from `story.ts`.
 *                      Each canonized beat grants +5% all production
 *                      permanently. The canonization's `productionMult`
 *                      field encodes this per-canonization bonus.
 *
 *   - `archetype`     Canonize a specific archetype from
 *                      `archetypes.ts ARCHETYPES`. The canonized
 *                      archetype's bonus is applied to ALL future runs
 *                      regardless of drift — even if the run's
 *                      affinity drifts elsewhere, the canonized
 *                      archetype's bonus still applies. The bonus
 *                      shape lives on the archetype def, NOT here —
 *                      the consumer queries `ARCHETYPES[id].bonus`
 *                      directly. No flat stat is encoded on this
 *                      canonization entry.
 *
 *   - `stage_clear`   Canonize a specific stage clear (one of the 7
 *                      stages from `state/types.ts StageId`). Each
 *                      canonized stage clear grants +10% Evolution
 *                      Points from that stage permanently. The
 *                      canonization's `epFromStageMult` field encodes
 *                      this per-canonization bonus.
 *
 * The discriminated union is enforced by the IIFE validator: each
 * canonization entry must set the effect fields appropriate to its
 * `kind` (story_beat sets productionMult, stage_clear sets
 * epFromStageMult, archetype sets neither).
 */
export type CanonizationKind = "story_beat" | "archetype" | "stage_clear";

/**
 * A single Canonization entry. Each entry represents one KIND of
 * canonization (story beat / archetype / stage clear); the player
 * purchases the entry once per specific item they want to canonize
 * (e.g. buying "canonize_story_beat" 3 times canonizes 3 different
 * story beats). The state tracks `canonizationsOwned[canonizationId]`
 * as a count (not a boolean) — the count is the number of specific
 * items canonized under that kind.
 *
 * The state ALSO tracks the specific items canonized via separate
 * maps (`canonizedStoryBeats`, `canonizedArchetypes`,
 * `canonizedStageClears`) — these are keyed by the canonized item's
 * id (story beat id / archetype id / stage id) and used by the
 * consumer to look up the specific item's bonus (especially for
 * archetype canonizations, where the bonus shape is on the archetype
 * def, not here).
 *
 * Canonizations are permanent across ALL future runs — once a story
 * beat is canonized, the +5% all production applies forever. The
 * `canonizationsOwned` and per-item canonization maps are part of the
 * persistent GameState.
 *
 * Canonizations are NOT mutually exclusive — the player can (eventually)
 * canonize all 14 story beats, all 13 archetypes, and all 7 stage
 * clears. Each canonization stacks additively within its kind (3
 * canonized story beats = +15% all production).
 */
export interface CanonizationDef {
  /** Stable identifier (used as a key in `canonizationsOwned` in GameState). */
  id: string;
  /** Human-readable canonization name. */
  name: string;
  /** Narrative / mechanical flavour describing what canonizing this kind does. */
  desc: string;
  /** Emoji glyph shown on the canonization card. */
  icon: string;
  /** Testament Clauses currency cost per canonization (per specific item). */
  cost: number;
  /** The kind of item this canonization canonizes. */
  kind: CanonizationKind;
  /**
   * Per-canonization additive all-production multiplier. Only set on
   * `story_beat` canonizations (+0.05 = +5% all production per canonized
   * beat). The consumer sums this × `canonizationsOwned[id]` for the
   * total production bonus from canonized story beats.
   */
  productionMult?: number;
  /**
   * Per-canonization additive EP-from-stage multiplier. Only set on
   * `stage_clear` canonizations (+0.10 = +10% EP from that stage per
   * canonized clear). The consumer sums this × `canonizationsOwned[id]`
   * for the total EP bonus from canonized stage clears (applied to the
   * specific stage the player canonized — tracked separately in
   * `canonizedStageClears`).
   */
  epFromStageMult?: number;
}

export const CANONIZATIONS: CanonizationDef[] = [
  {
    id: "canonize_story_beat",
    name: "Canonize a Story Beat",
    desc:
      "Declare that a single moment from the god's run history shall be eternal truth. Every canonized " +
      "story beat grants +5% all production permanently — the memory of who the god was resonating " +
      "forward through every future ascension. May be purchased once per story beat.",
    icon: "📖",
    cost: 3,
    kind: "story_beat",
    productionMult: 0.05,
  },
  {
    id: "canonize_archetype",
    name: "Canonize an Archetype",
    desc:
      "Declare that one of the archetypes the god has lived shall be eternal — its bonus applies to " +
      "ALL future runs regardless of drift, even if the run's affinity wanders elsewhere. The canonized " +
      "archetype's bonus shape lives on the archetype def; this canonization simply pins it. May be " +
      "purchased once per archetype.",
    icon: "🎭",
    cost: 6,
    kind: "archetype",
  },
  {
    id: "canonize_stage_clear",
    name: "Canonize a Stage Clear",
    desc:
      "Declare that one of the stages the god has transcended shall be eternal. Every canonized stage " +
      "clear grants +10% Evolution Points from that stage permanently — the triumph echoing forward " +
      "into every future ascent. May be purchased once per stage.",
    icon: "🏆",
    cost: 4,
    kind: "stage_clear",
    epFromStageMult: 0.10,
  },
];

export const CANONIZATION_MAP: Record<string, CanonizationDef> = Object.fromEntries(
  CANONIZATIONS.map((c) => [c.id, c])
);

export const CANONIZATION_COUNT: number = CANONIZATIONS.length;

// =====================================================================
// 3. Permanence Weaves (3) — pin laws through resets
// =====================================================================

/**
 * The kind of item a Permanence Weave can pin. Each kind corresponds to
 * a layer's "pick one per run" decision that the weave makes permanent:
 *
 *   - `divine_law`    Pin a Divine Law from `apotheosis.ts DIVINE_LAWS`.
 *                      The pinned law is codified for free at the start
 *                      of every future Apotheosis-layer run, without
 *                      spending Divinity. Its bonus applies for the
 *                      entire run.
 *
 *   - `worship_mode`  Pin a Worship Mode from `apotheosis.ts
 *                      WORSHIP_MODES`. The pinned mode is selected for
 *                      free at the start of every future Apotheosis-
 *                      layer run, without spending the pick. Its bonus
 *                      applies for the entire run.
 *
 *   - `route`         Pin a Route from `foresight.ts ROUTES`. The
 *                      pinned route is selected for free at the start
 *                      of every future Foresight-layer run, without
 *                      spending the pick. Its bonus applies for the
 *                      entire run.
 *
 * The consumer reads the pinned item's bonus from its source definition
 * (DIVINE_LAWS / WORSHIP_MODES / ROUTES) — the weave itself grants no
 * flat stat bonus. This keeps the bonus shape canonical to its source
 * (no duplication).
 */
export type PermanenceWeaveKind = "divine_law" | "worship_mode" | "route";

/**
 * A single Permanence Weave entry. Each entry represents one KIND of
 * weave (divine law / worship mode / route); the player purchases the
 * entry once per specific item they want to pin (e.g. buying
 * "weave_divine_law" 2 times pins 2 different divine laws). The state
 * tracks `pinnedDivineLaws` / `pinnedWorshipModes` / `pinnedRoutes` as
 * `Record<string, boolean>` maps keyed by the pinned item's id.
 *
 * The weave itself grants NO stat bonus — its only effect is the
 * pinning action. The consumer queries the source definition
 * (DIVINE_LAWS / WORSHIP_MODES / ROUTES) for the pinned item's bonus
 * and applies it as if the player had picked it at the start of every
 * future run.
 *
 * Weaves are permanent across ALL future runs — once a divine law is
 * pinned, it's codified for free at the start of every future
 * Apotheosis-layer run, forever. The per-item pin maps are part of the
 * persistent GameState.
 *
 * Weaves are NOT mutually exclusive — the player can (eventually) pin
 * multiple divine laws, worship modes (only one applies per run — the
 * consumer picks the player's preferred pinned mode at run start), and
 * routes (only one applies per run — same logic). The state tracks the
 * SET of pinned items; the consumer picks which pinned item to activate
 * at the start of each run (or activates all of them for laws, which
 * stack — see `apotheosis.ts` for divine law stacking semantics).
 */
export interface PermanenceWeaveDef {
  /** Stable identifier (used as a key in the state's weave-purchase tracker). */
  id: string;
  /** Human-readable weave name. */
  name: string;
  /** Narrative / mechanical flavour describing what pinning this kind of item does. */
  desc: string;
  /** Emoji glyph shown on the weave card. */
  icon: string;
  /** Testament Clauses currency cost per weave (per specific item pinned). */
  cost: number;
  /** The kind of item this weave can pin. */
  kind: PermanenceWeaveKind;
}

export const PERMANENCE_WEAVES: PermanenceWeaveDef[] = [
  {
    id: "weave_divine_law",
    name: "Weave a Divine Law into Permanence",
    desc:
      "Pin a single Divine Law so it persists across all future prestiges without re-purchase — codified " +
      "for free at the start of every Apotheosis-layer run. The law's bonus applies for the entire run, " +
      "every run, forever. May be purchased once per divine law.",
    icon: "📜",
    cost: 10,
    kind: "divine_law",
  },
  {
    id: "weave_worship_mode",
    name: "Weave a Worship Mode into Permanence",
    desc:
      "Pin a single Worship Mode so it persists across all future prestiges without re-pick — selected " +
      "for free at the start of every Apotheosis-layer run. The mode's bonus applies for the entire run, " +
      "every run, forever. May be purchased once per worship mode.",
    icon: "🕯️",
    cost: 8,
    kind: "worship_mode",
  },
  {
    id: "weave_route",
    name: "Weave a Route into Permanence",
    desc:
      "Pin a single Route so it persists across all future prestiges without re-pick — selected for " +
      "free at the start of every Foresight-layer run. The route's bonus applies for the entire run, " +
      "every run, forever. May be purchased once per route.",
    icon: "🛤️",
    cost: 6,
    kind: "route",
  },
];

export const PERMANENCE_WEAVE_MAP: Record<string, PermanenceWeaveDef> = Object.fromEntries(
  PERMANENCE_WEAVES.map((w) => [w.id, w])
);

export const PERMANENCE_WEAVE_COUNT: number = PERMANENCE_WEAVES.length;

// =====================================================================
// 4. Ending Choices (2) — the final decision
// =====================================================================

/**
 * The two possible endings the god may choose when the Eternity layer
 * is reached. This is the final decision of the game — there is no
 * Layer 11. Each ending closes the loop in a different way.
 *
 *   - `preserve`   "Preserve Universe" — the god steps back and the
 *                  game enters gallery mode. The player can view all
 *                  their past runs, achievements, and story. No boon
 *                  is granted — the universe is frozen as a museum
 *                  of everything the god has been. Progression ends.
 *
 *   - `reset`      "Reset Universe" — the god destroys the universe
 *                  and starts completely fresh at Layer 1 (Evolution),
 *                  but carrying a Cosmic Boon: +100% all production,
 *                  +100% EP, +50% all caps per stack. The boon
 *                  STACKS — each time the player reaches Eternity and
 *                  chooses Reset, `cosmicBoonStacks` increments by 1
 *                  and the boon grows stronger.
 */
export type EndingId = "preserve" | "reset";

/**
 * The per-stack values of the Cosmic Boon granted by the "Reset
 * Universe" ending. The total boon is `cosmicBoonStacks × CosmicBoonDef`
 * (additive on each field). Only the "reset" ending sets
 * `cosmicBoonPerStack`; the "preserve" ending leaves it `undefined`
 * (gallery mode grants no boon).
 *
 * The consumer computes the active cosmic boon in the tick loop:
 *
 *   const resetDef = ENDING_CHOICE_MAP["reset"];
 *   const boon = resetDef?.cosmicBoonPerStack;
 *   if (boon && state.cosmicBoonStacks > 0) {
 *     bonus.productionMult += boon.productionMult * state.cosmicBoonStacks;
 *     bonus.epMult         += boon.epMult         * state.cosmicBoonStacks;
 *     bonus.capsMult       += boon.capsMult       * state.cosmicBoonStacks;
 *   }
 *
 * The boon applies to EVERY future run after the reset — the boon is
 * persistent (cosmicBoonStacks is part of the persistent GameState),
 * not per-run. A player who has chosen Reset 3 times carries a +300%
 * production / +300% EP / +150% caps boon into every subsequent run
 * forever.
 */
export interface CosmicBoonDef {
  /** Additive all-production multiplier per stack (1.0 = +100% per stack). */
  productionMult: number;
  /** Additive Evolution Points multiplier per stack (1.0 = +100% EP per stack). */
  epMult: number;
  /** Additive multiplier on every resource cap per stack (0.5 = +50% caps per stack). */
  capsMult: number;
}

/**
 * A single Ending Choice. The two endings are functionally distinct:
 *
 *   - "preserve"   Gallery mode — no boon. The game becomes a museum.
 *                  `cosmicBoonPerStack` is `undefined`.
 *
 *   - "reset"     Fresh start with a stacking Cosmic Boon.
 *                  `cosmicBoonPerStack` is set with the per-stack
 *                  values (+100% production, +100% EP, +50% caps per
 *                  stack). The boon is applied to every future run,
 *                  scaled by `state.cosmicBoonStacks` (incremented
 *                  each time this ending is chosen).
 *
 * The IIFE validator enforces:
 *   - Exactly 2 endings exist (`preserve` and `reset`).
 *   - The "reset" ending sets `cosmicBoonPerStack` with all three
 *     fields strictly positive.
 *   - The "preserve" ending does NOT set `cosmicBoonPerStack`
 *     (gallery mode grants no boon).
 */
export interface EndingChoiceDef {
  /** Stable identifier (matches `endingChosen` in GameState). */
  id: EndingId;
  /** Human-readable ending name. */
  name: string;
  /** Narrative / mechanical flavour describing what the ending means. */
  desc: string;
  /** Emoji glyph shown on the ending card. */
  icon: string;
  /**
   * Per-stack Cosmic Boon values. Only set on the "reset" ending.
   * The consumer multiplies each field by `state.cosmicBoonStacks`
   * to compute the active boon. `undefined` on the "preserve" ending
   * (gallery mode grants no boon).
   */
  cosmicBoonPerStack?: CosmicBoonDef;
}

export const ENDING_CHOICES: EndingChoiceDef[] = [
  {
    id: "preserve",
    name: "Preserve Universe",
    desc:
      "The god steps back from creation and lets it stand. The game enters gallery mode — a museum of " +
      "every run, every achievement, every story beat the god has lived. No boon is granted; the " +
      "universe is frozen as a complete and final work. Progression ends here. The story is told.",
    icon: "🏛️",
  },
  {
    id: "reset",
    name: "Reset Universe",
    desc:
      "The god unmakes the universe and starts completely fresh — at the very beginning, Layer 1, with " +
      "nothing but a Cosmic Boon: +100% all production, +100% Evolution Points, +50% all caps. The boon " +
      "STACKS — each time you reach Eternity and choose Reset, the boon grows stronger. The god becomes " +
      "a cycle, each turn louder than the last, until the cycle itself is the story.",
    icon: "🔄",
    cosmicBoonPerStack: {
      productionMult: 1.00,
      epMult: 1.00,
      capsMult: 0.50,
    },
  },
];

export const ENDING_CHOICE_MAP: Record<string, EndingChoiceDef> = Object.fromEntries(
  ENDING_CHOICES.map((e) => [e.id, e])
);

export const ENDING_CHOICE_COUNT: number = ENDING_CHOICES.length;

// =====================================================================
// Module-load sanity checks
// =====================================================================

/**
 * Validate the eternity data at module load:
 *   - All testament clause ids are unique.
 *   - Each clause has cost > 0.
 *   - Each clause sets EXACTLY ONE effect field (a clause that mixed
 *     flat stat bonuses with `allBonusesMult` would conflate two
 *     distinct design intents — flat-per-stat vs. meta-amp — and is
 *     rejected).
 *   - All mult fields on clauses (if set) are > 0 (clauses are boons,
 *     never penalties).
 *   - All canonization ids are unique.
 *   - Each canonization has cost > 0.
 *   - Each canonization's `kind` is one of the three valid values.
 *   - Each canonization sets the effect fields appropriate to its kind:
 *       story_beat    → productionMult must be set (>0)
 *       archetype     → no effect fields (the bonus lives on the
 *                       archetype def; consumer queries ARCHETYPES
 *                       directly)
 *       stage_clear   → epFromStageMult must be set (>0)
 *   - All permanence weave ids are unique.
 *   - Each weave has cost > 0.
 *   - Each weave's `kind` is one of the three valid values.
 *   - Exactly 2 ending choices exist, with ids "preserve" and "reset".
 *   - The "reset" ending sets `cosmicBoonPerStack` with all three
 *     fields strictly positive.
 *   - The "preserve" ending does NOT set `cosmicBoonPerStack`.
 *
 * Throws on any violation (programmer error, not a runtime / save data
 * error). The check is O(N) and runs once at module import, so it's a
 * no-op on the hot path. Matches the pattern established by
 * `apotheosis.ts`, `singularity.ts`, `omnipotence.ts`,
 * `divinity_layer.ts`, and `infinity.ts`.
 */
(function validateEternityData(): void {
  // ---- Testament clauses ----
  const seenClause = new Set<string>();
  for (const c of TESTAMENT_CLAUSES) {
    if (seenClause.has(c.id)) {
      throw new Error(`eternity.ts: duplicate testament clause id "${c.id}"`);
    }
    seenClause.add(c.id);

    if (c.cost <= 0) {
      throw new Error(
        `eternity.ts: testament clause "${c.id}" cost must be > 0 (got ${c.cost})`
      );
    }

    const effectCount = [
      c.productionMult !== undefined,
      c.capsMult !== undefined,
      c.scienceMult !== undefined,
      c.militaryMult !== undefined,
      c.populationGrowthMult !== undefined,
      c.goldMult !== undefined,
      c.divinityMult !== undefined,
      c.allBonusesMult !== undefined,
    ].filter(Boolean).length;
    if (effectCount !== 1) {
      throw new Error(
        `eternity.ts: testament clause "${c.id}" must set EXACTLY ONE effect field ` +
        `(set ${effectCount}). Mixing flat-per-stat bonuses with allBonusesMult ` +
        `conflates two distinct design intents.`
      );
    }

    if (c.productionMult !== undefined && c.productionMult <= 0) {
      throw new Error(
        `eternity.ts: testament clause "${c.id}" productionMult must be > 0 (got ${c.productionMult})`
      );
    }
    if (c.capsMult !== undefined && c.capsMult <= 0) {
      throw new Error(
        `eternity.ts: testament clause "${c.id}" capsMult must be > 0 (got ${c.capsMult})`
      );
    }
    if (c.scienceMult !== undefined && c.scienceMult <= 0) {
      throw new Error(
        `eternity.ts: testament clause "${c.id}" scienceMult must be > 0 (got ${c.scienceMult})`
      );
    }
    if (c.militaryMult !== undefined && c.militaryMult <= 0) {
      throw new Error(
        `eternity.ts: testament clause "${c.id}" militaryMult must be > 0 (got ${c.militaryMult})`
      );
    }
    if (c.populationGrowthMult !== undefined && c.populationGrowthMult <= 0) {
      throw new Error(
        `eternity.ts: testament clause "${c.id}" populationGrowthMult must be > 0 (got ${c.populationGrowthMult})`
      );
    }
    if (c.goldMult !== undefined && c.goldMult <= 0) {
      throw new Error(
        `eternity.ts: testament clause "${c.id}" goldMult must be > 0 (got ${c.goldMult})`
      );
    }
    if (c.divinityMult !== undefined && c.divinityMult <= 0) {
      throw new Error(
        `eternity.ts: testament clause "${c.id}" divinityMult must be > 0 (got ${c.divinityMult})`
      );
    }
    if (c.allBonusesMult !== undefined && c.allBonusesMult <= 0) {
      throw new Error(
        `eternity.ts: testament clause "${c.id}" allBonusesMult must be > 0 (got ${c.allBonusesMult})`
      );
    }
  }

  // ---- Canonizations ----
  const seenCanonization = new Set<string>();
  for (const c of CANONIZATIONS) {
    if (seenCanonization.has(c.id)) {
      throw new Error(`eternity.ts: duplicate canonization id "${c.id}"`);
    }
    seenCanonization.add(c.id);

    if (c.cost <= 0) {
      throw new Error(
        `eternity.ts: canonization "${c.id}" cost must be > 0 (got ${c.cost})`
      );
    }

    const validKinds: CanonizationKind[] = ["story_beat", "archetype", "stage_clear"];
    if (!validKinds.includes(c.kind)) {
      throw new Error(
        `eternity.ts: canonization "${c.id}" kind "${c.kind}" is not one of ${validKinds.join(" | ")}`
      );
    }

    switch (c.kind) {
      case "story_beat": {
        if (c.productionMult === undefined) {
          throw new Error(
            `eternity.ts: canonization "${c.id}" (kind=story_beat) must set productionMult`
          );
        }
        if (c.productionMult <= 0) {
          throw new Error(
            `eternity.ts: canonization "${c.id}" productionMult must be > 0 (got ${c.productionMult})`
          );
        }
        if (c.epFromStageMult !== undefined) {
          throw new Error(
            `eternity.ts: canonization "${c.id}" (kind=story_beat) must NOT set epFromStageMult`
          );
        }
        break;
      }
      case "archetype": {
        if (c.productionMult !== undefined) {
          throw new Error(
            `eternity.ts: canonization "${c.id}" (kind=archetype) must NOT set productionMult ` +
            `(the bonus shape lives on the archetype def)`
          );
        }
        if (c.epFromStageMult !== undefined) {
          throw new Error(
            `eternity.ts: canonization "${c.id}" (kind=archetype) must NOT set epFromStageMult`
          );
        }
        break;
      }
      case "stage_clear": {
        if (c.epFromStageMult === undefined) {
          throw new Error(
            `eternity.ts: canonization "${c.id}" (kind=stage_clear) must set epFromStageMult`
          );
        }
        if (c.epFromStageMult <= 0) {
          throw new Error(
            `eternity.ts: canonization "${c.id}" epFromStageMult must be > 0 (got ${c.epFromStageMult})`
          );
        }
        if (c.productionMult !== undefined) {
          throw new Error(
            `eternity.ts: canonization "${c.id}" (kind=stage_clear) must NOT set productionMult`
          );
        }
        break;
      }
      // No default — exhaustiveness enforced by TypeScript's discriminated union check.
    }
  }

  // ---- Permanence weaves ----
  const seenWeave = new Set<string>();
  for (const w of PERMANENCE_WEAVES) {
    if (seenWeave.has(w.id)) {
      throw new Error(`eternity.ts: duplicate permanence weave id "${w.id}"`);
    }
    seenWeave.add(w.id);

    if (w.cost <= 0) {
      throw new Error(
        `eternity.ts: permanence weave "${w.id}" cost must be > 0 (got ${w.cost})`
      );
    }

    const validWeaveKinds: PermanenceWeaveKind[] = ["divine_law", "worship_mode", "route"];
    if (!validWeaveKinds.includes(w.kind)) {
      throw new Error(
        `eternity.ts: permanence weave "${w.id}" kind "${w.kind}" is not one of ${validWeaveKinds.join(" | ")}`
      );
    }
  }

  // ---- Ending choices ----
  if (ENDING_CHOICES.length !== 2) {
    throw new Error(
      `eternity.ts: ENDING_CHOICES must contain exactly 2 entries (got ${ENDING_CHOICES.length})`
    );
  }
  const seenEnding = new Set<string>();
  for (const e of ENDING_CHOICES) {
    if (seenEnding.has(e.id)) {
      throw new Error(`eternity.ts: duplicate ending choice id "${e.id}"`);
    }
    seenEnding.add(e.id);
  }
  const preserveDef = ENDING_CHOICE_MAP["preserve"];
  const resetDef = ENDING_CHOICE_MAP["reset"];
  if (!preserveDef) {
    throw new Error(`eternity.ts: ENDING_CHOICES must include an entry with id "preserve"`);
  }
  if (!resetDef) {
    throw new Error(`eternity.ts: ENDING_CHOICES must include an entry with id "reset"`);
  }
  if (preserveDef.cosmicBoonPerStack !== undefined) {
    throw new Error(
      `eternity.ts: ending "preserve" must NOT set cosmicBoonPerStack (gallery mode grants no boon)`
    );
  }
  if (resetDef.cosmicBoonPerStack === undefined) {
    throw new Error(
      `eternity.ts: ending "reset" must set cosmicBoonPerStack`
    );
  }
  const boon = resetDef.cosmicBoonPerStack;
  if (boon.productionMult <= 0) {
    throw new Error(
      `eternity.ts: ending "reset" cosmicBoonPerStack.productionMult must be > 0 (got ${boon.productionMult})`
    );
  }
  if (boon.epMult <= 0) {
    throw new Error(
      `eternity.ts: ending "reset" cosmicBoonPerStack.epMult must be > 0 (got ${boon.epMult})`
    );
  }
  if (boon.capsMult <= 0) {
    throw new Error(
      `eternity.ts: ending "reset" cosmicBoonPerStack.capsMult must be > 0 (got ${boon.capsMult})`
    );
  }
})();

// =====================================================================
// Helpers
// =====================================================================

/**
 * Aggregated bonus object returned by `testamentClauseBonus`.
 *
 * All mult fields are additive on top of the baseline (0 = no change).
 * The `allBonusesMult` field is a META-multiplier that the consumer
 * applies LAST, after summing all other bonuses from all sources — not
 * just testament clauses, but also echoes, fork branches, divine laws,
 * worship modes, foresight nodes, ascension upgrades, canonizations,
 * cosmic boons, etc.
 *
 * The consumer applies these in the tick loop:
 *
 *   - `productionMult`:        multiply production by `(1 + productionMult)`
 *   - `capsMult`:              multiply every resource cap by `(1 + capsMult)`
 *   - `scienceMult`:          multiply science by `(1 + scienceMult)`
 *   - `militaryMult`:         multiply military by `(1 + militaryMult)`
 *   - `populationGrowthMult`: multiply pop growth by `(1 + populationGrowthMult)`
 *   - `goldMult`:              multiply gold by `(1 + goldMult)`
 *   - `divinityMult`:         multiply Divinity gain by `(1 + divinityMult)`
 *   - `allBonusesMult`:       AFTER all other bonuses are summed across
 *                              all sources, multiply the aggregate by
 *                              `(1 + allBonusesMult)`. The Clause of
 *                              Unity's +0.25 amplifies everything the
 *                              god has built across all 10 layers.
 *
 * The `allBonusesMult` field is the ONLY meta-multiplier in the layer.
 * The consumer should apply it exactly once, at the very end of the
 * bonus aggregation pipeline. Applying it earlier (e.g. per-source)
 * would compound it incorrectly.
 */
export interface TestamentBonus {
  /** Additive all-production multiplier (Abundance +0.50). */
  productionMult: number;
  /** Additive multiplier on every resource cap (Endurance +1.00). */
  capsMult: number;
  /** Additive science multiplier (Wisdom +0.75). */
  scienceMult: number;
  /** Additive military-power multiplier (Dominion +1.00). */
  militaryMult: number;
  /** Additive population-growth multiplier (Fertility +1.00). */
  populationGrowthMult: number;
  /** Additive gold multiplier (Wealth +1.00). */
  goldMult: number;
  /** Additive Divinity multiplier (Faith +2.00). */
  divinityMult: number;
  /**
   * META-multiplier on ALL OTHER accumulated bonuses (Unity +0.25).
   * The consumer applies this LAST as `finalBonus × (1 + allBonusesMult)`.
   */
  allBonusesMult: number;
}

/**
 * Sum the bonuses from all owned Testament Clauses into a single
 * aggregate. Each owned clause contributes its single effect field to
 * the corresponding result field.
 *
 * The `allBonusesMult` field is special — it is NOT applied here. It
 * is returned as-is for the consumer to apply at the very end of the
 * bonus aggregation pipeline (after summing ALL bonuses from ALL
 * sources). The Clause of Unity is the only entry that sets this
 * field; if Unity is not owned, it defaults to 0.
 *
 * Used by the tick loop to compute the permanent-per-run testament
 * bonus (clauses are persistent — once owned, they apply forever, so
 * the aggregate is the same every tick of every run until the player
 * buys a new clause). The aggregate is recomputed each tick anyway
 * (it's cheap — 8 entries) so the consumer doesn't need to cache it.
 *
 * @param clausesOwned  Map of clause id → owned flag. Truthy = owned.
 * @returns Aggregated `TestamentBonus` (all fields defaulted for empty input).
 *
 * @example
 *   testamentClauseBonus({})
 *     // → { productionMult:0, ..., allBonusesMult:0 }
 *   testamentClauseBonus({ clause_abundance: true })
 *     // → { productionMult:0.50, ..., allBonusesMult:0 }  (+50% production)
 *   testamentClauseBonus({ clause_endurance: true })
 *     // → { capsMult:1.00, ..., allBonusesMult:0 }  (+100% caps)
 *   testamentClauseBonus({ clause_faith: true })
 *     // → { divinityMult:2.00, ..., allBonusesMult:0 }  (+200% Divinity)
 *   testamentClauseBonus({ clause_unity: true })
 *     // → { ..., allBonusesMult:0.25 }  (+25% meta-amp; consumer applies LAST)
 *   testamentClauseBonus({ clause_abundance: true, clause_unity: true })
 *     // → { productionMult:0.50, ..., allBonusesMult:0.25 }
 *     //   (consumer computes final production bonus as 0.50 × 1.25 = 0.625)
 *   testamentClauseBonus({
 *     clause_abundance: true,
 *     clause_endurance: true,
 *     clause_wisdom: true,
 *     clause_dominion: true,
 *     clause_fertility: true,
 *     clause_wealth: true,
 *     clause_faith: true,
 *     clause_unity: true,
 *   })
 *     // → { productionMult:0.50, capsMult:1.00, scienceMult:0.75,
 *     //     militaryMult:1.00, populationGrowthMult:1.00, goldMult:1.00,
 *     //     divinityMult:2.00, allBonusesMult:0.25 }
 *   testamentClauseBonus({ nonexistent_clause: true })
 *     // → { all defaults }  (unknown clause id ignored)
 *   testamentClauseBonus({ clause_abundance: false })
 *     // → { all defaults }  (falsy value treated as unowned)
 */
export function testamentClauseBonus(
  clausesOwned: Record<string, boolean>
): TestamentBonus {
  const result: TestamentBonus = {
    productionMult: 0,
    capsMult: 0,
    scienceMult: 0,
    militaryMult: 0,
    populationGrowthMult: 0,
    goldMult: 0,
    divinityMult: 0,
    allBonusesMult: 0,
  };
  for (const clause of TESTAMENT_CLAUSES) {
    if (!clausesOwned[clause.id]) continue;
    if (clause.productionMult !== undefined) result.productionMult += clause.productionMult;
    if (clause.capsMult !== undefined) result.capsMult += clause.capsMult;
    if (clause.scienceMult !== undefined) result.scienceMult += clause.scienceMult;
    if (clause.militaryMult !== undefined) result.militaryMult += clause.militaryMult;
    if (clause.populationGrowthMult !== undefined) result.populationGrowthMult += clause.populationGrowthMult;
    if (clause.goldMult !== undefined) result.goldMult += clause.goldMult;
    if (clause.divinityMult !== undefined) result.divinityMult += clause.divinityMult;
    if (clause.allBonusesMult !== undefined) result.allBonusesMult += clause.allBonusesMult;
  }
  return result;
}

/**
 * Aggregated bonus object returned by `canonizationBonus`.
 *
 * Only story-beat and stage-clear canonizations contribute to this
 * aggregate. Archetype canonizations do NOT — their bonus shape lives
 * on the archetype def (`archetypes.ts ARCHETYPES[id].bonus`), and the
 * consumer queries that directly per canonized archetype id (using the
 * `canonizedArchetypes` state map).
 *
 * The consumer applies these in the tick loop:
 *
 *   - `productionMult`:   multiply all production by
 *                         `(1 + productionMult)`. From story-beat
 *                         canonizations: count × 0.05 each.
 *   - `epFromStageMult`:  additive Evolution Points multiplier PER
 *                         CANONIZED STAGE. The consumer applies this
 *                         per stage: for each canonized stage clear,
 *                         multiply EP gains FROM THAT STAGE by
 *                         `(1 + epFromStageMult)`. The `canonizedStageClears`
 *                         state map records which stages are canonized.
 */
export interface CanonizationBonus {
  /**
   * Additive all-production multiplier from canonized story beats.
   * `0.05 × canonized_beat_count` (e.g. 3 canonized beats = +0.15).
   */
  productionMult: number;
  /**
   * Per-canonized-stage EP multiplier. Applied PER STAGE that has been
   * canonized (the consumer reads `canonizedStageClears` to determine
   * which stages). `0.10 × canonized_stage_count` is the per-stage
   * bonus (e.g. 2 canonized stages = +0.20 EP from each of those two
   * stages specifically).
   */
  epFromStageMult: number;
}

/**
 * Sum the bonuses from all canonizations purchased into a single
 * aggregate. Each canonization type contributes its per-purchase
 * effect multiplied by the count purchased (from the
 * `canonizationsOwned` map).
 *
 * Archetype canonizations contribute NOTHING to this aggregate — their
 * bonus lives on the archetype def and the consumer queries
 * `ARCHETYPES[id].bonus` directly per canonized archetype id (using the
 * `canonizedArchetypes` state map). This helper only aggregates the
 * flat per-purchase bonuses from story-beat and stage-clear
 * canonizations.
 *
 * Used by the tick loop to compute the permanent-per-run canonization
 * bonus (canonizations are persistent — once purchased, they apply
 * forever). The aggregate is recomputed each tick anyway (it's cheap —
 * 3 entries) so the consumer doesn't need to cache it.
 *
 * @param canonizationsOwned  Map of canonization id → count purchased.
 * @returns Aggregated `CanonizationBonus` (all fields defaulted for empty input).
 *
 * @example
 *   canonizationBonus({})
 *     // → { productionMult:0, epFromStageMult:0 }
 *   canonizationBonus({ canonize_story_beat: 1 })
 *     // → { productionMult:0.05, epFromStageMult:0 }  (+5% all production)
 *   canonizationBonus({ canonize_story_beat: 4 })
 *     // → { productionMult:0.20, epFromStageMult:0 }  (+20% all production)
 *   canonizationBonus({ canonize_stage_clear: 1 })
 *     // → { productionMult:0, epFromStageMult:0.10 }  (+10% EP from each canonized stage)
 *   canonizationBonus({ canonize_stage_clear: 3 })
 *     // → { productionMult:0, epFromStageMult:0.30 }  (+30% EP from each canonized stage)
 *   canonizationBonus({ canonize_archetype: 5 })
 *     // → { productionMult:0, epFromStageMult:0 }  (archetype canonizations contribute nothing here)
 *   canonizationBonus({ canonize_story_beat: 2, canonize_stage_clear: 1 })
 *     // → { productionMult:0.10, epFromStageMult:0.10 }
 *   canonizationBonus({ nonexistent_canonization: 5 })
 *     // → { productionMult:0, epFromStageMult:0 }  (unknown id ignored)
 *   canonizationBonus({ canonize_story_beat: 0 })
 *     // → { productionMult:0, epFromStageMult:0 }  (count <= 0 treated as unpurchased)
 */
export function canonizationBonus(
  canonizationsOwned: Record<string, number>
): CanonizationBonus {
  const result: CanonizationBonus = {
    productionMult: 0,
    epFromStageMult: 0,
  };
  for (const canon of CANONIZATIONS) {
    const count = canonizationsOwned[canon.id] ?? 0;
    if (count <= 0) continue;
    if (canon.productionMult !== undefined) result.productionMult += canon.productionMult * count;
    if (canon.epFromStageMult !== undefined) result.epFromStageMult += canon.epFromStageMult * count;
  }
  return result;
}

/**
 * Whether the Layer 10 (Eternity) completion conditions are met.
 *
 * Condition: an Ending has been chosen this run
 * (`endingChosen !== null`).
 *
 * Matches `prestigeLayers.ts eternity.completeState = "Choose an
 * Ending"` (the L10-data task spec supersedes the vanilla-JS ending
 * names with "Preserve Universe" / "Reset Universe" — see the file
 * header comment for the naming reconciliation). Used by the
 * `triggerPrestige` integration (or, more accurately, the Ending
 * resolution flow) to mark the layer complete and either freeze the
 * universe (Preserve) or restart the game at Layer 1 carrying the
 * Cosmic Boon (Reset).
 *
 * Note: the gating is intentionally trivial — the player reaches
 * Eternity, optionally buys Clauses / Canonizations / Weaves with their
 * Testament Clauses currency, and then makes the Ending choice. There
 * is no minimum clause / canonization / weave count required to choose
 * an Ending; the player can choose immediately upon reaching the layer
 * if they wish (though doing so forfeits the chance to spend Testament
 * Clauses this run). The richness of the layer comes from the
 * permanence of the purchases, not from a gating threshold.
 *
 * @param endingChosen  The ending id chosen this run, or `null` if not yet chosen.
 * @returns `true` if an ending has been chosen.
 *
 * @example
 *   isEternityComplete(null)
 *     // → false  (no ending chosen yet)
 *   isEternityComplete("preserve")
 *     // → true  (Preserve Universe chosen — layer complete, game enters gallery mode)
 *   isEternityComplete("reset")
 *     // → true  (Reset Universe chosen — layer complete, game restarts with Cosmic Boon)
 *   isEternityComplete("nonexistent" as EndingId)
 *     // → false  (unknown ending id treated as "no ending chosen")
 */
export function isEternityComplete(
  endingChosen: EndingId | null
): boolean {
  return endingChosen === "preserve" || endingChosen === "reset";
}

/**
 * Compute the active Cosmic Boon from the player's lifetime count of
 * "Reset Universe" choices.
 *
 * Each time the player chooses the "reset" ending, `cosmicBoonStacks`
 * increments by 1 (this is a persistent GameState field — the boon
 * carries across every future run). The total boon is the per-stack
 * values from `ENDING_CHOICE_MAP["reset"].cosmicBoonPerStack` scaled
 * by the stack count.
 *
 * The boon applies to EVERY future run after the reset — it is not
 * per-run. A player who has chosen Reset 3 times carries a +300%
 * production / +300% EP / +150% caps boon into every subsequent run
 * forever.
 *
 * The boon is intentionally additive on each field (not multiplicative
 * on stacks) — 3 stacks of +100% production = +300% production, NOT
 * ×2 ×2 ×2 = ×8. This keeps the boon growth linear and predictable,
 * matching the spec wording "stacks with each reset" (linear stacking,
 * not compounding).
 *
 * Used by the tick loop to compute the cosmic boon bonus applied to
 * production / EP gains / caps. The boon is recomputed each tick
 * (it's cheap — a single map lookup and three multiplies) so the
 * consumer doesn't need to cache it.
 *
 * @param stacks  The lifetime count of "reset" ending choices (from `state.cosmicBoonStacks`).
 * @returns The active Cosmic Boon (all fields 0 if `stacks <= 0` or the "reset" ending is somehow missing).
 *
 * @example
 *   cosmicBoonBonus(0)
 *     // → { productionMult:0, epMult:0, capsMult:0 }  (no boon)
 *   cosmicBoonBonus(1)
 *     // → { productionMult:1.00, epMult:1.00, capsMult:0.50 }  (1 stack — +100% prod, +100% EP, +50% caps)
 *   cosmicBoonBonus(3)
 *     // → { productionMult:3.00, epMult:3.00, capsMult:1.50 }  (3 stacks — +300% prod, +300% EP, +150% caps)
 *   cosmicBoonBonus(-5)
 *     // → { productionMult:0, epMult:0, capsMult:0 }  (negative stacks treated as 0)
 */
export function cosmicBoonBonus(stacks: number): CosmicBoonDef {
  const result: CosmicBoonDef = {
    productionMult: 0,
    epMult: 0,
    capsMult: 0,
  };
  if (stacks <= 0) return result;
  const resetDef = ENDING_CHOICE_MAP["reset"];
  if (!resetDef || !resetDef.cosmicBoonPerStack) return result;
  const perStack = resetDef.cosmicBoonPerStack;
  result.productionMult = perStack.productionMult * stacks;
  result.epMult = perStack.epMult * stacks;
  result.capsMult = perStack.capsMult * stacks;
  return result;
}
