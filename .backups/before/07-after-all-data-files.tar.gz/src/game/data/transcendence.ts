// Transcendence — Layer 3 prestige content
//
// When a god reaches Transcendence it separates from creation and begins
// drawing power from offerings, rituals, scripts, and (in the dark path)
// blood pacts. The world becomes a vessel; what is poured into it returns
// as Divinity.
//
// Four mechanic families live in this file:
//
//   1. Offerings (6)        — sacrifice surplus resources for instant
//                             Divinity. Reusable each run.
//   2. Rituals (7)          — one-time per run, cost Divinity, powerful
//                             temporary or permanent effects.
//   3. Scripts (5)          — toggleable automation behaviors.
//   4. Blood Pact tiers (4) — sacrifice population for instant Divinity
//                             (dark path), with per-run limits.
//
// State fields (planned for GameState — to be wired in a follow-up task):
//   - ritualsUsed:       Record<string, boolean>  // rituals performed this run (one-time)
//   - ritualTimers:      Record<string, number>   // remaining seconds for temporary rituals
//   - activeScripts:     Record<string, boolean>  // scripts currently toggled on
//   - bloodPactUses:     Record<string, number>   // times each blood pact tier was used this run
//
// Reference: /home/z/my-project/upload/data.js DATA.OFFERINGS (lines 549-558),
// DATA.RITUALS (lines 432-439), and DATA.SCRIPTS (lines 440-453) for the
// original vanilla-JS shapes. The TS port reshapes each mechanic into a
// spec-aligned subset with explicit Divinity-only outputs (the vanilla JS
// spread gains across six sub-currencies; this port concentrates them all
// into the existing `divinity` resource id — see resources.ts:36).
//
// Advancement to Layer 4 (Genesis) requires performing at least one Blood
// Pact — see prestigeLayers.ts `transcendence.completeState: "Perform a Blood Pact"`.

import type { ResourceId } from "../state/types";

// =====================================================================
// Offerings (6) — sacrifice surplus resources for Divinity (reusable each run)
// =====================================================================

export interface OfferingDef {
  /** Stable identifier (used as a key in `offeringCounts` in GameState). */
  id: string;
  /** Human-readable offering name. */
  name: string;
  /** Narrative / mechanical flavour describing what is surrendered and why. */
  desc: string;
  /** Emoji glyph shown on the offering card. */
  icon: string;
  /** Single resource + amount consumed when the offering is performed. */
  cost: { resource: ResourceId; amount: number };
  /** Divinity granted instantly on success. */
  divinityGain: number;
}

export const OFFERINGS: OfferingDef[] = [
  {
    id: "burn_sugar",
    name: "Burn the Sugar",
    desc: "Set the glucose reserves alight; sweetness becomes divine spark.",
    icon: "🍬",
    cost: { resource: "glucose", amount: 50 },
    divinityGain: 1,
  },
  {
    id: "shed_flesh",
    name: "Shed the Flesh",
    desc: "Strip away the proteins of the body; what was tissue returns as power.",
    icon: "🥩",
    cost: { resource: "proteins", amount: 80 },
    divinityGain: 2,
  },
  {
    id: "melt_coin",
    name: "Melt the Coin",
    desc: "Pour gold into the crucible of faith; wealth unmade becomes divinity.",
    icon: "🪙",
    cost: { resource: "gold", amount: 200 },
    divinityGain: 3,
  },
  {
    id: "forge_break",
    name: "Forge-Break",
    desc: "Shatter the alloys of the starworks; their breaking sings of ascension.",
    icon: "⚒️",
    cost: { resource: "alloys", amount: 150 },
    divinityGain: 5,
  },
  {
    id: "erase_records",
    name: "Erase the Records",
    desc: "Burn away the galactic archive; forgotten knowledge becomes godfuel.",
    icon: "🗑️",
    cost: { resource: "data", amount: 300 },
    divinityGain: 8,
  },
  {
    id: "burn_library",
    name: "Burn the Library",
    desc: "Consign culture itself to flame; the ashes rise as Transcendence.",
    icon: "📚",
    cost: { resource: "culture", amount: 250 },
    divinityGain: 6,
  },
];

export const OFFERING_MAP: Record<string, OfferingDef> = Object.fromEntries(
  OFFERINGS.map((o) => [o.id, o])
);

export const OFFERING_COUNT: number = OFFERINGS.length;

// =====================================================================
// Rituals (7) — one-time per run, cost Divinity, powerful temporary/permanent effects
// =====================================================================

/**
 * A single ritual effect.
 *
 * `mode`:
 *   - "mult":         multiply the target's output by (1 + value). value is signed.
 *                     e.g. { target: "population_growth", mode: "mult", value: 1.0 } → ×2 pop growth
 *   - "flat_per_sec": add `value` to the target's per-second generation. value is signed.
 *                     e.g. { target: "divinity_per_sec", mode: "flat_per_sec", value: 0.05 }
 *                          → +0.05 Divinity/s permanent for run (Eternal Well)
 *   - "set":          set the target resource to `value` while the ritual is active.
 *                     e.g. { target: "happiness", mode: "set", value: 100 } (Calm the Storm)
 *   - "flag":         set a boolean flag consumed by special-case logic. Stored in
 *                     ritualsUsed; the consuming logic clears it after use.
 *                     e.g. { target: "evolve_skip", mode: "flag", value: 1 } (Break Through)
 *
 * `target` keys are effect handles consumed by the game loop, not ResourceIds.
 * They are plain strings to allow new effect targets without type churn.
 * Known targets:
 *   "population_growth" | "happiness" | "military_power" | "science"
 *   "gold" | "production" | "divinity_per_sec" | "evolve_skip"
 */
export interface RitualEffect {
  target: string;
  mode: "mult" | "flat_per_sec" | "set" | "flag";
  value: number;
}

export interface RitualDef {
  /** Stable identifier (used as a key in `ritualsUsed` / `ritualTimers` in GameState). */
  id: string;
  /** Human-readable ritual name. */
  name: string;
  /** One-line flavour / mechanical description of what the ritual does. */
  desc: string;
  /** Emoji glyph shown on the ritual card. */
  icon: string;
  /** Divinity cost to perform the ritual. */
  cost: number;
  /** Effects applied while the ritual is active. */
  effects: RitualEffect[];
  /** Seconds the ritual's effects last.
   *  Omitted (undefined) → permanent for the rest of the run (Golden Hand, Eternal Well, Break Through). */
  duration?: number;
}

export const RITUALS: RitualDef[] = [
  {
    id: "fertile_bloom",
    name: "Fertile Bloom",
    desc: "Pour divinity into the roots of life; population grows twice as fast for two minutes.",
    icon: "🌸",
    cost: 8,
    duration: 120,
    effects: [
      { target: "population_growth", mode: "mult", value: 1.0 },
    ],
  },
  {
    id: "calm_storm",
    name: "Calm the Storm",
    desc: "Still the discord in your people's hearts; happiness holds at 100 for one minute.",
    icon: "🕊️",
    cost: 5,
    duration: 60,
    effects: [
      { target: "happiness", mode: "set", value: 100 },
    ],
  },
  {
    id: "war_fever",
    name: "War Fever",
    desc: "Fan the steel and the hearts that wield it; military power surges 50% for three minutes.",
    icon: "⚔️",
    cost: 10,
    duration: 180,
    effects: [
      { target: "military_power", mode: "mult", value: 0.5 },
    ],
  },
  {
    id: "insight_burst",
    name: "Insight Burst",
    desc: "Open the mind's eye wide; science flows at 1.75× rate for three minutes.",
    icon: "💡",
    cost: 12,
    duration: 180,
    effects: [
      { target: "science", mode: "mult", value: 0.75 },
    ],
  },
  {
    id: "golden_hand",
    name: "Golden Hand",
    desc: "Lay a permanent blessing on the works of the world; gold and production flow 20% richer for the rest of the run.",
    icon: "✋",
    cost: 20,
    effects: [
      { target: "gold", mode: "mult", value: 0.20 },
      { target: "production", mode: "mult", value: 0.20 },
    ],
  },
  {
    id: "eternal_well",
    name: "Eternal Well",
    desc: "Dig a channel from the divine source; divinity seeps in at +0.05/s for the rest of the run.",
    icon: "⛲",
    cost: 25,
    effects: [
      { target: "divinity_per_sec", mode: "flat_per_sec", value: 0.05 },
    ],
  },
  {
    id: "break_through",
    name: "Break Through",
    desc: "Force open the door to the next stage; the next evolution requirement check is skipped entirely.",
    icon: "💥",
    cost: 30,
    effects: [
      { target: "evolve_skip", mode: "flag", value: 1 },
    ],
  },
];

export const RITUAL_MAP: Record<string, RitualDef> = Object.fromEntries(
  RITUALS.map((r) => [r.id, r])
);

export const RITUAL_COUNT: number = RITUALS.length;

// =====================================================================
// Scripts (5) — toggleable automation
// =====================================================================

/**
 * Discriminated union of script behaviors. Each script kind maps to a single
 * well-defined automation behavior in the tick loop. The consumer (store) reads
 * `behavior.kind` and dispatches accordingly.
 */
export type ScriptBehavior =
  | { kind: "auto_buy_cheapest_cell_system" }
  | { kind: "happiness_drift"; below: number; toward: number; perSec: number }
  | { kind: "reserve_resource"; resources: ResourceId[]; fraction: number }
  | { kind: "auto_research_cheapest_tech" }
  | { kind: "divinity_per_sec"; value: number };

export interface ScriptDef {
  /** Stable identifier (used as a key in `activeScripts` in GameState). */
  id: string;
  /** Human-readable script name. */
  name: string;
  /** Short flavour / mechanical description of what the script does. */
  desc: string;
  /** Emoji glyph shown on the script toggle. */
  icon: string;
  /** What the script does each tick while toggled on. */
  behavior: ScriptBehavior;
}

export const SCRIPTS: ScriptDef[] = [
  {
    id: "buy_sprout",
    name: "Buy-Sprout",
    desc: "Auto-buys the cheapest Cell-stage system the player can afford each tick.",
    icon: "🌱",
    behavior: { kind: "auto_buy_cheapest_cell_system" },
  },
  {
    id: "comfort",
    name: "Comfort",
    desc: "When happiness drops below 50, it drifts back toward 70 at 1/sec.",
    icon: "🛌",
    behavior: { kind: "happiness_drift", below: 50, toward: 70, perSec: 1 },
  },
  {
    id: "hoard",
    name: "Hoard",
    desc: "Reserves 10% of food and water — those amounts are locked away from consumption.",
    icon: "📦",
    behavior: { kind: "reserve_resource", resources: ["food", "water"], fraction: 0.10 },
  },
  {
    id: "curiosity",
    name: "Curiosity",
    desc: "Auto-researches the cheapest tech the player can afford each tick.",
    icon: "🔍",
    behavior: { kind: "auto_research_cheapest_tech" },
  },
  {
    id: "prayer_mill",
    name: "Prayer Mill",
    desc: "A prayer wheel turns endlessly; +0.01 Divinity per second while active.",
    icon: "🛐",
    behavior: { kind: "divinity_per_sec", value: 0.01 },
  },
];

export const SCRIPT_MAP: Record<string, ScriptDef> = Object.fromEntries(
  SCRIPTS.map((s) => [s.id, s])
);

export const SCRIPT_COUNT: number = SCRIPTS.length;

// =====================================================================
// Blood Pact tiers (4) — sacrifice population for instant Divinity (dark path)
// =====================================================================

export interface BloodPactTier {
  /** Stable identifier (used as a key in `bloodPactUses` in GameState). */
  id: string;
  /** Human-readable pact name. */
  name: string;
  /** Narrative / mechanical flavour of the cost and gain. */
  desc: string;
  /** Emoji glyph shown on the pact card. */
  icon: string;
  /** Flat population cost. Mutually exclusive with `populationFraction`. */
  populationCost?: number;
  /** Fraction (0..1) of current population sacrificed. Mutually exclusive with `populationCost`. */
  populationFraction?: number;
  /** Divinity granted instantly on performance. */
  divinityGain: number;
  /** Happiness hit applied immediately. Always negative or zero. */
  happinessCost: number;
  /** Maximum times this pact can be performed per run. */
  limitPerRun: number;
}

export const BLOOD_PACTS: BloodPactTier[] = [
  {
    id: "minor_offering",
    name: "Minor Offering",
    desc: "A small price paid in blood. 5 souls pass the threshold; divinity stirs.",
    icon: "🤲",
    populationCost: 5,
    divinityGain: 4,
    happinessCost: -10,
    limitPerRun: 5,
  },
  {
    id: "lesser_sacrifice",
    name: "Lesser Sacrifice",
    desc: "A heavier toll. 25 lives become 15 divinity; the survivors mourn.",
    icon: "🗡️",
    populationCost: 25,
    divinityGain: 15,
    happinessCost: -25,
    limitPerRun: 3,
  },
  {
    id: "greater_sacrifice",
    name: "Greater Sacrifice",
    desc: "A solemn rite of 100 souls. The altar drinks deep; the run bears the scar.",
    icon: "🪦",
    populationCost: 100,
    divinityGain: 50,
    happinessCost: -50,
    limitPerRun: 1,
  },
  {
    id: "total_oblation",
    name: "Total Oblation",
    desc: "Half of all that lives is given to the god. The world kneels, diminished but radiant.",
    icon: "☠️",
    populationFraction: 0.50,
    divinityGain: 100,
    happinessCost: -75,
    limitPerRun: 1,
  },
];

export const BLOOD_PACT_MAP: Record<string, BloodPactTier> = Object.fromEntries(
  BLOOD_PACTS.map((p) => [p.id, p])
);

export const BLOOD_PACT_COUNT: number = BLOOD_PACTS.length;

// =====================================================================
// Module-load sanity checks
// =====================================================================

/**
 * Validate the transcendence data at module load:
 *   - All ids within each family are unique.
 *   - Each blood pact has exactly one of `populationCost` / `populationFraction`.
 *   - `populationFraction` (if set) is in (0, 1].
 *   - Blood pact `happinessCost` is always ≤ 0.
 *   - Blood pact `limitPerRun` is always ≥ 1.
 *
 * Throws on any violation (programmer error, not a runtime / save data error).
 * The check is O(N) and runs once, so it's a no-op on the hot path.
 */
(function validateTranscendenceData(): void {
  const seenOffering = new Set<string>();
  for (const o of OFFERINGS) {
    if (seenOffering.has(o.id)) {
      throw new Error(`transcendence.ts: duplicate offering id "${o.id}"`);
    }
    seenOffering.add(o.id);
    if (o.cost.amount <= 0) {
      throw new Error(`transcendence.ts: offering "${o.id}" has non-positive cost.amount`);
    }
    if (o.divinityGain <= 0) {
      throw new Error(`transcendence.ts: offering "${o.id}" has non-positive divinityGain`);
    }
  }

  const seenRitual = new Set<string>();
  for (const r of RITUALS) {
    if (seenRitual.has(r.id)) {
      throw new Error(`transcendence.ts: duplicate ritual id "${r.id}"`);
    }
    seenRitual.add(r.id);
    if (r.cost < 0) {
      throw new Error(`transcendence.ts: ritual "${r.id}" has negative cost`);
    }
    if (r.duration !== undefined && r.duration <= 0) {
      throw new Error(`transcendence.ts: ritual "${r.id}" has non-positive duration`);
    }
  }

  const seenScript = new Set<string>();
  for (const s of SCRIPTS) {
    if (seenScript.has(s.id)) {
      throw new Error(`transcendence.ts: duplicate script id "${s.id}"`);
    }
    seenScript.add(s.id);
  }

  const seenPact = new Set<string>();
  for (const p of BLOOD_PACTS) {
    if (seenPact.has(p.id)) {
      throw new Error(`transcendence.ts: duplicate blood pact id "${p.id}"`);
    }
    seenPact.add(p.id);
    const hasFlat = p.populationCost !== undefined;
    const hasFraction = p.populationFraction !== undefined;
    if (hasFlat === hasFraction) {
      throw new Error(
        `transcendence.ts: blood pact "${p.id}" must set exactly one of populationCost / populationFraction`
      );
    }
    if (hasFlat && (p.populationCost as number) <= 0) {
      throw new Error(`transcendence.ts: blood pact "${p.id}" has non-positive populationCost`);
    }
    if (hasFraction) {
      const frac = p.populationFraction as number;
      if (frac <= 0 || frac > 1) {
        throw new Error(
          `transcendence.ts: blood pact "${p.id}" populationFraction must be in (0, 1]`
        );
      }
    }
    if (p.divinityGain <= 0) {
      throw new Error(`transcendence.ts: blood pact "${p.id}" has non-positive divinityGain`);
    }
    if (p.happinessCost > 0) {
      throw new Error(`transcendence.ts: blood pact "${p.id}" happinessCost must be ≤ 0`);
    }
    if (p.limitPerRun < 1) {
      throw new Error(`transcendence.ts: blood pact "${p.id}" limitPerRun must be ≥ 1`);
    }
  }
})();

// =====================================================================
// Helpers
// =====================================================================

/**
 * Sum the production multiplier bonus from active rituals.
 *
 * Counts `mode: "mult"` effects with target "production":
 *   - Temporary rituals (with a `duration`) whose remaining timer > 0.
 *   - Permanent rituals (no `duration`) that were performed this run.
 *
 * Used by the production / gold multiplier in the tick loop. Note: Golden
 * Hand also grants a +20% bonus to `gold` — that bonus is NOT counted here
 * (this helper is production-only). The gold multiplier should call a
 * sibling helper or read the effect list directly. For now both bonuses
 * share the same value (0.20), so wiring only the production side here is
 * sufficient for the Layer 3 data file; the gold-side wiring is a store
 * responsibility.
 *
 * @param ritualTimers  Remaining seconds for each temporary ritual (id → seconds).
 * @param ritualsUsed   Rituals performed this run (id → true).
 * @returns Additive production multiplier (0.20 = +20%).
 *
 * @example
 *   activeRitualProductionBonus({}, {})
 *     // → 0  (no rituals performed)
 *   activeRitualProductionBonus({ fertile_bloom: 60 }, { fertile_bloom: true })
 *     // → 0  (Fertile Bloom affects population_growth, not production)
 *   activeRitualProductionBonus({ insight_burst: 60 }, { insight_burst: true })
 *     // → 0  (Insight Burst affects science, not production)
 *   activeRitualProductionBonus({}, { golden_hand: true })
 *     // → 0.20  (Golden Hand's permanent +20% production)
 */
export function activeRitualProductionBonus(
  ritualTimers: Record<string, number>,
  ritualsUsed: Record<string, boolean>,
): number {
  let total = 0;
  for (const ritual of RITUALS) {
    if (!ritualsUsed[ritual.id]) continue;
    if (ritual.duration !== undefined) {
      // Temporary ritual — only contributes while the timer is positive.
      if ((ritualTimers[ritual.id] || 0) <= 0) continue;
    }
    for (const eff of ritual.effects) {
      if (eff.mode !== "mult") continue;
      if (eff.target === "production") {
        total += eff.value;
      }
    }
  }
  return total;
}

/**
 * Sum the population-growth multiplier bonus from active rituals.
 *
 * Counts `mode: "mult"` effects with target "population_growth":
 *   - Temporary rituals (with a `duration`) whose remaining timer > 0.
 *   - Permanent rituals (no `duration`) that were performed this run.
 *
 * The result is additive on top of the baseline population growth rate
 * (a value of 1.0 means "×2 growth"; 0.5 means "×1.5 growth").
 *
 * @param ritualTimers  Remaining seconds for each temporary ritual (id → seconds).
 * @param ritualsUsed   Rituals performed this run (id → true).
 * @returns Additive population-growth multiplier (1.0 = +100%, i.e. ×2 growth).
 *
 * @example
 *   activeRitualPopMult({ fertile_bloom: 60 }, { fertile_bloom: true })
 *     // → 1.0  (Fertile Bloom: ×2 growth = +1.0 additive)
 *   activeRitualPopMult({ fertile_bloom: 0 }, { fertile_bloom: true })
 *     // → 0  (timer expired — ritual no longer active)
 *   activeRitualPopMult({}, { golden_hand: true })
 *     // → 0  (Golden Hand doesn't affect population_growth)
 */
export function activeRitualPopMult(
  ritualTimers: Record<string, number>,
  ritualsUsed: Record<string, boolean>,
): number {
  let total = 0;
  for (const ritual of RITUALS) {
    if (!ritualsUsed[ritual.id]) continue;
    if (ritual.duration !== undefined) {
      if ((ritualTimers[ritual.id] || 0) <= 0) continue;
    }
    for (const eff of ritual.effects) {
      if (eff.mode !== "mult") continue;
      if (eff.target === "population_growth") {
        total += eff.value;
      }
    }
  }
  return total;
}

/**
 * Total Divinity/sec generated by Transcendence mechanics.
 *
 * Sums:
 *   - The Prayer Mill script's `divinity_per_sec` value, while the script is active.
 *   - The Eternal Well ritual's +0.05 divinity/s permanent-for-run effect, if
 *     the ritual was performed this run.
 *
 * Used by the tick loop to add to the player's `divinity` resource each second.
 *
 * @param activeScripts  Currently-toggled scripts (id → true).
 * @param ritualsUsed    Rituals performed this run (id → true).
 * @returns Divinity generated per second.
 *
 * @example
 *   transcendenceDivinityPerSecond({}, {})
 *     // → 0
 *   transcendenceDivinityPerSecond({ prayer_mill: true }, {})
 *     // → 0.01
 *   transcendenceDivinityPerSecond({}, { eternal_well: true })
 *     // → 0.05
 *   transcendenceDivinityPerSecond({ prayer_mill: true }, { eternal_well: true })
 *     // → 0.06
 */
export function transcendenceDivinityPerSecond(
  activeScripts: Record<string, boolean>,
  ritualsUsed: Record<string, boolean>,
): number {
  let total = 0;
  // Prayer Mill script contribution (active toggle).
  if (activeScripts["prayer_mill"]) {
    const prayerMill = SCRIPT_MAP["prayer_mill"];
    if (prayerMill && prayerMill.behavior.kind === "divinity_per_sec") {
      total += prayerMill.behavior.value;
    }
  }
  // Eternal Well ritual contribution (permanent for run after purchase).
  if (ritualsUsed["eternal_well"]) {
    const eternalWell = RITUAL_MAP["eternal_well"];
    if (eternalWell) {
      for (const eff of eternalWell.effects) {
        if (eff.target === "divinity_per_sec" && eff.mode === "flat_per_sec") {
          total += eff.value;
        }
      }
    }
  }
  return total;
}
