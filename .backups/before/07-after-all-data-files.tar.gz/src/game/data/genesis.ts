// Genesis — Layer 4 prestige content
//
// When a god reaches Genesis it becomes a true creator. Before life begins, it
// defines cradle worlds, sacred geography, and dormant seeds — the conditions
// under which the next universe will wake. The next run inherits these
// authored choices as starting state.
//
// Five authored facets compose a Cradle World:
//
//   1. Cradle World (8)         — origin world type that biases starting
//                                  resources / archetype / caps / EP reward.
//   2. Prime Condition (6)      — starting boon (resources / pop / cap /
//                                  production / starting tech).
//   3. Sacred Geography (4)     — map template with run-long production /
//                                  cap / pop-growth trade-offs.
//   4. Dormant Seed (4)         — hidden mechanic that awakens mid-run when
//                                  the player reaches the awakening stage.
//   5. Difficulty Tier (4)     — EP reward multiplier (Easy ×0.7 → Extreme ×2.5).
//
// State fields (planned for GameState — to be wired in a follow-up task):
//   - worldConfig: WorldConfig | null                 // authored choices; null before Layer 4
//   - dormantSeedAwakened: boolean                    // whether the dormant seed has awoken this run
//
// Advancement to Layer 5 (Apotheosis) requires authoring a complete Cradle
// World (all 5 facets set) — see prestigeLayers.ts
// `genesis.completeState: "Author a complete Cradle World (all 5 facets set)"`.

import type { ResourceId, StageId } from "../state/types";
import { RESOURCES } from "./resources";

// =====================================================================
// Cap bonus model — shared by Cradle Worlds, Prime Conditions, Sacred
// Geography, and (when awakened) the Vault Seed dormant seed.
// =====================================================================

/**
 * A capacity bonus applied to either a specific list of resources or to
 * every resource ("all"). `value` is additive on top of the baseline cap,
 * e.g. `0.50` = +50% cap, `-0.10` = -10% cap.
 *
 * `target: "all"` expands to every entry in `RESOURCES` (see `worldCapMult`).
 * For per-resource boosts, list the specific ResourceIds (e.g. Crystal
 * Cradle's +50% to stone & alloys).
 */
export interface WorldCapBonus {
  target: ResourceId[] | "all";
  value: number;
}

// =====================================================================
// 1. Cradle Worlds (8) — origin world type that biases starting state
// =====================================================================

export interface CradleWorldDef {
  /** Stable identifier (matches `worldConfig.cradleWorld` in GameState). */
  id: string;
  /** Human-readable cradle world name. */
  name: string;
  /** Narrative / mechanical flavour describing the cradle's nature. */
  desc: string;
  /** Emoji glyph shown on the cradle card. */
  icon: string;
  /** Resources granted at run start. `happiness` here is read by `worldStartHappinessBonus`. */
  startResources?: Partial<Record<ResourceId, number>>;
  /** Archetype id to bias toward during affinity drift (e.g. "lithoid"). */
  archetypeBias?: string;
  /** Additive production multiplier (0.05 = +5% all production). */
  productionMult?: number;
  /** Capacity bonuses — global ("all") or per-resource. */
  capBonuses?: WorldCapBonus[];
  /** Additive EP reward multiplier (0.25 = +25% EP on prestige). */
  epRewardMult?: number;
}

export const CRADLE_WORLDS: CradleWorldDef[] = [
  {
    id: "primordial_soup",
    name: "Primordial Soup",
    desc: "A warm broth of carbon and lightning. Life stirs where chemistry permits.",
    icon: "🥣",
    startResources: { glucose: 10, proteins: 5 },
  },
  {
    id: "crystal_cradle",
    name: "Crystal Cradle",
    desc: "A lattice of living stone. The first cells take shape as mineral geometries.",
    icon: "💎",
    archetypeBias: "lithoid",
    capBonuses: [{ target: ["stone", "alloys"], value: 0.50 }],
  },
  {
    id: "ashen_womb",
    name: "Ashen Womb",
    desc: "Volcanic heat and sulfur. The cradle of those who thrive where nothing should.",
    icon: "🌋",
    startResources: { atp: 15 },
    archetypeBias: "extremophile",
    productionMult: 0.05,
  },
  {
    id: "verdant_eden",
    name: "Verdant Eden",
    desc: "Lush and wet and singing. The garden that needs no tending.",
    icon: "🌳",
    startResources: { food: 10, water: 5, happiness: 5 },
  },
  {
    id: "frozen_origin",
    name: "Frozen Origin",
    desc: "A world held in ice. What endures here, endures forever.",
    icon: "❄️",
    archetypeBias: "lithoid",
    capBonuses: [{ target: "all", value: 0.20 }],
  },
  {
    id: "salt_abyss",
    name: "Salt Abyss",
    desc: "Brine and venom. The cradle of those who turn poison into breath.",
    icon: "🧂",
    startResources: { proteins: 5, lipids: 5 },
    archetypeBias: "toxoid",
  },
  {
    id: "rotbloom_basin",
    name: "Rotbloom Basin",
    desc: "Decay made fertile. The dead feed the living and the living feed the dead.",
    icon: "🥀",
    startResources: { organic_matter: 10, culture: 3 },
    archetypeBias: "necroid",
  },
  {
    id: "void_basin",
    name: "Void Basin",
    desc: "Nothing and less than nothing. The creator's wager: meaning blooms from absence.",
    icon: "🕳️",
    epRewardMult: 0.25,
  },
];

export const CRADLE_WORLD_MAP: Record<string, CradleWorldDef> = Object.fromEntries(
  CRADLE_WORLDS.map((c) => [c.id, c])
);

export const CRADLE_WORLD_COUNT: number = CRADLE_WORLDS.length;

// =====================================================================
// 2. Prime Conditions (6) — starting boons
// =====================================================================

export interface PrimeConditionDef {
  /** Stable identifier (matches `worldConfig.primeCondition` in GameState). */
  id: string;
  /** Human-readable prime condition name. */
  name: string;
  /** Narrative / mechanical flavour of the boon. */
  desc: string;
  /** Emoji glyph shown on the condition card. */
  icon: string;
  /** Resources granted at run start. */
  startResources?: Partial<Record<ResourceId, number>>;
  /** Flat starting population bonus (added to baseline starting pop). */
  startPopulation?: number;
  /** Additive production multiplier (0.05 = +5% all production). */
  productionMult?: number;
  /** Capacity bonuses — global ("all") or per-resource. */
  capBonuses?: WorldCapBonus[];
  /** Tech id granted as researched at run start (e.g. "mining" for Abundant Minerals). */
  startTech?: string;
}

export const PRIME_CONDITIONS: PrimeConditionDef[] = [
  {
    id: "fertile_soil",
    name: "Fertile Soil",
    desc: "The land is rich and willing. Happiness and food cap rise with the harvest.",
    icon: "🌱",
    startResources: { happiness: 5 },
    capBonuses: [{ target: ["food"], value: 0.10 }],
  },
  {
    id: "abundant_minerals",
    name: "Abundant Minerals",
    desc: "The crust gives freely. The people begin knowing how to dig.",
    icon: "⛏️",
    startTech: "mining",
  },
  {
    id: "stable_geology",
    name: "Stable Geology",
    desc: "Solid ground, settled people. Populations thrive and works proceed apace.",
    icon: "🪨",
    startPopulation: 10,
    productionMult: 0.05,
  },
  {
    id: "warm_currents",
    name: "Warm Currents",
    desc: "Mild oceans and gentle rain. Water and food flow abundantly.",
    icon: "🌊",
    startResources: { water: 5, food: 5 },
  },
  {
    id: "ancient_relics",
    name: "Ancient Relics",
    desc: "The bones of a prior age. Knowledge and culture echo from before.",
    icon: "🏺",
    startResources: { knowledge: 5, culture: 3 },
  },
  {
    id: "lucky_stars",
    name: "Lucky Stars",
    desc: "The heavens align. Every work of the new world runs a little richer.",
    icon: "🍀",
    productionMult: 0.10,
  },
];

export const PRIME_CONDITION_MAP: Record<string, PrimeConditionDef> = Object.fromEntries(
  PRIME_CONDITIONS.map((p) => [p.id, p])
);

export const PRIME_CONDITION_COUNT: number = PRIME_CONDITIONS.length;

// =====================================================================
// 3. Sacred Geography (4) — map templates with run-long trade-offs
// =====================================================================

export interface SacredGeographyDef {
  /** Stable identifier (matches `worldConfig.sacredGeography` in GameState). */
  id: string;
  /** Human-readable geography name. */
  name: string;
  /** Narrative / mechanical flavour of the map template. */
  desc: string;
  /** Emoji glyph shown on the geography card. */
  icon: string;
  /** Additive production multiplier (signed; e.g. 0.10 = +10%, -0.05 = -5%). */
  productionMult?: number;
  /** Capacity bonuses — global ("all") or per-resource. Signed values. */
  capBonuses?: WorldCapBonus[];
  /** Additive population-growth multiplier (0.20 = +20% pop growth). */
  populationGrowthMult?: number;
}

export const SACRED_GEOGRAPHIES: SacredGeographyDef[] = [
  {
    id: "archipelago",
    name: "Archipelago",
    desc: "Many islands, many shores, many small havens. Caps rise, but works are scattered.",
    icon: "🏝️",
    productionMult: -0.05,
    capBonuses: [{ target: "all", value: 0.15 }],
  },
  {
    id: "great_continent",
    name: "Great Continent",
    desc: "One vast landmass under one sky. Production surges; the land holds steady.",
    icon: "🌎",
    productionMult: 0.10,
    capBonuses: [{ target: "all", value: 0.05 }],
  },
  {
    id: "ringed_ocean",
    name: "Ringed Ocean",
    desc: "A world-ocean girdled by reefs. People multiply; the works of hands slow.",
    icon: "🪐",
    productionMult: -0.10,
    populationGrowthMult: 0.20,
  },
  {
    id: "skylands",
    name: "Skylands",
    desc: "Floating islands hung in the air. Production soars; storage is the price.",
    icon: "☁️",
    productionMult: 0.15,
    capBonuses: [{ target: "all", value: -0.10 }],
  },
];

export const SACRED_GEOGRAPHY_MAP: Record<string, SacredGeographyDef> = Object.fromEntries(
  SACRED_GEOGRAPHIES.map((g) => [g.id, g])
);

export const SACRED_GEOGRAPHY_COUNT: number = SACRED_GEOGRAPHIES.length;

// =====================================================================
// 4. Dormant Seeds (4) — hidden mechanics that awaken mid-run
// =====================================================================

/**
 * A dormant seed sits silent at run start, then awakens when the player
 * reaches `awakeningStage`. Exactly one of the effect fields below should
 * be set (validator-enforced).
 *
 * Effect field → consumer wiring:
 *   - `productionMult`: add to the global production multiplier for the
 *     remainder of the run (Growth Seed).
 *   - `capBonuses`: apply as an additional cap bonus to all resources
 *     for the remainder of the run (Vault Seed).
 *   - `divinityFlat`: one-time flat grant to the `divinity` resource when
 *     the seed awakens (Wisdom Seed).
 *   - `freeRandomTech`: the store grants one free random tech from the
 *     currently-available tech pool (Ascension Seed). This is a flag-style
 *     effect; the consumer performs the grant and clears the flag, like
 *     Transcendence's `break_through` ritual.
 */
export interface DormantSeedDef {
  /** Stable identifier (matches `worldConfig.dormantSeed` in GameState). */
  id: string;
  /** Human-readable dormant seed name. */
  name: string;
  /** Narrative / mechanical flavour of the seed and its awakening. */
  desc: string;
  /** Emoji glyph shown on the seed card. */
  icon: string;
  /** Stage at which the seed awakens. */
  awakeningStage: StageId;
  /** Additive all-production multiplier granted for the rest of the run. */
  productionMult?: number;
  /** Global capacity bonus granted for the rest of the run. */
  capBonuses?: WorldCapBonus[];
  /** One-time flat grant to `divinity` upon awakening. */
  divinityFlat?: number;
  /** If true, the store grants one free random tech upon awakening. */
  freeRandomTech?: boolean;
}

export const DORMANT_SEEDS: DormantSeedDef[] = [
  {
    id: "growth_seed",
    name: "Growth Seed",
    desc: "A dormant pulse of vitality. At the Creature stage it blooms — +10% all production for the run.",
    icon: "🌱",
    awakeningStage: "creature",
    productionMult: 0.10,
  },
  {
    id: "wisdom_seed",
    name: "Wisdom Seed",
    desc: "A silent kernel of insight. At the Tribal stage it opens — +5 Divinity, granted in full.",
    icon: "🦉",
    awakeningStage: "tribal",
    divinityFlat: 5,
  },
  {
    id: "vault_seed",
    name: "Vault Seed",
    desc: "A buried chamber of capacity. At the Civilization stage it unseals — +15% to all caps for the run.",
    icon: "🏛️",
    awakeningStage: "civilization",
    capBonuses: [{ target: "all", value: 0.15 }],
  },
  {
    id: "ascension_seed",
    name: "Ascension Seed",
    desc: "A secret path to the stars. At the Solar stage it ignites — one free random tech, yours.",
    icon: "✨",
    awakeningStage: "solar",
    freeRandomTech: true,
  },
];

export const DORMANT_SEED_MAP: Record<string, DormantSeedDef> = Object.fromEntries(
  DORMANT_SEEDS.map((s) => [s.id, s])
);

export const DORMANT_SEED_COUNT: number = DORMANT_SEEDS.length;

// =====================================================================
// 5. Difficulty Tiers (4) — EP reward multiplier
// =====================================================================

export interface DifficultyTierDef {
  /** Stable identifier (matches `worldConfig.difficulty` in GameState). */
  id: string;
  /** Human-readable difficulty name. */
  name: string;
  /** Narrative / mechanical flavour of the difficulty. */
  desc: string;
  /** Emoji glyph shown on the difficulty card. */
  icon: string;
  /** Multiplier applied to EP earned on prestige (Easy 0.7 → Extreme 2.5). */
  epMultiplier: number;
}

export const DIFFICULTY_TIERS: DifficultyTierDef[] = [
  {
    id: "easy",
    name: "Easy",
    desc: "A gentle world. The creator's hand rests lightly; EP rewards are reduced.",
    icon: "🌱",
    epMultiplier: 0.7,
  },
  {
    id: "normal",
    name: "Normal",
    desc: "A balanced world. The standard measure of struggle and reward.",
    icon: "⚖️",
    epMultiplier: 1.0,
  },
  {
    id: "hard",
    name: "Hard",
    desc: "A demanding world. Survival earns 60% more EP than the standard measure.",
    icon: "🔥",
    epMultiplier: 1.6,
  },
  {
    id: "extreme",
    name: "Extreme",
    desc: "A punishing world. The creator's wager is total; EP rewards are 2.5× the standard.",
    icon: "💀",
    epMultiplier: 2.5,
  },
];

export const DIFFICULTY_MAP: Record<string, DifficultyTierDef> = Object.fromEntries(
  DIFFICULTY_TIERS.map((d) => [d.id, d])
);

export const DIFFICULTY_COUNT: number = DIFFICULTY_TIERS.length;

// =====================================================================
// 6. WorldConfig — the authored choices that define the next run
// =====================================================================

/**
 * A fully-authored Cradle World. All five facets must be set for the
 * Genesis layer to count as "complete" (see prestigeLayers.ts
 * `genesis.completeState`).
 *
 * Stored on `GameState.worldConfig` after Layer 4 unlocks. Consumers
 * (initialRunState, tick loop, EP calc) read the helpers below to
 * extract the mechanical implications of the chosen facets.
 */
export interface WorldConfig {
  cradleWorld: string;
  primeCondition: string;
  sacredGeography: string;
  dormantSeed: string;
  difficulty: string;
}

// =====================================================================
// Module-load sanity checks
// =====================================================================

/**
 * Validate the genesis data at module load:
 *   - All ids within each family are unique.
 *   - All cradle world `archetypeBias` ids exist in the archetype set
 *     (checked against the 13 known archetypes).
 *   - Each dormant seed sets exactly one of `productionMult` /
 *     `capBonuses` / `divinityFlat` / `freeRandomTech`.
 *   - Dormant seed `divinityFlat` is positive when set.
 *   - Difficulty `epMultiplier` is positive.
 *
 * Throws on any violation (programmer error, not a runtime / save data
 * error). The check is O(N) and runs once, so it's a no-op on the hot
 * path. Matches the pattern established by `transcendence.ts` and
 * `foresight.ts`.
 */
(function validateGenesisData(): void {
  const KNOWN_ARCHETYPES = new Set<string>([
    "humanoid", "mammalian", "reptilian", "avian", "arthropoid",
    "molluscoid", "fungoid", "plantoid", "aquatic",
    "lithoid", "necroid", "toxoid", "extremophile",
  ]);

  const seenCradle = new Set<string>();
  for (const c of CRADLE_WORLDS) {
    if (seenCradle.has(c.id)) {
      throw new Error(`genesis.ts: duplicate cradle world id "${c.id}"`);
    }
    seenCradle.add(c.id);
    if (c.archetypeBias && !KNOWN_ARCHETYPES.has(c.archetypeBias)) {
      throw new Error(
        `genesis.ts: cradle world "${c.id}" has unknown archetypeBias "${c.archetypeBias}"`
      );
    }
    if (c.productionMult !== undefined && c.productionMult < 0) {
      throw new Error(`genesis.ts: cradle world "${c.id}" has negative productionMult`);
    }
    if (c.epRewardMult !== undefined && c.epRewardMult < 0) {
      throw new Error(`genesis.ts: cradle world "${c.id}" has negative epRewardMult`);
    }
  }

  const seenPrime = new Set<string>();
  for (const p of PRIME_CONDITIONS) {
    if (seenPrime.has(p.id)) {
      throw new Error(`genesis.ts: duplicate prime condition id "${p.id}"`);
    }
    seenPrime.add(p.id);
    if (p.productionMult !== undefined && p.productionMult < 0) {
      throw new Error(`genesis.ts: prime condition "${p.id}" has negative productionMult`);
    }
    if (p.startPopulation !== undefined && p.startPopulation < 0) {
      throw new Error(`genesis.ts: prime condition "${p.id}" has negative startPopulation`);
    }
  }

  const seenGeo = new Set<string>();
  for (const g of SACRED_GEOGRAPHIES) {
    if (seenGeo.has(g.id)) {
      throw new Error(`genesis.ts: duplicate sacred geography id "${g.id}"`);
    }
    seenGeo.add(g.id);
  }

  const seenSeed = new Set<string>();
  for (const s of DORMANT_SEEDS) {
    if (seenSeed.has(s.id)) {
      throw new Error(`genesis.ts: duplicate dormant seed id "${s.id}"`);
    }
    seenSeed.add(s.id);
    const effects = [
      s.productionMult !== undefined,
      s.capBonuses !== undefined,
      s.divinityFlat !== undefined,
      s.freeRandomTech !== undefined,
    ].filter(Boolean).length;
    if (effects !== 1) {
      throw new Error(
        `genesis.ts: dormant seed "${s.id}" must set exactly one effect (set ${effects})`
      );
    }
    if (s.divinityFlat !== undefined && s.divinityFlat <= 0) {
      throw new Error(`genesis.ts: dormant seed "${s.id}" has non-positive divinityFlat`);
    }
    if (s.productionMult !== undefined && s.productionMult < 0) {
      throw new Error(`genesis.ts: dormant seed "${s.id}" has negative productionMult`);
    }
  }

  const seenDiff = new Set<string>();
  for (const d of DIFFICULTY_TIERS) {
    if (seenDiff.has(d.id)) {
      throw new Error(`genesis.ts: duplicate difficulty id "${d.id}"`);
    }
    seenDiff.add(d.id);
    if (d.epMultiplier <= 0) {
      throw new Error(`genesis.ts: difficulty "${d.id}" has non-positive epMultiplier`);
    }
  }
})();

// =====================================================================
// 7. Helpers
// =====================================================================

/**
 * Apply a `WorldCapBonus` to an accumulator map. "all" expands to every
 * entry in `RESOURCES`; otherwise the listed ResourceIds are incremented.
 *
 * Internal helper used by `worldCapMult`.
 */
function applyCapBonus(
  acc: Partial<Record<ResourceId, number>>,
  bonus: WorldCapBonus
): void {
  if (bonus.target === "all") {
    for (const r of RESOURCES) {
      acc[r.id] = (acc[r.id] ?? 0) + bonus.value;
    }
  } else {
    for (const rid of bonus.target) {
      acc[rid] = (acc[rid] ?? 0) + bonus.value;
    }
  }
}

/**
 * Sum the additive production multiplier from all authored facets.
 *
 * Sources (all additive, e.g. 0.05 + 0.10 = 0.15 = +15%):
 *   - Cradle World:    Ashen Womb (+5%)
 *   - Prime Condition: Stable Geology (+5%), Lucky Stars (+10%)
 *   - Sacred Geography: Archipelago (-5%), Great Continent (+10%),
 *                       Ringed Ocean (-10%), Skylands (+15%)
 *   - Dormant Seed:    Growth Seed (+10%) — only counted when `awakened`
 *
 * @param config     The authored WorldConfig.
 * @param awakened   Whether the dormant seed has awakened this run.
 * @returns Additive production multiplier (0.10 = +10% all production).
 *
 * @example
 *   worldProductionMult({cradleWorld:"ashen_womb", primeCondition:"lucky_stars",
 *     sacredGeography:"great_continent", dormantSeed:"growth_seed",
 *     difficulty:"normal"}, false)
 *     // → 0.25  (0.05 + 0.10 + 0.10; growth seed not yet awakened)
 *   worldProductionMult({...same...}, true)
 *     // → 0.35  (+0.10 from awakened Growth Seed)
 */
export function worldProductionMult(
  config: WorldConfig,
  awakened: boolean
): number {
  let total = 0;

  const cradle = CRADLE_WORLD_MAP[config.cradleWorld];
  if (cradle?.productionMult) total += cradle.productionMult;

  const prime = PRIME_CONDITION_MAP[config.primeCondition];
  if (prime?.productionMult) total += prime.productionMult;

  const geo = SACRED_GEOGRAPHY_MAP[config.sacredGeography];
  if (geo?.productionMult) total += geo.productionMult;

  if (awakened) {
    const seed = DORMANT_SEED_MAP[config.dormantSeed];
    if (seed?.productionMult) total += seed.productionMult;
  }

  return total;
}

/**
 * Sum the additive capacity multiplier per resource from all authored
 * facets.
 *
 * Sources:
 *   - Cradle World:    Crystal Cradle (+50% stone & alloys),
 *                       Frozen Origin (+20% all)
 *   - Prime Condition: Fertile Soil (+10% food)
 *   - Sacred Geography: Archipelago (+15% all), Great Continent (+5% all),
 *                       Skylands (-10% all)
 *   - Dormant Seed:    Vault Seed (+15% all) — only counted when `awakened`
 *
 * Global ("all") bonuses are expanded across every resource in
 * `RESOURCES`; per-resource bonuses only affect the listed resources.
 *
 * @param config     The authored WorldConfig.
 * @param awakened   Whether the dormant seed has awakened this run.
 * @returns Per-resource additive cap multiplier map (0.50 = +50% cap).
 *
 * @example
 *   worldCapMult({cradleWorld:"crystal_cradle", primeCondition:"fertile_soil",
 *     sacredGeography:"archipelago", dormantSeed:"vault_seed",
 *     difficulty:"normal"}, false)
 *     // → { stone: 0.65, alloys: 0.65, food: 0.25, ...allOthers: 0.15 }
 *        (crystal +50% to stone/alloys, fertile +10% to food,
 *         archipelago +15% to all, vault seed not yet awakened)
 *   worldCapMult({...same...}, true)
 *     // → vault seed adds another +0.15 to every resource
 */
export function worldCapMult(
  config: WorldConfig,
  awakened: boolean
): Partial<Record<ResourceId, number>> {
  const acc: Partial<Record<ResourceId, number>> = {};

  const cradle = CRADLE_WORLD_MAP[config.cradleWorld];
  if (cradle?.capBonuses) {
    for (const b of cradle.capBonuses) applyCapBonus(acc, b);
  }

  const prime = PRIME_CONDITION_MAP[config.primeCondition];
  if (prime?.capBonuses) {
    for (const b of prime.capBonuses) applyCapBonus(acc, b);
  }

  const geo = SACRED_GEOGRAPHY_MAP[config.sacredGeography];
  if (geo?.capBonuses) {
    for (const b of geo.capBonuses) applyCapBonus(acc, b);
  }

  if (awakened) {
    const seed = DORMANT_SEED_MAP[config.dormantSeed];
    if (seed?.capBonuses) {
      for (const b of seed.capBonuses) applyCapBonus(acc, b);
    }
  }

  return acc;
}

/**
 * Sum the additive population-growth multiplier from the authored
 * Sacred Geography. No other facet affects pop growth in the current
 * data set, so this helper only reads the geography.
 *
 * Sources:
 *   - Sacred Geography: Ringed Ocean (+20% pop growth)
 *
 * The dormant seed does NOT affect pop growth in the current data set,
 * so `awakened` is not a parameter.
 *
 * @param config  The authored WorldConfig.
 * @returns Additive pop-growth multiplier (0.20 = +20% pop growth).
 *
 * @example
 *   worldPopGrowthMult({sacredGeography:"ringed_ocean", ...})
 *     // → 0.20
 *   worldPopGrowthMult({sacredGeography:"great_continent", ...})
 *     // → 0
 */
export function worldPopGrowthMult(config: WorldConfig): number {
  const geo = SACRED_GEOGRAPHY_MAP[config.sacredGeography];
  return geo?.populationGrowthMult ?? 0;
}

/**
 * Aggregate the starting resource bonuses from the authored Cradle
 * World and Prime Condition.
 *
 * Sources:
 *   - Cradle World:    Primordial Soup (+10 glucose, +5 proteins),
 *                       Ashen Womb (+15 ATP), Verdant Eden (+10 food, +5 water,
 *                       +5 happiness), Salt Abyss (+5 proteins, +5 lipids),
 *                       Rotbloom Basin (+10 organic matter, +3 culture)
 *   - Prime Condition: Fertile Soil (+5 happiness), Warm Currents (+5 water,
 *                       +5 food), Ancient Relics (+5 knowledge, +3 culture)
 *
 * `happiness` is included in the returned map; `worldStartHappinessBonus`
 * reads it back out as a convenience.
 *
 * Dormant seeds do NOT grant starting resources (they awaken mid-run),
 * so they are not consulted here.
 *
 * @param config  The authored WorldConfig.
 * @returns Partial resource → amount map (additive on top of baseline).
 *
 * @example
 *   worldStartResourceBonus({cradleWorld:"primordial_soup",
 *     primeCondition:"warm_currents", ...})
 *     // → { glucose: 10, proteins: 5, water: 5, food: 5 }
 */
export function worldStartResourceBonus(
  config: WorldConfig
): Partial<Record<ResourceId, number>> {
  const acc: Partial<Record<ResourceId, number>> = {};

  const cradle = CRADLE_WORLD_MAP[config.cradleWorld];
  if (cradle?.startResources) {
    for (const [rid, amt] of Object.entries(cradle.startResources)) {
      acc[rid as ResourceId] = (acc[rid as ResourceId] ?? 0) + (amt as number);
    }
  }

  const prime = PRIME_CONDITION_MAP[config.primeCondition];
  if (prime?.startResources) {
    for (const [rid, amt] of Object.entries(prime.startResources)) {
      acc[rid as ResourceId] = (acc[rid as ResourceId] ?? 0) + (amt as number);
    }
  }

  return acc;
}

/**
 * Total EP reward multiplier — the product of the difficulty tier's
 * base multiplier and the cradle world's EP reward bonus.
 *
 * Sources:
 *   - Difficulty:    Easy ×0.7, Normal ×1.0, Hard ×1.6, Extreme ×2.5
 *   - Cradle World:  Void Basin (+25% EP reward)
 *
 * The cradle world's `epRewardMult` is additive on top of the difficulty
 * base, so the total is `difficulty.epMultiplier * (1 + cradle.epRewardMult)`.
 * For Void Basin on Normal: `1.0 * (1 + 0.25) = 1.25`.
 *
 * @param config  The authored WorldConfig.
 * @returns Final EP multiplier to apply to prestige-earned EP.
 *
 * @example
 *   worldEpMultiplier({cradleWorld:"void_basin", difficulty:"normal", ...})
 *     // → 1.25  (1.0 × 1.25)
 *   worldEpMultiplier({cradleWorld:"primordial_soup", difficulty:"extreme", ...})
 *     // → 2.5   (2.5 × 1.0)
 *   worldEpMultiplier({cradleWorld:"void_basin", difficulty:"hard", ...})
 *     // → 2.0   (1.6 × 1.25)
 */
export function worldEpMultiplier(config: WorldConfig): number {
  const diff = DIFFICULTY_MAP[config.difficulty];
  const base = diff?.epMultiplier ?? 1.0;

  const cradle = CRADLE_WORLD_MAP[config.cradleWorld];
  const bonus = cradle?.epRewardMult ?? 0;

  return base * (1 + bonus);
}

/**
 * Flat starting population bonus from the authored Prime Condition.
 *
 * Sources:
 *   - Prime Condition: Stable Geology (+10 pop)
 *
 * @param config  The authored WorldConfig.
 * @returns Flat population bonus to add to the baseline starting pop.
 *
 * @example
 *   worldStartPopulationBonus({primeCondition:"stable_geology", ...})
 *     // → 10
 *   worldStartPopulationBonus({primeCondition:"fertile_soil", ...})
 *     // → 0
 */
export function worldStartPopulationBonus(config: WorldConfig): number {
  const prime = PRIME_CONDITION_MAP[config.primeCondition];
  return prime?.startPopulation ?? 0;
}

/**
 * Flat starting happiness bonus aggregated from the authored Cradle
 * World and Prime Condition. Reads the `happiness` key out of
 * `worldStartResourceBonus` for convenience.
 *
 * Sources:
 *   - Cradle World:    Verdant Eden (+5 happiness)
 *   - Prime Condition: Fertile Soil (+5 happiness)
 *
 * @param config  The authored WorldConfig.
 * @returns Flat happiness bonus to add to the baseline starting happiness.
 *
 * @example
 *   worldStartHappinessBonus({cradleWorld:"verdant_eden",
 *     primeCondition:"fertile_soil", ...})
 *     // → 10  (5 + 5)
 */
export function worldStartHappinessBonus(config: WorldConfig): number {
  return worldStartResourceBonus(config).happiness ?? 0;
}

/**
 * The archetype id to bias toward during affinity drift, or `null` if
 * the authored Cradle World has no bias.
 *
 * Sources:
 *   - Cradle World:    Crystal Cradle → "lithoid",
 *                       Ashen Womb → "extremophile",
 *                       Frozen Origin → "lithoid",
 *                       Salt Abyss → "toxoid",
 *                       Rotbloom Basin → "necroid"
 *
 * The bias is applied by the store: when computing affinity drift each
 * tick, the biased archetype gains a small additional affinity (the
 * amount is a store-side tuning parameter, not defined here).
 *
 * @param config  The authored WorldConfig.
 * @returns Archetype id, or `null` if no bias.
 *
 * @example
 *   worldArchetypeBias({cradleWorld:"crystal_cradle", ...})
 *     // → "lithoid"
 *   worldArchetypeBias({cradleWorld:"primordial_soup", ...})
 *     // → null
 */
export function worldArchetypeBias(config: WorldConfig): string | null {
  const cradle = CRADLE_WORLD_MAP[config.cradleWorld];
  return cradle?.archetypeBias ?? null;
}

/**
 * The tech id to grant as already-researched at run start, or `null`
 * if the authored Prime Condition grants no starting tech.
 *
 * Sources:
 *   - Prime Condition: Abundant Minerals → "mining"
 *
 * NOTE: The `"mining"` tech id does NOT yet exist in `techs.ts` — it
 * is a forward reference. A follow-up task must add the Mining tech
 * to `techs.ts` (or rename this to `"masonry"` to use the existing
 * stone-related Tribal tech). Until then, the consumer should treat
 * an unknown tech id as a no-op (or log a warning). See the
 * "Unresolved Issues / Risks" section of the worklog entry for
 * Task L4-data.
 *
 * @param config  The authored WorldConfig.
 * @returns Tech id to mark as researched, or `null` if none.
 *
 * @example
 *   worldStartTech({primeCondition:"abundant_minerals", ...})
 *     // → "mining"
 *   worldStartTech({primeCondition:"lucky_stars", ...})
 *     // → null
 */
export function worldStartTech(config: WorldConfig): string | null {
  const prime = PRIME_CONDITION_MAP[config.primeCondition];
  return prime?.startTech ?? null;
}
