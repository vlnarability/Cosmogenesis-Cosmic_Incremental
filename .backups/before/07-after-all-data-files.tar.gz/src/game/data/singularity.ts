// Singularity — Layer 6 prestige content
//
// When a god reaches Singularity it enters the machinery of reality itself.
// No longer an outside author, it becomes the substrate beneath creation:
// relic loadouts reshape passive bonuses, logic cores execute scheduled
// divine actions on the tick loop, and (in a later task) compression lets
// the god collapse redundant system tiers into denser cores.
//
// Three mechanic families are spec'd for Singularity in prestigeLayers.ts:
//   - Relic Loadouts (passive bonus triples: upside / downside / special)
//   - Compression (collapse system tiers — NOT in this file)
//   - Logic Cores   (automation priorities that run while active)
//
// This file implements TWO of those three families — Relic Loadouts and
// Logic Cores — plus the helpers `relicBonus`, `logicCoreBonus`, and
// `isSingularityComplete`. The Compression family interacts with the
// stage-band logic in store.ts (which doesn't yet exist for Layer 6), so
// it's deferred to a follow-up task; `isSingularityComplete` already
// accepts a `compressionPerformed: boolean` argument so the helper is
// ready to gate advancement to Layer 7 (Omnipotence) once compression
// wiring lands.
//
// State fields (planned for GameState — to be wired in a follow-up task):
//   - activeRelic:           string | null              // equipped relic loadout id, or null
//   - installedLogicCores:   Record<string, boolean>   // installed logic cores (any subset of 6)
//   - compressionPerformed:  boolean                    // whether any system tier was compressed this run
//
// Reference: /home/z/my-project/upload/data.js DATA.LOGIC_CORES (lines
// 270-277) for the original vanilla-JS shapes (7 cores including a
// "balanced" placeholder). The TS port reshapes each core into a spec-
// aligned subset of 6 cores with explicit per-tick effects. The Relic
// Loadout family is new to the port — the vanilla JS had stage-keyed
// `MASTERY_RELICS` (one relic per stage) and a single slot system, but
// no "loadout" with an upside/downside/special-interaction triple.
//
// Advancement to Layer 7 (Omnipotence) requires installing 3 Logic Cores
// AND compressing one system tier — see prestigeLayers.ts
// `singularity.completeState: "Install 3 Logic Cores and Compress one system tier"`.

import type { ResourceId } from "../state/types";

// =====================================================================
// Constants
// =====================================================================

/**
 * Number of Logic Cores the player must install for the Layer 6
 * completion check (`isSingularityComplete`). Matches the spec wording
 * "Install 3 Logic Cores and Compress one system tier" from
 * prestigeLayers.ts. The dataset defines 6 cores total, so this is half
 * of the available pool — a meaningful but not exhaustive commitment.
 */
export const SINGULARITY_COMPLETION_CORES_REQUIRED: number = 3;

/**
 * Maximum number of Logic Cores the player can install in a single run.
 *
 * The dataset has exactly 6 cores; the cap is enforced as `Object.keys(
 * installedLogicCores).filter(...).length <= 6` by the store, but the
 * data-side constant lives here so the validator and consumer share one
 * source of truth. A future upgrade ("Logic Core Seed" in vanilla JS
 * `DATA.FUTURE_UPGRADES.singularity`) could raise this cap; if so, bump
 * this constant or replace it with a function.
 */
export const MAX_INSTALLED_LOGIC_CORES: number = 6;

// =====================================================================
// 1. Relic Loadouts (8) — passive bonus triples: upside / downside / special
// =====================================================================

/**
 * Discriminated union of relic "special interaction" behaviors. Each
 * relic carries exactly one variant; the consumer (store / game loop)
 * reads `relic.special.kind` and dispatches accordingly.
 *
 * The special is the third leg of each relic loadout — it's what makes
 * "Singularity Core" different from a flat "+production / -caps" bonus.
 * Specials are triggerable: they fire on specific game events (tech
 * purchase, system purchase, action perform, per-tick conditional, etc.).
 *
 * Known variants:
 *
 *   - `production_floor`              Singularity Core
 *   - `pop_growth_doubles_below_pop`  Eternal Flame
 *   - `tech_cost_reduction`           Void Lens
 *   - `system_buy_gold_kickback`      Golden Idol
 *   - `caps_grow_with_happiness`      Stone Tablet
 *   - `military_event_chance_mult`    War Drum
 *   - `double_actions_producing`     Harvest Scythe
 *   - `scale_with_installed_cores`    Omni Matrix
 */
export type RelicSpecial =
  /** Production is floored at `floorMult × baseline` while the relic is equipped.
   *  Protects against other production penalties (e.g. Stone Tablet's −15%). */
  | { kind: "production_floor"; floorMult: number }
  /** Population growth rate is doubled while `state.population ≤ threshold`.
   *  Eternal Flame's "burns hottest when the world is small" flavor. */
  | { kind: "pop_growth_doubles_below_pop"; threshold: number }
  /** All tech research costs are reduced by `value` (0..1, additive on final cost).
   *  Void Lens "bends inquiry into cheaper shapes". */
  | { kind: "tech_cost_reduction"; value: number }
  /** When the player buys a system, refund `fraction` of its gold cost as a kickback.
   *  Golden Idol's "wealth returns to the worshipful". */
  | { kind: "system_buy_gold_kickback"; fraction: number }
  /** While `state.resources.happiness ≥ above`, all caps grow by `perSec` per second.
   *  Stone Tablet "swells beneath contented civilizations". */
  | { kind: "caps_grow_with_happiness"; above: number; perSec: number }
  /** Military-type random events are `value`× more likely to fire while equipped.
   *  War Drum "calls the conflicts that prove devotion". */
  | { kind: "military_event_chance_mult"; value: number }
  /** Manual actions that produce any of `resources` have their yield doubled.
   *  Harvest Scythe "cuts twice where life is gathered". */
  | { kind: "double_actions_producing"; resources: ResourceId[] }
  /** This relic's own stat bonuses are multiplied by `(1 + perCoreMult × installedLogicCoreCount)`.
   *  Omni Matrix "synergizes with the cores that run beneath it". */
  | { kind: "scale_with_installed_cores"; perCoreMult: number };

/**
 * A single Relic Loadout. Only one relic can be equipped at a time
 * (mirrors the Worship Mode pattern from apotheosis.ts — `activeRelic`
 * in GameState is a single id, not a set). The store applies the
 * equipped relic's effects each tick via `relicBonus(state.activeRelic)`.
 *
 * Effect field → consumer wiring:
 *   - `productionMult`         → additive all-production mult (Singularity Core +0.30, Stone Tablet −0.15)
 *   - `populationGrowthMult`   → additive pop-growth mult (Eternal Flame +0.50, Golden Idol −0.20)
 *   - `scienceMult`            → additive science mult (Void Lens +0.60, War Drum −0.20)
 *   - `militaryMult`           → additive military mult (Void Lens −0.30, War Drum +0.80)
 *   - `goldMult`               → additive gold mult (Golden Idol +0.40, Harvest Scythe −0.30)
 *   - `productionMult` (again) → Golden Idol also sets +0.40 production
 *   - `foodMult`               → additive food mult (Harvest Scythe +0.50)
 *   - `organicMatterMult`     → additive organic_matter mult (Harvest Scythe +0.50)
 *   - `capsMult`               → additive mult on all resource caps (Singularity Core −0.20, Stone Tablet +0.50, Omni Matrix +0.10)
 *   - `happinessDrainPerSec`  → flat per-second happiness drain (Eternal Flame −0.2, War Drum −0.3)
 *   - `special`                → discriminated union dispatched by the consumer (see `RelicSpecial`)
 *
 * All mult fields are additive on the baseline (0 = no change). Negative
 * values represent the relic's downside (e.g. Singularity Core's −20% caps).
 * `happinessDrainPerSec` is signed and typically negative (a drain);
 * the IIFE validator enforces it be ≤ 0 when set. `special` is required
 * (non-optional) — every relic has a special interaction.
 *
 * Omni Matrix is the only relic with no downside (all its stat fields
 * are non-negative, no `happinessDrainPerSec`). The validator does NOT
 * enforce that every relic has a downside — only the dataset author
 * ensures that intent.
 */
export interface RelicLoadoutDef {
  /** Stable identifier (matches `activeRelic` in GameState). */
  id: string;
  /** Human-readable relic name. */
  name: string;
  /** Narrative / mechanical flavour describing the relic's upside, downside, and special. */
  desc: string;
  /** Emoji glyph shown on the relic card. */
  icon: string;
  /** Additive all-production multiplier (0.30 = +30% all production). */
  productionMult?: number;
  /** Additive population-growth multiplier (0.50 = +50% pop growth). */
  populationGrowthMult?: number;
  /** Additive science multiplier (0.60 = +60% science). */
  scienceMult?: number;
  /** Additive military-power multiplier (0.80 = +80% military). */
  militaryMult?: number;
  /** Additive gold multiplier (0.40 = +40% gold). */
  goldMult?: number;
  /** Additive food multiplier (0.50 = +50% food). */
  foodMult?: number;
  /** Additive organic_matter multiplier (0.50 = +50% organic matter). */
  organicMatterMult?: number;
  /** Additive multiplier on every resource's cap (−0.20 = −20% all caps). */
  capsMult?: number;
  /** Flat per-second happiness drain (signed; typically negative for a drain). */
  happinessDrainPerSec?: number;
  /** The relic's special interaction — required, dispatches on `special.kind`. */
  special: RelicSpecial;
}

export const RELIC_LOADOUTS: RelicLoadoutDef[] = [
  {
    id: "singularity_core",
    name: "Singularity Core",
    desc:
      "A point of infinite density at the heart of the world. All production flows 30% richer — " +
      "but every cap is squeezed by 20%. Production never falls below half its baseline, " +
      "no matter how much else compresses around it.",
    icon: "🕳️",
    productionMult: 0.30,
    capsMult: -0.20,
    special: { kind: "production_floor", floorMult: 0.50 },
  },
  {
    id: "eternal_flame",
    name: "Eternal Flame",
    desc:
      "A fire that never goes out, fed by the joy of the living. Population grows 50% faster — " +
      "but happiness drains at 0.2 per second. While the world is small (population ≤ 50), " +
      "the flame burns hottest and growth doubles again.",
    icon: "🔥",
    populationGrowthMult: 0.50,
    happinessDrainPerSec: -0.2,
    special: { kind: "pop_growth_doubles_below_pop", threshold: 50 },
  },
  {
    id: "void_lens",
    name: "Void Lens",
    desc:
      "An aperture into the space between thoughts. Science flows 60% richer — " +
      "but the lens warps every blade and spear, and military power withers by 30%. " +
      "Inquiry bends toward cheaper shapes: all tech research costs 20% less.",
    icon: "🔭",
    scienceMult: 0.60,
    militaryMult: -0.30,
    special: { kind: "tech_cost_reduction", value: 0.20 },
  },
  {
    id: "golden_idol",
    name: "Golden Idol",
    desc:
      "A graven image that turns devotion into wealth. Gold and production both rise 40% — " +
      "but the idol's hunger slows population growth by 20%. Every system bought returns " +
      "10% of its gold cost to the worshipful.",
    icon: "🟡",
    goldMult: 0.40,
    productionMult: 0.40,
    populationGrowthMult: -0.20,
    special: { kind: "system_buy_gold_kickback", fraction: 0.10 },
  },
  {
    id: "stone_tablet",
    name: "Stone Tablet",
    desc:
      "Ancient law cut deep into bedrock. Every cap is widened by 50% — " +
      "but the weight of tradition slows production by 15%. When happiness is high (≥ 80), " +
      "the tablet swells: caps grow by +1% per second beneath contented civilizations.",
    icon: "📜",
    capsMult: 0.50,
    productionMult: -0.15,
    special: { kind: "caps_grow_with_happiness", above: 80, perSec: 0.01 },
  },
  {
    id: "war_drum",
    name: "War Drum",
    desc:
      "A hide stretched tight over a hollow frame, beaten without end. Military power surges 80% — " +
      "but the drum wears the soul: happiness drains at 0.3 per second, and science withers 20%. " +
      "The drum calls conflicts to itself: military-type events fire 50% more often.",
    icon: "🥁",
    militaryMult: 0.80,
    happinessDrainPerSec: -0.3,
    scienceMult: -0.20,
    special: { kind: "military_event_chance_mult", value: 1.50 },
  },
  {
    id: "harvest_scythe",
    name: "Harvest Scythe",
    desc:
      "A crescent blade that reaps what the world has grown. Food and organic matter flow 50% richer — " +
      "but gold is pared back by 30%. Every foraging and hunting action yields twice as much; " +
      "the scythe cuts twice where life is gathered.",
    icon: "🌾",
    foodMult: 0.50,
    organicMatterMult: 0.50,
    goldMult: -0.30,
    special: {
      kind: "double_actions_producing",
      resources: ["food", "organic_matter"],
    },
  },
  {
    id: "omni_matrix",
    name: "Omni Matrix",
    desc:
      "A lattice of every pattern at once, balanced against itself. All production and caps rise 10% — " +
      "no downside, no drain. The matrix synergizes with installed logic cores: each core multiplies " +
      "its bonuses by +1%.",
    icon: "🔷",
    productionMult: 0.10,
    capsMult: 0.10,
    special: { kind: "scale_with_installed_cores", perCoreMult: 0.01 },
  },
];

export const RELIC_LOADOUT_MAP: Record<string, RelicLoadoutDef> = Object.fromEntries(
  RELIC_LOADOUTS.map((r) => [r.id, r])
);

export const RELIC_LOADOUT_COUNT: number = RELIC_LOADOUTS.length;

// =====================================================================
// 2. Logic Cores (6) — automation priorities that run while active
// =====================================================================

/**
 * Discriminated union of logic core behaviors. Each core has exactly one
 * behavior variant; the consumer (store / game loop) reads `core.behavior.kind`
 * and dispatches accordingly.
 *
 * Two kinds are automation (Growth, Stability) — they trigger an action
 * each tick; the bonus fields on the def are unused for these. The other
 * four (Conquest, Science, Trade, Faith) are passive bonus providers —
 * their `behavior.kind` is "passive" and the consumer reads the bonus
 * fields each tick via `logicCoreBonus`.
 *
 * Known variants:
 *
 *   - `auto_evolve`           Growth Core
 *   - `happiness_drift`       Stability Core
 *   - `passive`               Conquest / Science / Trade / Faith Cores
 */
export type LogicCoreBehavior =
  /** Each tick, if the current stage's evolve requirements are met,
   *  automatically trigger `evolveStage()`. Mirrors the existing
   *  `auto_evolver` upgrade effect but at the Layer 6 scope. */
  | { kind: "auto_evolve" }
  /** Each tick, if `state.resources.happiness < below`, drift happiness
   *  upward toward `toward` at `perSec`/s. Stability Core's "happiness
   *  drifts toward 70 if below 40" — below: 40, toward: 70, perSec: 1. */
  | { kind: "happiness_drift"; below: number; toward: number; perSec: number }
  /** No automation — the core only contributes its passive bonus fields
   *  to `logicCoreBonus`. Conquest, Science, Trade, and Faith use this. */
  | { kind: "passive" };

/**
 * A single Logic Core. Up to `MAX_INSTALLED_LOGIC_CORES` (6) can be
 * installed at once; the player picks any subset of the 6 defined cores.
 * The store applies each installed core's behavior each tick.
 *
 * Effect field → consumer wiring:
 *   - `militaryMult`     → additive military mult (Conquest Core +0.20)
 *   - `scienceMult`      → additive science mult (Science Core +0.25)
 *   - `goldMult`         → additive gold mult (Trade Core +0.15)
 *   - `productionMult`   → additive production mult (Trade Core +0.15)
 *   - `divinityPerSec`   → flat Divinity/sec (Faith Core +0.02)
 *   - `behavior`         → discriminated union dispatched by the consumer
 *
 * Cores with `behavior.kind !== "passive"` (Growth, Stability) typically
 * set no bonus fields — their value is the automation, not a stat boost.
 * The validator enforces that "passive" cores set at least one bonus
 * field, and that non-passive cores set NO bonus fields (to keep the
 * boundary clean).
 *
 * `divinityPerSec` is additive on top of any other Divinity/sec source
 * (Transcendence's Eternal Well ritual +0.05, Apotheosis's Manna, etc.).
 * Faith Core's +0.02/s is intentionally modest — it's a permanent-for-
 * run passive once the core is installed, not a one-time grant.
 */
export interface LogicCoreDef {
  /** Stable identifier (used as a key in `installedLogicCores` in GameState). */
  id: string;
  /** Human-readable core name. */
  name: string;
  /** Short flavour / mechanical description of what the core does while installed. */
  desc: string;
  /** Emoji glyph shown on the core card. */
  icon: string;
  /** What the core does each tick while installed (automation or "passive"). */
  behavior: LogicCoreBehavior;
  /** Additive military-power multiplier (0.20 = +20% military). */
  militaryMult?: number;
  /** Additive science multiplier (0.25 = +25% science). */
  scienceMult?: number;
  /** Additive gold multiplier (0.15 = +15% gold). */
  goldMult?: number;
  /** Additive all-production multiplier (0.15 = +15% production). */
  productionMult?: number;
  /** Flat Divinity generated per second (0.02 = +0.02 Divinity/s). */
  divinityPerSec?: number;
}

export const LOGIC_CORES: LogicCoreDef[] = [
  {
    id: "growth_core",
    name: "Growth Core",
    desc:
      "Bias the substrate toward becoming. Each tick, if the current stage's evolve requirements " +
      "are met, the core triggers evolution automatically — no click needed.",
    icon: "🌱",
    behavior: { kind: "auto_evolve" },
  },
  {
    id: "stability_core",
    name: "Stability Core",
    desc:
      "Bias the substrate toward calm. Each tick, if happiness drops below 40, it drifts back " +
      "toward 70 at 1 per second — keeping the world just above the threshold of unrest.",
    icon: "🛡️",
    behavior: { kind: "happiness_drift", below: 40, toward: 70, perSec: 1 },
  },
  {
    id: "conquest_core",
    name: "Conquest Core",
    desc:
      "Bias the substrate toward command. While installed, military power is 20% greater — " +
      "the drum of war plays beneath every action.",
    icon: "⚔️",
    behavior: { kind: "passive" },
    militaryMult: 0.20,
  },
  {
    id: "science_core",
    name: "Science Core",
    desc:
      "Bias the substrate toward inquiry. While installed, science flows 25% richer — " +
      "the lattice of curiosity hums beneath every measurement.",
    icon: "🔬",
    behavior: { kind: "passive" },
    scienceMult: 0.25,
  },
  {
    id: "trade_core",
    name: "Trade Core",
    desc:
      "Bias the substrate toward exchange. While installed, gold and production both rise 15% — " +
      "the gears of commerce turn a little faster beneath every transaction.",
    icon: "⚖️",
    behavior: { kind: "passive" },
    goldMult: 0.15,
    productionMult: 0.15,
  },
  {
    id: "faith_core",
    name: "Faith Core",
    desc:
      "Bias the substrate toward devotion. While installed, a thin but constant stream of divinity " +
      "flows in at +0.02 per second — the substrate itself begins to pray.",
    icon: "🛐",
    behavior: { kind: "passive" },
    divinityPerSec: 0.02,
  },
];

export const LOGIC_CORE_MAP: Record<string, LogicCoreDef> = Object.fromEntries(
  LOGIC_CORES.map((c) => [c.id, c])
);

export const LOGIC_CORE_COUNT: number = LOGIC_CORES.length;

// =====================================================================
// Module-load sanity checks
// =====================================================================

/**
 * Validate the singularity data at module load:
 *   - All relic loadout ids are unique.
 *   - Each relic sets a `special` (required field — enforced by type, but
 *     the validator also sanity-checks the payload of each variant).
 *   - Each relic sets at least one stat field OR has a `special` whose
 *     `kind` is `scale_with_installed_cores` (Omni Matrix — its specials
 *     amplifies its own stat fields, so it must set at least one).
 *   - `happinessDrainPerSec` (if set) is ≤ 0 (it's a drain, not a bonus).
 *   - `capsMult` (if set) is in (−1, ∞) — caps can drop toward 0 but
 *     never go negative.
 *   - All logic core ids are unique.
 *   - Each `passive` logic core sets at least one bonus field.
 *   - Each non-`passive` logic core (auto_evolve, happiness_drift) sets
 *     NO bonus fields — automation-only.
 *   - `divinityPerSec` (if set) is > 0.
 *   - All mult fields (if set) on logic cores are > 0 (cores grant
 *     bonuses, never penalties).
 *   - `SINGULARITY_COMPLETION_CORES_REQUIRED` is in [1, MAX_INSTALLED_LOGIC_CORES].
 *
 * Throws on any violation (programmer error, not a runtime / save data
 * error). The check is O(N) and runs once at module import, so it's a
 * no-op on the hot path. Matches the pattern established by
 * `apotheosis.ts`, `transcendence.ts`, and `genesis.ts`.
 */
(function validateSingularityData(): void {
  if (
    SINGULARITY_COMPLETION_CORES_REQUIRED < 1 ||
    SINGULARITY_COMPLETION_CORES_REQUIRED > MAX_INSTALLED_LOGIC_CORES
  ) {
    throw new Error(
      `singularity.ts: SINGULARITY_COMPLETION_CORES_REQUIRED must be in [1, ${MAX_INSTALLED_LOGIC_CORES}] (got ${SINGULARITY_COMPLETION_CORES_REQUIRED})`
    );
  }

  // ---- Relic loadouts ----
  const seenRelic = new Set<string>();
  for (const r of RELIC_LOADOUTS) {
    if (seenRelic.has(r.id)) {
      throw new Error(`singularity.ts: duplicate relic loadout id "${r.id}"`);
    }
    seenRelic.add(r.id);

    // `special` is required by type, but the validator sanity-checks each variant's payload.
    switch (r.special.kind) {
      case "production_floor":
        if (r.special.floorMult < 0 || r.special.floorMult > 1) {
          throw new Error(
            `singularity.ts: relic "${r.id}" production_floor.floorMult must be in [0, 1] (got ${r.special.floorMult})`
          );
        }
        break;
      case "pop_growth_doubles_below_pop":
        if (r.special.threshold < 0) {
          throw new Error(
            `singularity.ts: relic "${r.id}" pop_growth_doubles_below_pop.threshold must be >= 0 (got ${r.special.threshold})`
          );
        }
        break;
      case "tech_cost_reduction":
        if (r.special.value < 0 || r.special.value > 1) {
          throw new Error(
            `singularity.ts: relic "${r.id}" tech_cost_reduction.value must be in [0, 1] (got ${r.special.value})`
          );
        }
        break;
      case "system_buy_gold_kickback":
        if (r.special.fraction < 0 || r.special.fraction > 1) {
          throw new Error(
            `singularity.ts: relic "${r.id}" system_buy_gold_kickback.fraction must be in [0, 1] (got ${r.special.fraction})`
          );
        }
        break;
      case "caps_grow_with_happiness":
        if (r.special.above < 0 || r.special.above > 100) {
          throw new Error(
            `singularity.ts: relic "${r.id}" caps_grow_with_happiness.above must be in [0, 100] (got ${r.special.above})`
          );
        }
        if (r.special.perSec <= 0) {
          throw new Error(
            `singularity.ts: relic "${r.id}" caps_grow_with_happiness.perSec must be > 0 (got ${r.special.perSec})`
          );
        }
        break;
      case "military_event_chance_mult":
        if (r.special.value < 0) {
          throw new Error(
            `singularity.ts: relic "${r.id}" military_event_chance_mult.value must be >= 0 (got ${r.special.value})`
          );
        }
        break;
      case "double_actions_producing":
        if (r.special.resources.length === 0) {
          throw new Error(
            `singularity.ts: relic "${r.id}" double_actions_producing.resources must be non-empty`
          );
        }
        break;
      case "scale_with_installed_cores":
        if (r.special.perCoreMult < 0) {
          throw new Error(
            `singularity.ts: relic "${r.id}" scale_with_installed_cores.perCoreMult must be >= 0 (got ${r.special.perCoreMult})`
          );
        }
        // Omni Matrix must set at least one stat field for the scaling to amplify.
        const omniStats = [
          r.productionMult,
          r.populationGrowthMult,
          r.scienceMult,
          r.militaryMult,
          r.goldMult,
          r.foodMult,
          r.organicMatterMult,
          r.capsMult,
        ].filter((v) => v !== undefined).length;
        if (omniStats < 1) {
          throw new Error(
            `singularity.ts: relic "${r.id}" scale_with_installed_cores requires at least one stat field to amplify (set ${omniStats})`
          );
        }
        break;
      // No default — exhaustiveness is enforced by TypeScript's discriminated union check.
    }

    // `happinessDrainPerSec` is a drain — must be ≤ 0.
    if (r.happinessDrainPerSec !== undefined && r.happinessDrainPerSec > 0) {
      throw new Error(
        `singularity.ts: relic "${r.id}" happinessDrainPerSec must be <= 0 (got ${r.happinessDrainPerSec})`
      );
    }

    // `capsMult` is additive on caps; a value of −1 would zero every cap.
    // Allow (−1, ∞) — −0.999 is the smallest meaningful value.
    if (r.capsMult !== undefined && r.capsMult <= -1) {
      throw new Error(
        `singularity.ts: relic "${r.id}" capsMult must be > -1 (got ${r.capsMult})`
      );
    }

    // Each relic should set at least one stat field (the upside or downside)
    // in addition to its `special`. The only relic that could conceivably
    // violate this is one whose `special` is `scale_with_installed_cores`
    // with NO stat fields to amplify — but that case is already caught by
    // the Omni Matrix check above (a `scale_with_installed_cores` relic
    // with no stats fails the `omniStats < 1` check). For all other
    // specials, the dataset author ensures at least one stat is set.
    //
    // We do NOT enforce a generic "statCount >= 1" here because some relic
    // designs might legitimately have a `special`-only effect (e.g. a
    // hypothetical relic whose only impact is its `production_floor`).
    // The dataset below passes: all 8 relics set at least one stat field.
  }

  // ---- Logic cores ----
  const seenCore = new Set<string>();
  for (const c of LOGIC_CORES) {
    if (seenCore.has(c.id)) {
      throw new Error(`singularity.ts: duplicate logic core id "${c.id}"`);
    }
    seenCore.add(c.id);

    const bonusCount = [
      c.militaryMult,
      c.scienceMult,
      c.goldMult,
      c.productionMult,
      c.divinityPerSec,
    ].filter((v) => v !== undefined).length;

    if (c.behavior.kind === "passive") {
      // Passive cores must set at least one bonus field.
      if (bonusCount < 1) {
        throw new Error(
          `singularity.ts: passive logic core "${c.id}" must set at least one bonus field (set ${bonusCount})`
        );
      }
    } else {
      // Automation cores (auto_evolve, happiness_drift) must set NO bonus fields.
      if (bonusCount > 0) {
        throw new Error(
          `singularity.ts: automation logic core "${c.id}" (behavior "${c.behavior.kind}") must NOT set bonus fields (set ${bonusCount})`
        );
      }
    }

    // Bonus fields on cores must be strictly positive — cores grant bonuses,
    // never penalties. (Contrast with relics, which can have negative fields
    // for downsides.)
    if (c.militaryMult !== undefined && c.militaryMult <= 0) {
      throw new Error(
        `singularity.ts: logic core "${c.id}" militaryMult must be > 0 (got ${c.militaryMult})`
      );
    }
    if (c.scienceMult !== undefined && c.scienceMult <= 0) {
      throw new Error(
        `singularity.ts: logic core "${c.id}" scienceMult must be > 0 (got ${c.scienceMult})`
      );
    }
    if (c.goldMult !== undefined && c.goldMult <= 0) {
      throw new Error(
        `singularity.ts: logic core "${c.id}" goldMult must be > 0 (got ${c.goldMult})`
      );
    }
    if (c.productionMult !== undefined && c.productionMult <= 0) {
      throw new Error(
        `singularity.ts: logic core "${c.id}" productionMult must be > 0 (got ${c.productionMult})`
      );
    }
    if (c.divinityPerSec !== undefined && c.divinityPerSec <= 0) {
      throw new Error(
        `singularity.ts: logic core "${c.id}" divinityPerSec must be > 0 (got ${c.divinityPerSec})`
      );
    }

    // happiness_drift behavior must have sensible thresholds.
    if (c.behavior.kind === "happiness_drift") {
      if (c.behavior.below < 0 || c.behavior.below > 100) {
        throw new Error(
          `singularity.ts: logic core "${c.id}" happiness_drift.below must be in [0, 100] (got ${c.behavior.below})`
        );
      }
      if (c.behavior.toward < 0 || c.behavior.toward > 100) {
        throw new Error(
          `singularity.ts: logic core "${c.id}" happiness_drift.toward must be in [0, 100] (got ${c.behavior.toward})`
        );
      }
      if (c.behavior.toward < c.behavior.below) {
        throw new Error(
          `singularity.ts: logic core "${c.id}" happiness_drift.toward (${c.behavior.toward}) must be >= below (${c.behavior.below})`
        );
      }
      if (c.behavior.perSec <= 0) {
        throw new Error(
          `singularity.ts: logic core "${c.id}" happiness_drift.perSec must be > 0 (got ${c.behavior.perSec})`
        );
      }
    }
  }
})();

// =====================================================================
// Helpers
// =====================================================================

/**
 * Aggregated bonus object returned by `relicBonus`.
 *
 * All mult fields are additive on top of the baseline (0 = no change).
 * The consumer applies these in the tick loop:
 *
 *   - `productionMult`:        multiply production by `(1 + productionMult)`
 *   - `populationGrowthMult`:  multiply pop growth by `(1 + populationGrowthMult)`
 *   - `scienceMult`:           multiply science by `(1 + scienceMult)`
 *   - `militaryMult`:         multiply military by `(1 + militaryMult)`
 *   - `goldMult`:              multiply gold by `(1 + goldMult)`
 *   - `foodMult`:              multiply food by `(1 + foodMult)`
 *   - `organicMatterMult`:    multiply organic_matter by `(1 + organicMatterMult)`
 *   - `capsMult`:              multiply every resource cap by `(1 + capsMult)`
 *   - `happinessDrainPerSec`: add to `state.resources.happiness` per second (signed; negative = drain)
 *   - `special`:               the active relic's special interaction, or `null` if no relic equipped
 *
 * Only one relic can be equipped at a time (`state.activeRelic` is a single
 * id, not a set), so the aggregate is just the equipped relic's fields
 * passed through with defaults. The `special` field is non-aggregated —
 * it's the relic's own special, returned so the consumer can dispatch on
 * `special.kind` without a second lookup.
 */
export interface RelicBonus {
  /** Additive all-production multiplier (Singularity Core +0.30, Golden Idol +0.40, Stone Tablet −0.15, Omni Matrix +0.10). */
  productionMult: number;
  /** Additive population-growth multiplier (Eternal Flame +0.50, Golden Idol −0.20). */
  populationGrowthMult: number;
  /** Additive science multiplier (Void Lens +0.60, War Drum −0.20). */
  scienceMult: number;
  /** Additive military-power multiplier (War Drum +0.80, Void Lens −0.30). */
  militaryMult: number;
  /** Additive gold multiplier (Golden Idol +0.40, Harvest Scythe −0.30). */
  goldMult: number;
  /** Additive food multiplier (Harvest Scythe +0.50). */
  foodMult: number;
  /** Additive organic_matter multiplier (Harvest Scythe +0.50). */
  organicMatterMult: number;
  /** Additive multiplier on every resource's cap (Singularity Core −0.20, Stone Tablet +0.50, Omni Matrix +0.10). */
  capsMult: number;
  /** Flat per-second happiness drain (signed; Eternal Flame −0.2, War Drum −0.3, 0 = no drain). */
  happinessDrainPerSec: number;
  /** The active relic's special interaction, or `null` if no relic is equipped. */
  special: RelicSpecial | null;
}

/**
 * Return the equipped relic's bonuses as a single aggregate object.
 *
 * Only one relic can be active per run (`state.activeRelic` is a single
 * id, not a set — mirrors the Worship Mode pattern from apotheosis.ts).
 * The aggregate is just the equipped relic's stat fields passed through
 * with defaults (0 for mults, 0 for happinessDrainPerSec, `null` for
 * special). The `special` field is returned verbatim so the consumer
 * can dispatch on `special.kind` without a second lookup.
 *
 * Used by the tick loop to compute per-resource multipliers, the
 * pop-growth rate, cap multipliers, and the happiness drain. Special
 * interactions (e.g. Singularity Core's production floor, Golden Idol's
 * system-buy kickback) are dispatched separately by the consumer
 * reading `bonus.special.kind`.
 *
 * @param activeRelicId  The equipped relic loadout id, or `null` if none.
 * @returns Aggregated `RelicBonus` (all fields defaulted for null input).
 *
 * @example
 *   relicBonus(null)
 *     // → { productionMult:0, ..., happinessDrainPerSec:0, special:null }
 *   relicBonus("singularity_core")
 *     // → { productionMult:0.30, capsMult:-0.20, ...,
 *     //     special:{ kind:"production_floor", floorMult:0.50 } }
 *   relicBonus("eternal_flame")
 *     // → { populationGrowthMult:0.50, happinessDrainPerSec:-0.2, ...,
 *     //     special:{ kind:"pop_growth_doubles_below_pop", threshold:50 } }
 *   relicBonus("nonexistent_id")
 *     // → { all defaults, special:null }  (unknown id treated as "no relic")
 */
export function relicBonus(
  activeRelicId: string | null
): RelicBonus {
  const result: RelicBonus = {
    productionMult: 0,
    populationGrowthMult: 0,
    scienceMult: 0,
    militaryMult: 0,
    goldMult: 0,
    foodMult: 0,
    organicMatterMult: 0,
    capsMult: 0,
    happinessDrainPerSec: 0,
    special: null,
  };
  if (!activeRelicId) return result;
  const relic = RELIC_LOADOUT_MAP[activeRelicId];
  if (!relic) return result;
  if (relic.productionMult !== undefined) result.productionMult = relic.productionMult;
  if (relic.populationGrowthMult !== undefined) result.populationGrowthMult = relic.populationGrowthMult;
  if (relic.scienceMult !== undefined) result.scienceMult = relic.scienceMult;
  if (relic.militaryMult !== undefined) result.militaryMult = relic.militaryMult;
  if (relic.goldMult !== undefined) result.goldMult = relic.goldMult;
  if (relic.foodMult !== undefined) result.foodMult = relic.foodMult;
  if (relic.organicMatterMult !== undefined) result.organicMatterMult = relic.organicMatterMult;
  if (relic.capsMult !== undefined) result.capsMult = relic.capsMult;
  if (relic.happinessDrainPerSec !== undefined) result.happinessDrainPerSec = relic.happinessDrainPerSec;
  result.special = relic.special;
  return result;
}

/**
 * Aggregated bonus object returned by `logicCoreBonus`.
 *
 * All fields are additive on top of the baseline (0 = no change).
 * `divinityPerSec` is a flat per-second Divinity grant (not a mult).
 * The consumer applies these in the tick loop:
 *
 *   - `militaryMult`:     multiply military by `(1 + militaryMult)`
 *   - `scienceMult`:      multiply science by `(1 + scienceMult)`
 *   - `goldMult`:         multiply gold by `(1 + goldMult)`
 *   - `productionMult`:   multiply production by `(1 + productionMult)`
 *   - `divinityPerSec`:   add to `state.resources.divinity` per second
 *
 * Automation behaviors (Growth Core's auto-evolve, Stability Core's
 * happiness drift) are NOT in this aggregate — they're encoded on each
 * core's `behavior` field and dispatched by the consumer reading
 * `LOGIC_CORE_MAP[id].behavior` directly. This keeps the aggregate
 * strictly numeric (no union-of-behaviors return type).
 */
export interface LogicCoreBonus {
  /** Additive military-power multiplier (Conquest Core +0.20). */
  militaryMult: number;
  /** Additive science multiplier (Science Core +0.25). */
  scienceMult: number;
  /** Additive gold multiplier (Trade Core +0.15). */
  goldMult: number;
  /** Additive all-production multiplier (Trade Core +0.15). */
  productionMult: number;
  /** Flat Divinity generated per second (Faith Core +0.02). */
  divinityPerSec: number;
}

/**
 * Sum the passive bonuses from all installed Logic Cores into a single
 * aggregate.
 *
 * Iterates `LOGIC_CORES` and adds each installed core's bonus fields.
 * Cores with `behavior.kind !== "passive"` (Growth, Stability) set no
 * bonus fields (enforced by the IIFE validator) and contribute nothing
 * to the aggregate — their value is the automation, which the consumer
 * dispatches separately via `LOGIC_CORE_MAP[id].behavior`.
 *
 * Used by the tick loop to compute per-resource multipliers and the
 * Divinity/sec grant. The aggregate is recomputed each tick (it's cheap
 * — 6 entries) so the consumer doesn't need to cache it.
 *
 * @param installedCores  Map of core id → installed-this-run flag.
 * @returns Aggregated `LogicCoreBonus` (all fields defaulted for empty input).
 *
 * @example
 *   logicCoreBonus({})
 *     // → { militaryMult:0, scienceMult:0, goldMult:0, productionMult:0, divinityPerSec:0 }
 *   logicCoreBonus({ conquest_core: true })
 *     // → { militaryMult:0.20, scienceMult:0, goldMult:0, productionMult:0, divinityPerSec:0 }
 *   logicCoreBonus({ conquest_core: true, science_core: true, trade_core: true })
 *     // → { militaryMult:0.20, scienceMult:0.25, goldMult:0.15, productionMult:0.15, divinityPerSec:0 }
 *   logicCoreBonus({ faith_core: true })
 *     // → { ..., divinityPerSec:0.02 }
 *   logicCoreBonus({ growth_core: true, stability_core: true })
 *     // → { all zeros }  (automation cores contribute no passive bonuses)
 *   logicCoreBonus({ conquest_core: true, science_core: true, trade_core: true,
 *                    faith_core: true, growth_core: true, stability_core: true })
 *     // → { militaryMult:0.20, scienceMult:0.25, goldMult:0.15, productionMult:0.15, divinityPerSec:0.02 }
 */
export function logicCoreBonus(
  installedCores: Record<string, boolean>
): LogicCoreBonus {
  const result: LogicCoreBonus = {
    militaryMult: 0,
    scienceMult: 0,
    goldMult: 0,
    productionMult: 0,
    divinityPerSec: 0,
  };
  for (const core of LOGIC_CORES) {
    if (!installedCores[core.id]) continue;
    if (core.militaryMult !== undefined) result.militaryMult += core.militaryMult;
    if (core.scienceMult !== undefined) result.scienceMult += core.scienceMult;
    if (core.goldMult !== undefined) result.goldMult += core.goldMult;
    if (core.productionMult !== undefined) result.productionMult += core.productionMult;
    if (core.divinityPerSec !== undefined) result.divinityPerSec += core.divinityPerSec;
  }
  return result;
}

/**
 * Whether the Layer 6 (Singularity) completion conditions are met.
 *
 * Conditions (both must be true):
 *   1. At least `SINGULARITY_COMPLETION_CORES_REQUIRED` (3) Logic Cores installed.
 *   2. At least one system tier has been compressed this run
 *      (`compressionPerformed === true`).
 *
 * Matches `prestigeLayers.ts singularity.completeState = "Install 3
 * Logic Cores and Compress one system tier"`. Used by `triggerPrestige()`
 * to gate advancement to Layer 7 (Omnipotence).
 *
 * Note: the Compression family is NOT defined in this file (it's a
 * follow-up task — see the file header comment). The helper already
 * accepts `compressionPerformed` so it's ready to gate advancement
 * once the compression wiring lands. Until then, callers can pass
 * `false` (or omit it) to test the cores-only half of the condition.
 *
 * @param installedCores        Map of core id → installed-this-run flag.
 * @param compressionPerformed  Whether any system tier was compressed this run.
 * @returns `true` if both conditions are met.
 *
 * @example
 *   isSingularityComplete({}, false)
 *     // → false  (no cores installed, no compression)
 *   isSingularityComplete({ conquest_core: true, science_core: true }, false)
 *     // → false  (only 2 cores; no compression)
 *   isSingularityComplete({
 *     conquest_core: true, science_core: true, trade_core: true
 *   }, false)
 *     // → false  (3 cores but no compression)
 *   isSingularityComplete({}, true)
 *     // → false  (compression done but no cores installed)
 *   isSingularityComplete({
 *     conquest_core: true, science_core: true, trade_core: true
 *   }, true)
 *     // → true  (3 cores + compression)
 *   isSingularityComplete({
 *     conquest_core: true, science_core: true, trade_core: true,
 *     faith_core: true, growth_core: true, stability_core: true
 *   }, true)
 *     // → true  (6 cores + compression — over-satisfied)
 */
export function isSingularityComplete(
  installedCores: Record<string, boolean>,
  compressionPerformed: boolean
): boolean {
  const installedCount = LOGIC_CORES.filter((c) => installedCores[c.id]).length;
  return (
    installedCount >= SINGULARITY_COMPLETION_CORES_REQUIRED && compressionPerformed
  );
}
