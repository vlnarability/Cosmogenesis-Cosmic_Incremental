// Apotheosis — Layer 5 prestige content
//
// When a god reaches Apotheosis, civilization recognizes it. The creator
// is no longer silent: Divine Laws bind the run, Worship Modes shape how
// mortals pray, Miracles intervene directly, and Heresy rises whenever
// belief fractures. Manage all four and the god ascends to Singularity.
//
// Four mechanic families live in this file:
//
//   1. Divine Laws (8)        — fundamental rule changes, permanent for
//                               the run, cost Divinity. Up to 8 codified
//                               per run (one of each).
//   2. Worship Modes (6)      — pick one at run start; decides how mortals
//                               relate to the god and which bonuses apply.
//   3. Miracles (5)           — dramatic interventions that cost Divinity,
//                               each with a per-run usage limit.
//   4. Heresy Responses (4)   — manage rising heresy (0..100). The run
//                               ends at HERESY_MAX (100); these tools
//                               reduce heresy at various costs.
//
// State fields (planned for GameState — to be wired in a follow-up task):
//   - lawsCodified:        Record<string, boolean>  // laws codified this run (one of each, max 8)
//   - worshipMode:         string | null             // active worship mode id, or null before pick
//   - miracleUses:         Record<string, number>   // times each miracle used this run
//   - miracleTimers:       Record<string, number>   // remaining seconds for active temporary miracles
//   - heresyResponseUses:  Record<string, number>   // times each heresy response used this run
//   - heresy:              number                    // current heresy level (0..100)
//   - heresySchismResolved: boolean                  // whether a schism was resolved this run
//
// Reference: /home/z/my-project/upload/data.js DATA.DIVINE_LAWS (lines 204-210),
// DATA.WORSHIP_MODES (lines 196-203), DATA.MIRACLES (lines 211-218), and
// DATA.HERESY_RESPONSES (lines 219-224) for the original vanilla-JS shapes.
// The TS port reshapes each mechanic into the Layer 5 spec: 8 / 6 / 5 / 4
// entries with explicit Divinity costs and per-run limits, distinct from
// the vanilla JS (which had 5 / 6 / 6 / 4 entries with sub-currency costs).
//
// Advancement to Layer 6 (Singularity) requires codifying 3 Divine Laws
// AND resolving a Heresy schism — see prestigeLayers.ts
// `apotheosis.completeState: "Codify 3 Divine Laws and resolve a Heresy schism"`.

import type { ResourceId } from "../state/types";
import { RESOURCES } from "./resources";

// =====================================================================
// Constants
// =====================================================================

/**
 * Base heresy accumulation rate, in points per second, before any laws
 * or worship modes modify it. Effective rate each tick is
 * `BASE_HERESY_RATE * (1 + heresyRateMult(lawsCodified, worshipMode))`.
 *
 * At 0.05/s with no modifiers, heresy fills the 0..100 meter in
 * 100 / 0.05 = 2000 seconds (~33 minutes). Laws and worship modes can
 * speed this up (Zeal +50%, Fear has no effect), slow it down (Order -50%,
 * Mystery worship mode -25%), or even reverse it (Mercy: heresy decays).
 */
export const BASE_HERESY_RATE: number = 0.05;

/**
 * Maximum heresy value. When `state.heresy` reaches this number the run
 * ends — the god is rejected by creation (a "schism" too large to
 * resolve). The player should manage heresy via Heresy Responses before
 * it hits this cap.
 */
export const HERESY_MAX: number = 100;

/**
 * Number of Divine Laws the player must codify for the Layer 5
 * completion check (`isApotheosisComplete`). Matches the spec wording
 * "Codify 3 Divine Laws and resolve a Heresy schism" from
 * prestigeLayers.ts.
 */
export const APOTHEOSIS_COMPLETION_LAWS_REQUIRED: number = 3;

// =====================================================================
// 1. Divine Laws (8) — fundamental rule changes, permanent for the run
// =====================================================================

/**
 * A single Divine Law. Effects are spread across optional fields; the
 * IIFE validator enforces that each law sets at least one. Fields map
 * to consumer wiring as follows:
 *
 *   - `productionMult`        → additive all-production mult (Abundance, Tithe)
 *   - `populationGrowthMult`  → additive pop-growth mult (Fertility)
 *   - `militaryMult`          → additive military mult (Zeal)
 *   - `scienceMult`           → additive science mult (Revelation)
 *   - `goldMult`              → additive gold mult (Tithe)
 *   - `worshipMult`           → multiplicative worship-bonus mult (Faith 2.0)
 *   - `happinessFlat`         → flat per-tick happiness bonus (Mercy +10)
 *   - `happinessTarget`       → clamp happiness to this value while codified (Order 80)
 *   - `heresyDecays`          → UI flag: heresy meter shows "Decaying" (Mercy)
 *   - `heresyFlatOnCodify`    → one-time flat heresy change applied at codification (Faith -20)
 *   - `heresyRateMult`        → additive mult on BASE_HERESY_RATE (Zeal +0.50, Order -0.50, Mercy -2.00)
 *
 * `heresyRateMult` semantics: the effective heresy rate per second is
 * `BASE_HERESY_RATE * (1 + sum_of_law_heresyRateMult + mode.heresyRateMult)`.
 * Mercy's -2.00 makes the factor (1 + -2.00) = -1.0, so heresy decays at
 * the base rate (–0.05/s) when Mercy is codified alone.
 */
export interface DivineLawDef {
  /** Stable identifier (used as a key in `lawsCodified` in GameState). */
  id: string;
  /** Human-readable law name. */
  name: string;
  /** Narrative / mechanical flavour of what the law decrees. */
  desc: string;
  /** Emoji glyph shown on the law card. */
  icon: string;
  /** Divinity cost to codify the law (one-time per run). */
  cost: number;
  /** Additive all-production multiplier (0.15 = +15% all production). */
  productionMult?: number;
  /** Additive population-growth multiplier (0.30 = +30% pop growth). */
  populationGrowthMult?: number;
  /** Additive military-power multiplier (0.40 = +40% military). */
  militaryMult?: number;
  /** Additive science multiplier (0.35 = +35% science). */
  scienceMult?: number;
  /** Additive gold multiplier (0.25 = +25% gold). */
  goldMult?: number;
  /** Multiplicative worship-bonus multiplier (2.0 = double the worship bonus). */
  worshipMult?: number;
  /** Flat per-tick happiness bonus (signed). */
  happinessFlat?: number;
  /** Happiness clamp target while the law is codified (Order: 80). */
  happinessTarget?: number;
  /** Whether heresy decays naturally while codified (Mercy). */
  heresyDecays?: boolean;
  /** One-time flat heresy change applied at codification (signed; Faith: -20). */
  heresyFlatOnCodify?: number;
  /** Additive multiplier on BASE_HERESY_RATE (Zeal: +0.50; Order: -0.50; Mercy: -2.00). */
  heresyRateMult?: number;
}

export const DIVINE_LAWS: DivineLawDef[] = [
  {
    id: "law_abundance",
    name: "Law of Abundance",
    desc: "Decree that overflow is the natural state of the world. All production flows 15% richer.",
    icon: "🌾",
    cost: 15,
    productionMult: 0.15,
  },
  {
    id: "law_fertility",
    name: "Law of Fertility",
    desc: "Bless every womb and seed. Population growth surges by 30%.",
    icon: "🌱",
    cost: 12,
    populationGrowthMult: 0.30,
  },
  {
    id: "law_order",
    name: "Law of Order",
    desc: "Impose harmony by decree. Happiness holds at 80; heresy spreads half as fast.",
    icon: "⚖️",
    cost: 18,
    happinessTarget: 80,
    heresyRateMult: -0.50,
  },
  {
    id: "law_zeal",
    name: "Law of Zeal",
    desc: "Refine the faithful into a blade. +40% military — but zealotry breeds heresy 50% faster.",
    icon: "🔥",
    cost: 20,
    militaryMult: 0.40,
    heresyRateMult: 0.50,
  },
  {
    id: "law_revelation",
    name: "Law of Revelation",
    desc: "Open the heavens to inquiry. Science flows 35% richer.",
    icon: "📖",
    cost: 16,
    scienceMult: 0.35,
  },
  {
    id: "law_tithe",
    name: "Law of Tithe",
    desc: "A tenth of every work is the god's. Gold and production both rise 25%.",
    icon: "🪙",
    cost: 14,
    goldMult: 0.25,
    productionMult: 0.25,
  },
  {
    id: "law_faith",
    name: "Law of Faith",
    desc: "Doubt is named and diminished. Worship bonus doubles; 20 heresy extinguished at codification.",
    icon: "🙏",
    cost: 22,
    worshipMult: 2.0,
    heresyFlatOnCodify: -20,
  },
  {
    id: "law_mercy",
    name: "Law of Mercy",
    desc: "Forgiveness becomes law. Heresy decays naturally; happiness lifts by 10.",
    icon: "🤲",
    cost: 19,
    heresyDecays: true,
    heresyRateMult: -2.00,
    happinessFlat: 10,
  },
];

export const DIVINE_LAW_MAP: Record<string, DivineLawDef> = Object.fromEntries(
  DIVINE_LAWS.map((l) => [l.id, l])
);

export const DIVINE_LAW_COUNT: number = DIVINE_LAWS.length;

// =====================================================================
// 2. Worship Modes (6) — choose how mortals relate to the god
// =====================================================================

/**
 * A single Worship Mode. The player picks exactly one at the start of
 * an Apotheosis run; it applies for the entire run. Effects are spread
 * across optional fields; the IIFE validator enforces that each mode
 * sets at least one.
 *
 * Field → consumer wiring:
 *   - `productionMult`        → additive all-production mult (Reverence, Ambition, Mystery)
 *   - `populationGrowthMult` → additive pop-growth mult (Devotion)
 *   - `militaryMult`         → additive military mult (Fear)
 *   - `scienceMult`           → additive science mult (Wonder)
 *   - `goldMult`              → additive gold mult (Ambition)
 *   - `happinessFlat`         → flat per-tick happiness bonus (Wonder, Devotion)
 *   - `happinessDrainMult`   → multiplicative mult on happiness drain rate (Fear 0.5 = half drain)
 *   - `heresyRateMult`        → additive mult on BASE_HERESY_RATE (Mystery -0.25)
 */
export interface WorshipModeDef {
  /** Stable identifier (matches `worshipMode` in GameState). */
  id: string;
  /** Human-readable worship mode name. */
  name: string;
  /** Narrative / mechanical flavour of how mortals relate to the god. */
  desc: string;
  /** Emoji glyph shown on the worship mode card. */
  icon: string;
  /** Additive all-production multiplier (0.10 = +10% all production). */
  productionMult?: number;
  /** Additive population-growth multiplier (0.20 = +20% pop growth). */
  populationGrowthMult?: number;
  /** Additive military-power multiplier (0.25 = +25% military). */
  militaryMult?: number;
  /** Additive science multiplier (0.20 = +20% science). */
  scienceMult?: number;
  /** Additive gold multiplier (0.20 = +20% gold). */
  goldMult?: number;
  /** Flat per-tick happiness bonus (signed). */
  happinessFlat?: number;
  /** Multiplicative happiness-drain multiplier (0.5 = half drain; 1.0 = normal). */
  happinessDrainMult?: number;
  /** Additive multiplier on BASE_HERESY_RATE (Mystery: -0.25 = 25% slower heresy). */
  heresyRateMult?: number;
}

export const WORSHIP_MODES: WorshipModeDef[] = [
  {
    id: "reverence",
    name: "Reverence",
    desc: "The faithful adore the god through gratitude and steady service. All production flows 10% richer.",
    icon: "🙇",
    productionMult: 0.10,
  },
  {
    id: "fear",
    name: "Fear",
    desc: "The world obeys because it dreads divine judgment. +25% military; happiness drains half as fast.",
    icon: "😨",
    militaryMult: 0.25,
    happinessDrainMult: 0.5,
  },
  {
    id: "wonder",
    name: "Wonder",
    desc: "The god is marveled at more than obeyed. +20% science; happiness lifts by 10.",
    icon: "🌟",
    scienceMult: 0.20,
    happinessFlat: 10,
  },
  {
    id: "ambition",
    name: "Ambition",
    desc: "Faith becomes a covenant of ascent. +20% gold and +15% production.",
    icon: "👑",
    goldMult: 0.20,
    productionMult: 0.15,
  },
  {
    id: "mystery",
    name: "Mystery",
    desc: "The god hides behind signs and symbols. +15% production; heresy spreads 25% slower.",
    icon: "🌫️",
    productionMult: 0.15,
    heresyRateMult: -0.25,
  },
  {
    id: "devotion",
    name: "Devotion",
    desc: "The faithful multiply and rejoice. +20% population growth; happiness lifts by 15.",
    icon: "🕯️",
    populationGrowthMult: 0.20,
    happinessFlat: 15,
  },
];

export const WORSHIP_MODE_MAP: Record<string, WorshipModeDef> = Object.fromEntries(
  WORSHIP_MODES.map((m) => [m.id, m])
);

export const WORSHIP_MODE_COUNT: number = WORSHIP_MODES.length;

// =====================================================================
// 3. Miracles (5) — dramatic interventions that cost Divinity
// =====================================================================

/**
 * A single Miracle. Miracles cost Divinity and have a per-run usage
 * limit (stored on `miracleUses[id]` in GameState). Each miracle has
 * exactly one effect kind; the IIFE validator enforces this.
 *
 * Effect field → consumer wiring:
 *   - `grantAllResources`    → flat amount added to every primary resource
 *                              (Manna from Heaven: 50). The consumer iterates
 *                              `RESOURCES.filter(r => r.category === "primary")`.
 *   - `grantPopulation`      → flat population bonus (Great Bloom: +20).
 *   - `setHappiness`         → clamp happiness to value (Jubilee: 100).
 *   - `heresyFlat`           → signed flat heresy change (Purge of Doubt: -30).
 *   - `productionBoost`      → temporary production multiplier + duration (Divine Enlightenment).
 *                              The store applies the mult via `miracleTimers[id]`,
 *                              counting down `durationSec` each tick.
 */
export interface MiracleDef {
  /** Stable identifier (used as a key in `miracleUses` / `miracleTimers` in GameState). */
  id: string;
  /** Human-readable miracle name. */
  name: string;
  /** Narrative / mechanical flavour of the miracle's effect. */
  desc: string;
  /** Emoji glyph shown on the miracle card. */
  icon: string;
  /** Divinity cost to invoke the miracle. */
  cost: number;
  /** Maximum times this miracle can be invoked per run. */
  limitPerRun: number;
  /** Flat amount granted to every primary resource. */
  grantAllResources?: number;
  /** Flat population bonus. */
  grantPopulation?: number;
  /** Happiness clamp target (sets happiness to this value). */
  setHappiness?: number;
  /** Signed flat heresy change (typically negative). */
  heresyFlat?: number;
  /** Temporary production multiplier + duration. */
  productionBoost?: { mult: number; durationSec: number };
}

export const MIRACLES: MiracleDef[] = [
  {
    id: "manna_from_heaven",
    name: "Manna from Heaven",
    desc: "The sky opens. 50 of every primary resource descends upon the world.",
    icon: "🍞",
    cost: 15,
    limitPerRun: 3,
    grantAllResources: 50,
  },
  {
    id: "great_bloom",
    name: "Great Bloom",
    desc: "Life bursts forth in every cradle. +20 population, instantly.",
    icon: "🌸",
    cost: 18,
    limitPerRun: 2,
    grantPopulation: 20,
  },
  {
    id: "jubilee",
    name: "Jubilee",
    desc: "A day of total grace. Happiness is set to 100; the world sings.",
    icon: "🎉",
    cost: 12,
    limitPerRun: 3,
    setHappiness: 100,
  },
  {
    id: "purge_of_doubt",
    name: "Purge of Doubt",
    desc: "Heresy is named and burned. -30 heresy, paid in divinity.",
    icon: "🗡️",
    cost: 20,
    limitPerRun: 2,
    heresyFlat: -30,
  },
  {
    id: "divine_enlightenment",
    name: "Divine Enlightenment",
    desc: "The god's mind touches every work. Production is tripled for 60 seconds.",
    icon: "☀️",
    cost: 30,
    limitPerRun: 1,
    productionBoost: { mult: 3, durationSec: 60 },
  },
];

export const MIRACLE_MAP: Record<string, MiracleDef> = Object.fromEntries(
  MIRACLES.map((m) => [m.id, m])
);

export const MIRACLE_COUNT: number = MIRACLES.length;

// =====================================================================
// 4. Heresy Responses (4) — manage rising heresy (0..100; run ends at 100)
// =====================================================================

/**
 * A single Heresy Response. The player invokes these to keep `state.heresy`
 * below `HERESY_MAX` (100). Each response has a Divinity cost (0 for
 * Tolerate) and a per-run usage limit (`Infinity` for Tolerate, which is
 * always free and unlimited). Effects are spread across optional fields.
 *
 * Effect field → consumer wiring:
 *   - `heresyFlat`      → signed flat heresy change (typically negative)
 *   - `happinessFlat`   → signed flat happiness change (typically negative)
 *   - `populationFlat`  → signed flat population change (typically negative)
 *
 * Note: Tolerate is the "do nothing" option. It costs 0 Divinity, has
 * unlimited uses, and applies no effects. It exists so the player can
 * explicitly acknowledge rising heresy without spending resources.
 */
export interface HeresyResponseDef {
  /** Stable identifier (used as a key in `heresyResponseUses` in GameState). */
  id: string;
  /** Human-readable heresy response name. */
  name: string;
  /** Narrative / mechanical flavour of the response and its toll. */
  desc: string;
  /** Emoji glyph shown on the response card. */
  icon: string;
  /** Divinity cost to invoke (0 for Tolerate). */
  cost: number;
  /** Maximum times this response can be invoked per run (`Infinity` for Tolerate). */
  limitPerRun: number;
  /** Signed flat heresy change (typically negative — reduces heresy). */
  heresyFlat?: number;
  /** Signed flat happiness change (typically negative). */
  happinessFlat?: number;
  /** Signed flat population change (typically negative). */
  populationFlat?: number;
}

export const HERESY_RESPONSES: HeresyResponseDef[] = [
  {
    id: "tolerate",
    name: "Tolerate",
    desc: "Let doubt breathe. It costs nothing — and changes nothing.",
    icon: "🤷",
    cost: 0,
    limitPerRun: Infinity,
  },
  {
    id: "convert",
    name: "Convert",
    desc: "Reason with the heretics, gently. -15 heresy at the cost of -5 happiness.",
    icon: "📜",
    cost: 8,
    limitPerRun: 5,
    heresyFlat: -15,
    happinessFlat: -5,
  },
  {
    id: "smite",
    name: "Smite",
    desc: "Strike the leaders down. -30 heresy, -10 population. The survivors fall quiet.",
    icon: "⚡",
    cost: 15,
    limitPerRun: 3,
    heresyFlat: -30,
    populationFlat: -10,
  },
  {
    id: "inquisition",
    name: "Inquisition",
    desc: "Root out heresy wherever it hides. -50 heresy, -15 happiness, -5 population. Resolves the schism.",
    icon: "🔥",
    cost: 25,
    limitPerRun: 1,
    heresyFlat: -50,
    happinessFlat: -15,
    populationFlat: -5,
  },
];

export const HERESY_RESPONSE_MAP: Record<string, HeresyResponseDef> = Object.fromEntries(
  HERESY_RESPONSES.map((r) => [r.id, r])
);

export const HERESY_RESPONSE_COUNT: number = HERESY_RESPONSES.length;

// =====================================================================
// Module-load sanity checks
// =====================================================================

/**
 * Validate the apotheosis data at module load:
 *   - All ids within each family are unique.
 *   - Each divine law sets at least one effect field, has cost >= 0,
 *     and (if `worshipMult` set) is >= 1.
 *   - Each worship mode sets at least one effect field.
 *   - Each miracle sets exactly one effect (XOR-style check), has
 *     cost > 0 and limitPerRun >= 1.
 *   - Each heresy response has cost >= 0 and limitPerRun >= 1
 *     (Infinity allowed for Tolerate).
 *   - BASE_HERESY_RATE > 0, HERESY_MAX > 0.
 *
 * Throws on any violation (programmer error, not a runtime / save data
 * error). The check is O(N) and runs once, so it's a no-op on the hot
 * path. Matches the pattern established by `transcendence.ts` and
 * `genesis.ts`.
 */
(function validateApotheosisData(): void {
  if (BASE_HERESY_RATE <= 0) {
    throw new Error(`apotheosis.ts: BASE_HERESY_RATE must be > 0 (got ${BASE_HERESY_RATE})`);
  }
  if (HERESY_MAX <= 0) {
    throw new Error(`apotheosis.ts: HERESY_MAX must be > 0 (got ${HERESY_MAX})`);
  }
  if (APOTHEOSIS_COMPLETION_LAWS_REQUIRED < 1) {
    throw new Error(
      `apotheosis.ts: APOTHEOSIS_COMPLETION_LAWS_REQUIRED must be >= 1 (got ${APOTHEOSIS_COMPLETION_LAWS_REQUIRED})`
    );
  }

  const seenLaw = new Set<string>();
  for (const l of DIVINE_LAWS) {
    if (seenLaw.has(l.id)) {
      throw new Error(`apotheosis.ts: duplicate divine law id "${l.id}"`);
    }
    seenLaw.add(l.id);
    if (l.cost < 0) {
      throw new Error(`apotheosis.ts: divine law "${l.id}" has negative cost`);
    }
    if (l.worshipMult !== undefined && l.worshipMult < 1) {
      throw new Error(
        `apotheosis.ts: divine law "${l.id}" worshipMult must be >= 1 (got ${l.worshipMult})`
      );
    }
    if (l.happinessTarget !== undefined && (l.happinessTarget < 0 || l.happinessTarget > 100)) {
      throw new Error(
        `apotheosis.ts: divine law "${l.id}" happinessTarget must be in [0, 100] (got ${l.happinessTarget})`
      );
    }
    const effects = [
      l.productionMult !== undefined,
      l.populationGrowthMult !== undefined,
      l.militaryMult !== undefined,
      l.scienceMult !== undefined,
      l.goldMult !== undefined,
      l.worshipMult !== undefined,
      l.happinessFlat !== undefined,
      l.happinessTarget !== undefined,
      l.heresyDecays !== undefined,
      l.heresyFlatOnCodify !== undefined,
      l.heresyRateMult !== undefined,
    ].filter(Boolean).length;
    if (effects < 1) {
      throw new Error(`apotheosis.ts: divine law "${l.id}" must set at least one effect (set ${effects})`);
    }
  }

  const seenMode = new Set<string>();
  for (const m of WORSHIP_MODES) {
    if (seenMode.has(m.id)) {
      throw new Error(`apotheosis.ts: duplicate worship mode id "${m.id}"`);
    }
    seenMode.add(m.id);
    if (m.happinessDrainMult !== undefined && m.happinessDrainMult < 0) {
      throw new Error(
        `apotheosis.ts: worship mode "${m.id}" happinessDrainMult must be >= 0 (got ${m.happinessDrainMult})`
      );
    }
    const effects = [
      m.productionMult !== undefined,
      m.populationGrowthMult !== undefined,
      m.militaryMult !== undefined,
      m.scienceMult !== undefined,
      m.goldMult !== undefined,
      m.happinessFlat !== undefined,
      m.happinessDrainMult !== undefined,
      m.heresyRateMult !== undefined,
    ].filter(Boolean).length;
    if (effects < 1) {
      throw new Error(`apotheosis.ts: worship mode "${m.id}" must set at least one effect (set ${effects})`);
    }
  }

  const seenMiracle = new Set<string>();
  for (const m of MIRACLES) {
    if (seenMiracle.has(m.id)) {
      throw new Error(`apotheosis.ts: duplicate miracle id "${m.id}"`);
    }
    seenMiracle.add(m.id);
    if (m.cost <= 0) {
      throw new Error(`apotheosis.ts: miracle "${m.id}" has non-positive cost`);
    }
    if (m.limitPerRun < 1) {
      throw new Error(`apotheosis.ts: miracle "${m.id}" limitPerRun must be >= 1`);
    }
    if (m.grantAllResources !== undefined && m.grantAllResources <= 0) {
      throw new Error(`apotheosis.ts: miracle "${m.id}" grantAllResources must be > 0`);
    }
    if (m.grantPopulation !== undefined && m.grantPopulation <= 0) {
      throw new Error(`apotheosis.ts: miracle "${m.id}" grantPopulation must be > 0`);
    }
    if (m.setHappiness !== undefined && (m.setHappiness < 0 || m.setHappiness > 100)) {
      throw new Error(
        `apotheosis.ts: miracle "${m.id}" setHappiness must be in [0, 100] (got ${m.setHappiness})`
      );
    }
    if (m.heresyFlat !== undefined && m.heresyFlat >= 0) {
      throw new Error(
        `apotheosis.ts: miracle "${m.id}" heresyFlat must be negative (got ${m.heresyFlat})`
      );
    }
    if (m.productionBoost !== undefined) {
      if (m.productionBoost.mult <= 1) {
        throw new Error(
          `apotheosis.ts: miracle "${m.id}" productionBoost.mult must be > 1 (got ${m.productionBoost.mult})`
        );
      }
      if (m.productionBoost.durationSec <= 0) {
        throw new Error(
          `apotheosis.ts: miracle "${m.id}" productionBoost.durationSec must be > 0`
        );
      }
    }
    const effects = [
      m.grantAllResources !== undefined,
      m.grantPopulation !== undefined,
      m.setHappiness !== undefined,
      m.heresyFlat !== undefined,
      m.productionBoost !== undefined,
    ].filter(Boolean).length;
    if (effects !== 1) {
      throw new Error(
        `apotheosis.ts: miracle "${m.id}" must set exactly one effect (set ${effects})`
      );
    }
  }

  const seenResponse = new Set<string>();
  for (const r of HERESY_RESPONSES) {
    if (seenResponse.has(r.id)) {
      throw new Error(`apotheosis.ts: duplicate heresy response id "${r.id}"`);
    }
    seenResponse.add(r.id);
    if (r.cost < 0) {
      throw new Error(`apotheosis.ts: heresy response "${r.id}" has negative cost`);
    }
    if (r.limitPerRun < 1) {
      throw new Error(`apotheosis.ts: heresy response "${r.id}" limitPerRun must be >= 1`);
    }
    if (r.heresyFlat !== undefined && r.heresyFlat >= 0 && r.id !== "tolerate") {
      // Tolerate has no effects; non-Tolerate responses should reduce heresy.
      throw new Error(
        `apotheosis.ts: heresy response "${r.id}" heresyFlat must be negative (got ${r.heresyFlat})`
      );
    }
  }
})();

// =====================================================================
// Helpers
// =====================================================================

/**
 * Aggregated bonus object returned by `divineLawBonus`.
 *
 * All mult fields are additive on top of the baseline (0 = no change);
 * `worshipMult` is multiplicative (1 = no change, 2 = doubled).
 *
 * The consumer applies these in the tick loop:
 *   - `productionMult`:        multiply production by `(1 + productionMult)`
 *   - `populationGrowthMult`:  multiply pop growth by `(1 + populationGrowthMult)`
 *   - `militaryMult`:           multiply military by `(1 + militaryMult)`
 *   - `scienceMult`:             multiply science by `(1 + scienceMult)`
 *   - `goldMult`:                multiply gold by `(1 + goldMult)`
 *   - `worshipMult`:             multiply the worship-bonus by `worshipMult`
 *   - `happinessFlat`:          add to happiness per tick (or per second)
 *   - `happinessTarget`:        if non-null, clamp happiness to this value
 *   - `heresyDecays`:            UI flag; if true the heresy meter shows "Decaying"
 *   - `heresyRateMult`:          passed through to `heresyRateMult` helper
 */
export interface DivineLawBonus {
  /** Additive all-production multiplier (Abundance +0.15, Tithe +0.25). */
  productionMult: number;
  /** Additive population-growth multiplier (Fertility +0.30). */
  populationGrowthMult: number;
  /** Additive military-power multiplier (Zeal +0.40). */
  militaryMult: number;
  /** Additive science multiplier (Revelation +0.35). */
  scienceMult: number;
  /** Additive gold multiplier (Tithe +0.25). */
  goldMult: number;
  /** Multiplicative worship-bonus multiplier (Faith = 2.0; default 1.0). */
  worshipMult: number;
  /** Flat per-tick happiness bonus (Mercy +10). */
  happinessFlat: number;
  /** Happiness clamp target (Order: 80; null = no clamp). */
  happinessTarget: number | null;
  /** Whether heresy decays naturally while codified (Mercy). */
  heresyDecays: boolean;
  /** Additive multiplier on BASE_HERESY_RATE (Zeal +0.50; Order -0.50; Mercy -2.00). */
  heresyRateMult: number;
}

/**
 * Sum the bonuses from all codified Divine Laws into a single aggregate.
 *
 * All mult fields are additive (0 = no change) EXCEPT `worshipMult`,
 * which is multiplicative (1 = no change, 2 = doubled by Faith).
 * Compounding multiple laws that set `worshipMult` (currently only
 * Faith) would multiply them; with only Faith in the dataset, the
 * value is 1.0 (no Faith) or 2.0 (Faith codified).
 *
 * Used by the tick loop to compute per-resource multipliers, the
 * pop-growth rate, happiness clamps, and the worship-bonus multiplier.
 * Also feeds the standalone `heresyRateMult` helper for the heresy
 * meter's rate calculation.
 *
 * One-time effects (like Faith's `heresyFlatOnCodify: -20`) are NOT
 * included here — they're applied once by the store at codification
 * time, not per-tick. Read them directly from `DIVINE_LAW_MAP[id]`.
 *
 * @param lawsCodified  Map of law id → codified-this-run flag.
 * @returns Aggregated `DivineLawBonus` (all fields defaulted for empty input).
 *
 * @example
 *   divineLawBonus({})
 *     // → { productionMult:0, ..., worshipMult:1, happinessTarget:null,
 *     //     heresyDecays:false, heresyRateMult:0 }
 *   divineLawBonus({ law_abundance: true })
 *     // → { productionMult:0.15, ..., worshipMult:1, ... }
 *   divineLawBonus({ law_abundance: true, law_tithe: true })
 *     // → { productionMult:0.40, goldMult:0.25, ..., worshipMult:1, ... }
 *   divineLawBonus({ law_faith: true })
 *     // → { ..., worshipMult:2.0, ... }  (multiplicative, not additive)
 *   divineLawBonus({ law_zeal: true, law_order: true })
 *     // → { ..., heresyRateMult:0, ... }  (+0.50 + -0.50 cancel out)
 *   divineLawBonus({ law_mercy: true })
 *     // → { ..., heresyDecays:true, heresyRateMult:-2.00, happinessFlat:10 }
 */
export function divineLawBonus(
  lawsCodified: Record<string, boolean>
): DivineLawBonus {
  const result: DivineLawBonus = {
    productionMult: 0,
    populationGrowthMult: 0,
    militaryMult: 0,
    scienceMult: 0,
    goldMult: 0,
    worshipMult: 1, // multiplicative identity
    happinessFlat: 0,
    happinessTarget: null,
    heresyDecays: false,
    heresyRateMult: 0,
  };
  for (const law of DIVINE_LAWS) {
    if (!lawsCodified[law.id]) continue;
    if (law.productionMult !== undefined) result.productionMult += law.productionMult;
    if (law.populationGrowthMult !== undefined) result.populationGrowthMult += law.populationGrowthMult;
    if (law.militaryMult !== undefined) result.militaryMult += law.militaryMult;
    if (law.scienceMult !== undefined) result.scienceMult += law.scienceMult;
    if (law.goldMult !== undefined) result.goldMult += law.goldMult;
    if (law.worshipMult !== undefined) result.worshipMult *= law.worshipMult;
    if (law.happinessFlat !== undefined) result.happinessFlat += law.happinessFlat;
    if (law.happinessTarget !== undefined) result.happinessTarget = law.happinessTarget;
    if (law.heresyDecays) result.heresyDecays = true;
    if (law.heresyRateMult !== undefined) result.heresyRateMult += law.heresyRateMult;
  }
  return result;
}

/**
 * Return the active Worship Mode's def, or `null` if no mode is set.
 *
 * Only one worship mode can be active per run (`state.worshipMode` is a
 * single id, not a set). The consumer reads the effect fields directly
 * from the returned def:
 *
 *   const mode = worshipModeBonus(state.worshipMode);
 *   if (mode?.productionMult) production *= (1 + mode.productionMult);
 *   if (mode?.happinessDrainMult) drainRate *= mode.happinessDrainMult;
 *
 * @param modeId  The active worship mode id, or `null` if no mode picked yet.
 * @returns The `WorshipModeDef` for the id, or `null`.
 *
 * @example
 *   worshipModeBonus(null)
 *     // → null
 *   worshipModeBonus("reverence")
 *     // → { id:"reverence", name:"Reverence", ..., productionMult:0.10 }
 *   worshipModeBonus("nonexistent_id")
 *     // → null  (unknown id treated as "no mode")
 */
export function worshipModeBonus(
  modeId: string | null
): WorshipModeDef | null {
  if (!modeId) return null;
  return WORSHIP_MODE_MAP[modeId] ?? null;
}

/**
 * Compute the additive multiplier on `BASE_HERESY_RATE` from codified
 * Divine Laws and the active Worship Mode.
 *
 * Sources (all additive):
 *   - Law of Order:    -0.50  (slower heresy: rate × 0.5)
 *   - Law of Zeal:     +0.50  (faster heresy: rate × 1.5)
 *   - Law of Mercy:    -2.00  (heresy decays: rate × -1.0)
 *   - Mystery mode:    -0.25  (slower heresy: rate × 0.75)
 *
 * The effective per-second heresy rate is:
 *   `BASE_HERESY_RATE * (1 + heresyRateMult(lawsCodified, worshipMode))`
 *
 * With no laws / mode: 0 → rate = +0.05/s.
 * With Zeal + Fear:    +0.50 → rate = +0.075/s.
 * With Mercy alone:    -2.00 → rate = -0.05/s (heresy decays).
 * With Order + Mystery: -0.75 → rate = +0.0125/s.
 *
 * @param lawsCodified  Map of law id → codified-this-run flag.
 * @param modeId        Active worship mode id, or `null`.
 * @returns Additive multiplier on `BASE_HERESY_RATE` (0 = no change).
 *
 * @example
 *   heresyRateMult({}, null)
 *     // → 0
 *   heresyRateMult({ law_zeal: true }, null)
 *     // → 0.50
 *   heresyRateMult({ law_mercy: true }, null)
 *     // → -2.00  (heresy decays at base rate)
 *   heresyRateMult({ law_order: true }, "mystery")
 *     // → -0.75  (Order -0.50 + Mystery -0.25)
 *   heresyRateMult({ law_zeal: true, law_order: true }, null)
 *     // → 0  (Zeal +0.50 + Order -0.50 cancel out)
 */
export function heresyRateMult(
  lawsCodified: Record<string, boolean>,
  modeId: string | null
): number {
  let mult = 0;
  // From codified laws.
  mult += divineLawBonus(lawsCodified).heresyRateMult;
  // From active worship mode.
  const mode = worshipModeBonus(modeId);
  if (mode?.heresyRateMult !== undefined) {
    mult += mode.heresyRateMult;
  }
  return mult;
}

/**
 * Whether the Layer 5 (Apotheosis) completion conditions are met.
 *
 * Conditions (both must be true):
 *   1. At least `APOTHEOSIS_COMPLETION_LAWS_REQUIRED` (3) Divine Laws codified.
 *   2. A Heresy schism has been resolved this run.
 *
 * Matches `prestigeLayers.ts apotheosis.completeState = "Codify 3 Divine
 * Laws and resolve a Heresy schism"`. Used by `triggerPrestige()` to gate
 * advancement to Layer 6 (Singularity).
 *
 * @param lawsCodified         Map of law id → codified-this-run flag.
 * @param heresySchismResolved Whether a schism was resolved this run.
 * @returns `true` if both conditions are met.
 *
 * @example
 *   isApotheosisComplete({}, false)
 *     // → false  (no laws codified, no schism resolved)
 *   isApotheosisComplete({ law_abundance: true, law_faith: true }, false)
 *     // → false  (only 2 laws; schism not resolved)
 *   isApotheosisComplete({
 *     law_abundance: true, law_faith: true, law_mercy: true
 *   }, false)
 *     // → false  (3 laws but schism not resolved)
 *   isApotheosisComplete({}, true)
 *     // → false  (schism resolved but no laws codified)
 *   isApotheosisComplete({
 *     law_abundance: true, law_faith: true, law_mercy: true
 *   }, true)
 *     // → true  (3 laws + schism resolved)
 */
export function isApotheosisComplete(
  lawsCodified: Record<string, boolean>,
  heresySchismResolved: boolean
): boolean {
  const codifiedCount = DIVINE_LAWS.filter((l) => lawsCodified[l.id]).length;
  return (
    codifiedCount >= APOTHEOSIS_COMPLETION_LAWS_REQUIRED && heresySchismResolved
  );
}

/**
 * Convenience helper: the set of `ResourceId`s that "all resources"
 * miracles (Manna from Heaven) apply to. Mirrors the genesis.ts
 * `RESOURCES.filter(r => r.category === "primary")` convention —
 * prestige currencies (`divinity`, `evolution_points`, etc.) are
 * excluded so Manna doesn't grant free Divinity or EP.
 *
 * Exported so the consumer (store) doesn't have to re-implement the
 * filter. The consumer iterates this list and adds `grantAllResources`
 * to each.
 */
export const MIRACLE_ALL_RESOURCE_TARGETS: ResourceId[] = RESOURCES
  .filter((r) => r.category === "primary")
  .map((r) => r.id);
