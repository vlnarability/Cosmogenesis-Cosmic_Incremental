// Foresight tree — Layer 2 (Enlightenment) prestige content
//
// When a god reaches Enlightenment it becomes self-aware and begins
// interpreting reality. The player picks ONE Route per run (a run-long
// destiny) and then spends Divinity on a 20-node Foresight tree spread
// across 6 categories. Each purchased node grants a small permanent
// production / capacity / manual bonus, and may require other nodes to
// be purchased first.
//
// Six Routes (player picks one per run):
//   Growth        +15% population growth
//   Conquest      +20% military power
//   Harmony       +15% happiness
//   Wealth        +20% gold
//   Knowledge     +20% science
//   Transcendence +10% all production
//
// Six Foresight categories (4 + 4 + 3 + 3 + 3 + 3 = 20 nodes):
//   route       — bind the run's destiny and automate its routine choices
//   pressure    — read and resolve the next real stress point
//   conflict    — expose rival pressure and counterplay windows
//   continuity  — carry momentum and fate forward between runs
//   solar       — plan and prove the FTL doctrine
//   synergy     — surface hidden combinations and lock the final destiny
//
// Advancement to Layer 3 (Transcendence) requires purchasing
// ADVANCE_NODE_COUNT (10) of the 20 nodes — see worklog Task L2-data.
//
// State fields (planned for GameState — see worklog Task L2-data):
//   - activeRoute: string | null                       // chosen Route id; null before pick
//   - purchasedForesight: Record<string, boolean>      // node ids purchased this run
//
// Reference: /home/z/my-project/upload/data.js DATA.FORESIGHT_NODES (lines 118-137)
// for the original vanilla-JS node list. The TS port reshapes the nodes into
// 6 explicit categories and adds a `bonus` field to each node so the
// production / capacity / manual effects are first-class data (the vanilla
// game derived bonuses indirectly from the linked `upgradeId`).

// =====================================================================
// Routes
// =====================================================================

/** Bonus target types for routes. Routes only grant positive bonuses. */
export type RouteBonusType =
  | "population" | "military" | "happiness"
  | "gold" | "science" | "all";

export interface RouteBonus {
  /** Which domain the route amplifies. */
  type: RouteBonusType;
  /** 0.15 = +15%. Always positive — routes are boons, not debuffs. */
  value: number;
}

export interface RouteDef {
  /** Stable identifier (matches `activeRoute` in GameState). */
  id: string;
  /** Human-readable route name. */
  name: string;
  /** Narrative blurb — what choosing this route means in-fiction. */
  desc: string;
  /** Emoji glyph shown on the route card. */
  icon: string;
  /** Run-long bonus granted while this route is the active route. */
  bonus: RouteBonus;
}

export const ROUTES: RouteDef[] = [
  {
    id: "growth",
    name: "Growth",
    icon: "🌱",
    desc: "Tend to the roots of life; population swells faster under your gaze.",
    bonus: { type: "population", value: 0.15 },
  },
  {
    id: "conquest",
    name: "Conquest",
    icon: "⚔️",
    desc: "Steel and resolve sharpen the civilization's grip on force.",
    bonus: { type: "military", value: 0.20 },
  },
  {
    id: "harmony",
    name: "Harmony",
    icon: "🕊️",
    desc: "Hearts align with the design; happiness spreads across the run.",
    bonus: { type: "happiness", value: 0.15 },
  },
  {
    id: "wealth",
    name: "Wealth",
    icon: "💰",
    desc: "Coins stack where you point; gold output is blessed.",
    bonus: { type: "gold", value: 0.20 },
  },
  {
    id: "knowledge",
    name: "Knowledge",
    icon: "📜",
    desc: "Insight comes easier; science flows from every observed truth.",
    bonus: { type: "science", value: 0.20 },
  },
  {
    id: "transcendence",
    name: "Transcendence",
    icon: "🔮",
    desc: "All threads hum at once — a balanced ascension lifts every domain.",
    bonus: { type: "all", value: 0.10 },
  },
];

export const ROUTE_MAP: Record<string, RouteDef> = Object.fromEntries(
  ROUTES.map((r) => [r.id, r])
);

// =====================================================================
// Foresight Nodes
// =====================================================================

/** The six Foresight tree categories. Drives the layout of the tree UI. */
export type ForesightCategory =
  | "route" | "pressure" | "conflict" | "continuity" | "solar" | "synergy";

/** Bonus target types for Foresight nodes. Matches the TechDef.multiplier.target union. */
export type ForesightBonusType = "production" | "capacity" | "manual";

export interface ForesightBonus {
  /** Which domain the bonus amplifies. */
  type: ForesightBonusType;
  /** 0.05 = +5%. Stacks additively with other purchased nodes of the same type. */
  value: number;
}

export interface ForesightNodeDef {
  /** Stable identifier (matches keys in `purchasedForesight` in GameState). */
  id: string;
  /** Human-readable node name. */
  name: string;
  /** One-line flavour / mechanical description of what the node does. */
  desc: string;
  /** Tree category — drives which column / lane the node appears in. */
  category: ForesightCategory;
  /** Divinity cost to purchase this node. */
  cost: number;
  /** Other node ids that must be purchased before this one becomes available. */
  requires?: string[];
  /** Permanent bonus granted on purchase. Omitted on purely structural nodes. */
  bonus?: ForesightBonus;
}

export const FORESIGHT_NODES: ForesightNodeDef[] = [
  // ===== Route (4) — bind the run's destiny and automate its routine choices =====
  {
    id: "route_templates",
    name: "Save Routes",
    desc: "Record preferred run routes and apply them on seed.",
    category: "route",
    cost: 5,
    requires: [],
    bonus: { type: "manual", value: 0.05 },
  },
  {
    id: "seed_bias",
    name: "Bias the Cradle",
    desc: "Push new worlds toward the intended route.",
    category: "route",
    cost: 8,
    requires: ["route_templates"],
    bonus: { type: "production", value: 0.03 },
  },
  {
    id: "template_priority",
    name: "Prioritize Purchases",
    desc: "Make automation favor the chosen long-term backbone.",
    category: "route",
    cost: 8,
    requires: ["route_templates"],
    bonus: { type: "capacity", value: 0.05 },
  },
  {
    id: "policy_autopilot",
    name: "Resolve Routine Choices",
    desc: "Handle simple laws, doctrines, and project branches.",
    category: "route",
    cost: 14,
    requires: ["template_priority", "pressure_omens"],
    bonus: { type: "production", value: 0.05 },
  },

  // ===== Pressure (4) — read and resolve the next real stress point =====
  {
    id: "pressure_omens",
    name: "Read Bottlenecks",
    desc: "Surface the next real stress point before it hits.",
    category: "pressure",
    cost: 5,
    requires: [],
    bonus: { type: "production", value: 0.02 },
  },
  {
    id: "resource_threads",
    name: "Trace the Chains",
    desc: "Expose which exact resource routes will fail first.",
    category: "pressure",
    cost: 8,
    requires: ["pressure_omens"],
    bonus: { type: "capacity", value: 0.05 },
  },
  {
    id: "bottleneck_index",
    name: "Count Solved Omens",
    desc: "Record which predicted bottlenecks have truly been overcome.",
    category: "pressure",
    cost: 18,
    requires: ["resource_threads", "bloc_blueprints"],
    bonus: { type: "production", value: 0.08 },
  },
  {
    id: "compressed_frontiers",
    name: "Compress Mastery",
    desc: "Turn solved stages into brisk preludes.",
    category: "pressure",
    cost: 14,
    requires: ["seed_bias", "continuity_engine"],
    bonus: { type: "capacity", value: 0.08 },
  },

  // ===== Conflict (3) — expose rival pressure and counterplay windows =====
  {
    id: "rival_prophecy",
    name: "Read Rivals",
    desc: "Expose likely rival pressure earlier.",
    category: "conflict",
    cost: 5,
    requires: [],
    bonus: { type: "production", value: 0.02 },
  },
  {
    id: "counterplay_network",
    name: "Answer Pressure",
    desc: "Open counterplay windows before rivals peak.",
    category: "conflict",
    cost: 8,
    requires: ["rival_prophecy"],
    bonus: { type: "manual", value: 0.05 },
  },
  {
    id: "bloc_blueprints",
    name: "Read Blocs",
    desc: "See which congress blocs will actually hold.",
    category: "conflict",
    cost: 12,
    requires: ["counterplay_network"],
    bonus: { type: "production", value: 0.05 },
  },

  // ===== Continuity (3) — carry momentum and fate forward between runs =====
  {
    id: "continuity_engine",
    name: "Carry Momentum",
    desc: "Strengthen inherited setup power between runs.",
    category: "continuity",
    cost: 5,
    requires: [],
    bonus: { type: "production", value: 0.02 },
  },
  {
    id: "chronicle_lens",
    name: "Read History",
    desc: "Use archive outcomes as route advice.",
    category: "continuity",
    cost: 8,
    requires: ["continuity_engine"],
    bonus: { type: "capacity", value: 0.05 },
  },
  {
    id: "fate_weaving",
    name: "Weave Solved Fate",
    desc: "Turn successfully resolved pressure into inherited momentum.",
    category: "continuity",
    cost: 14,
    requires: ["bottleneck_index", "chronicle_lens"],
    bonus: { type: "production", value: 0.08 },
  },

  // ===== Solar (3) — plan and prove the FTL doctrine =====
  {
    id: "ftl_primers",
    name: "Plan the Leap",
    desc: "Identify the cleanest FTL doctrine sooner.",
    category: "solar",
    cost: 5,
    requires: [],
    bonus: { type: "production", value: 0.02 },
  },
  {
    id: "proof_scaffolds",
    name: "Prove the Jump",
    desc: "Reduce the burden of FTL proof.",
    category: "solar",
    cost: 8,
    requires: ["ftl_primers"],
    bonus: { type: "manual", value: 0.05 },
  },
  {
    id: "solar_ascension",
    name: "Ignite the Star",
    desc: "Channel solar ignition into a permanent production reservoir.",
    category: "solar",
    cost: 14,
    requires: ["proof_scaffolds", "chronicle_lens"],
    bonus: { type: "production", value: 0.08 },
  },

  // ===== Synergy (3) — surface hidden combinations and lock the final destiny =====
  {
    id: "synergy_visions",
    name: "See Hidden Synergies",
    desc: "Surface useful route, lineage, and project combinations before they are obvious.",
    category: "synergy",
    cost: 10,
    requires: ["template_priority", "chronicle_lens"],
    bonus: { type: "capacity", value: 0.08 },
  },
  {
    id: "cosmic_resonance",
    name: "Tune Cosmic Resonance",
    desc: "Align every system to a single harmonic, multiplying output without regard for stage.",
    category: "synergy",
    cost: 14,
    requires: ["synergy_visions"],
    bonus: { type: "production", value: 0.08 },
  },
  {
    id: "destiny_lock",
    name: "Lock the Destiny",
    desc: "Bind the chosen route tightly enough that future cycles drift less and arrive cleaner.",
    category: "synergy",
    cost: 30,
    requires: ["cosmic_resonance", "fate_weaving", "solar_ascension"],
    bonus: { type: "production", value: 0.15 },
  },
];

export const FORESIGHT_NODE_MAP: Record<string, ForesightNodeDef> = Object.fromEntries(
  FORESIGHT_NODES.map((n) => [n.id, n])
);

export const FORESIGHT_NODE_COUNT: number = FORESIGHT_NODES.length;

/**
 * Number of Foresight nodes the player must purchase to advance from
 * Layer 2 (Enlightenment) to Layer 3 (Transcendence).
 * Matches the spec: "Only 10 of 20 nodes need to be purchased to advance to Layer 3."
 */
export const ADVANCE_NODE_COUNT: number = 10;

/**
 * Sanity-check that every `requires` entry points at a real node id.
 * Runs once at module load; throws on a corrupted tree (programmer error,
 * not a runtime / save data error). Strips out at build time when the
 * assertion passes silently — the loop is a no-op on a valid tree.
 */
(function validateForesightTree(): void {
  const ids = new Set(FORESIGHT_NODES.map((n) => n.id));
  for (const node of FORESIGHT_NODES) {
    if (!node.requires) continue;
    for (const reqId of node.requires) {
      if (!ids.has(reqId)) {
        throw new Error(
          `foresight.ts: node "${node.id}" requires unknown node "${reqId}"`
        );
      }
    }
  }
})();

// =====================================================================
// Helpers
// =====================================================================

/**
 * Sum the bonus `value` of every purchased Foresight node whose bonus
 * type matches the requested type. Returns 0 if the player has no
 * matching nodes purchased.
 *
 * Bonuses stack additively across nodes of the same type, so this is
 * the value the production / capacity / manual multipliers should add
 * to their baseline before applying other multipliers.
 *
 * @param purchased  Record of node id → purchased (`true` = bought).
 * @param type        Bonus type to aggregate.
 *
 * @example
 *   foresightBonus({ route_templates: true, seed_bias: true }, "production")
 *     // → 0.03  (only seed_bias matches; route_templates is a manual bonus)
 *   foresightBonus({ route_templates: true }, "manual")
 *     // → 0.05
 */
export function foresightBonus(
  purchased: Record<string, boolean>,
  type: ForesightBonusType
): number {
  let total = 0;
  for (const node of FORESIGHT_NODES) {
    if (!purchased[node.id]) continue;
    if (node.bonus && node.bonus.type === type) {
      total += node.bonus.value;
    }
  }
  return total;
}

/**
 * Returns the bonus object for the given route id, or `undefined` if
 * the route id is not one of the six valid routes.
 *
 * Used by the production / happiness / etc. multipliers to look up the
 * chosen route's contribution to a given domain.
 *
 * @param routeId  One of "growth" | "conquest" | "harmony" | "wealth"
 *                 | "knowledge" | "transcendence".
 *
 * @example
 *   routeBonus("growth")        // → { type: "population", value: 0.15 }
 *   routeBonus("transcendence") // → { type: "all",         value: 0.10 }
 *   routeBonus("unknown")        // → undefined
 */
export function routeBonus(routeId: string): RouteBonus | undefined {
  const route = ROUTE_MAP[routeId];
  return route?.bonus;
}
