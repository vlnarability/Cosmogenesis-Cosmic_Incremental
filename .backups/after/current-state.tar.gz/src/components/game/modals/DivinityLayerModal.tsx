"use client";

import { useState } from "react";
import { useGameStore } from "@/game/state/store";
import {
  PRAYER_CHANNELS,
  DIVINE_MASKS,
  WORSHIP_POLARITIES,
  DIVINITY_COMPLETION_CHANNELS_REQUIRED,
} from "@/game/data/divinity_layer";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Drama, Sparkles, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

type SubTab = "channels" | "masks" | "polarity";

export function DivinityLayerModal() {
  const showDivinityModal = useGameStore((s) => s.showDivinityModal);
  const setShowDivinityModal = useGameStore((s) => s.setShowDivinityModal);
  const divinity = useGameStore((s) => s.resources.divinity || 0);
  const prayerOutput = useGameStore((s) => s.prayerOutput || 0);
  const prayerChannels = useGameStore((s) => s.prayerChannels || {});
  const activeDivineMask = useGameStore((s) => s.activeDivineMask);
  const activeWorshipPolarity = useGameStore((s) => s.activeWorshipPolarity);

  const levelPrayerChannel = useGameStore((s) => s.levelPrayerChannel);
  const selectDivineMask = useGameStore((s) => s.selectDivineMask);
  const alignWorshipPolarity = useGameStore((s) => s.alignWorshipPolarity);

  const [tab, setTab] = useState<SubTab>("channels");

  const openedCount = PRAYER_CHANNELS.filter((c) => (prayerChannels[c.id] || 0) >= 1).length;

  return (
    <Dialog open={showDivinityModal} onOpenChange={setShowDivinityModal}>
      <DialogContent className="max-w-3xl max-h-[88vh] overflow-y-auto glass-strong">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Drama className="w-5 h-5 text-violet-400" />
            Divinity Layer
          </DialogTitle>
          <DialogDescription>
            Route prayer into channels, wear a Divine Mask to shape how
            creation perceives you, and align a Worship Polarity for run-long
            effects. Open {DIVINITY_COMPLETION_CHANNELS_REQUIRED} channels and
            align a polarity to ascend to Infinity.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center justify-between rounded-lg border border-border bg-muted/30 px-3 py-2">
          <span className="text-xs text-muted-foreground uppercase tracking-wide">
            Divinity · Prayer
          </span>
          <span className="font-mono font-bold tabular-nums text-violet-300">
            {divinity.toFixed(2)} ✨ · {prayerOutput.toFixed(2)}
          </span>
        </div>

        {/* Sub-tab buttons */}
        <div className="flex gap-1 border-b border-border pb-2 flex-wrap">
          {(["channels", "masks", "polarity"] as SubTab[]).map((t) => (
            <Button
              key={t}
              size="sm"
              variant={tab === t ? "default" : "ghost"}
              className="h-7 capitalize"
              onClick={() => setTab(t)}
            >
              {t === "channels" ? `Prayer Channels (${openedCount}/${PRAYER_CHANNELS.length})` : t}
            </Button>
          ))}
        </div>

        {/* Prayer Channels */}
        {tab === "channels" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {PRAYER_CHANNELS.map((c) => {
              const level = prayerChannels[c.id] || 0;
              const nextCost = 10 * (level + 1);
              const canAfford = divinity >= nextCost;
              return (
                <div key={c.id} className="stat-card">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{c.icon}</span>
                    <span className="text-sm font-semibold truncate">{c.name}</span>
                    <Badge variant="outline" className="text-[0.6rem] ml-auto text-violet-300 border-violet-500/40">
                      Lv {level}
                    </Badge>
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{c.desc}</p>
                  <div className="flex items-center justify-between text-[0.65rem]">
                    <span className="text-muted-foreground">
                      Next: <span className="font-mono text-violet-300">{nextCost} ✨</span>
                    </span>
                    <Button
                      size="sm"
                      className="h-7"
                      disabled={!canAfford}
                      onClick={() => levelPrayerChannel(c.id)}
                    >
                      Level Up
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Divine Masks */}
        {tab === "masks" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {DIVINE_MASKS.map((m) => {
              const active = activeDivineMask === m.id;
              return (
                <div
                  key={m.id}
                  className={cn(
                    "stat-card transition-all",
                    active && "border-violet-400/60 ring-1 ring-violet-400/40"
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{m.icon}</span>
                    <span className="text-sm font-semibold truncate">{m.name}</span>
                    {active && (
                      <Badge variant="outline" className="text-[0.6rem] ml-auto text-violet-300 border-violet-500/40">
                        Worn
                      </Badge>
                    )}
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{m.desc}</p>
                  <div className="flex justify-end">
                    <Button
                      size="sm"
                      variant={active ? "destructive" : "default"}
                      className="h-7"
                      onClick={() => selectDivineMask(active ? null : m.id)}
                    >
                      {active ? "Remove" : "Wear"}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Worship Polarity */}
        {tab === "polarity" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {WORSHIP_POLARITIES.map((p) => {
              const active = activeWorshipPolarity === p.id;
              return (
                <div
                  key={p.id}
                  className={cn(
                    "stat-card transition-all",
                    active && "border-amber-400/60 ring-1 ring-amber-400/40"
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{p.icon}</span>
                    <span className="text-sm font-semibold truncate">{p.name}</span>
                    {active && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 ml-auto" />
                    )}
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{p.desc}</p>
                  <div className="flex justify-end">
                    <Button
                      size="sm"
                      variant={active ? "destructive" : "default"}
                      className="h-7"
                      onClick={() => alignWorshipPolarity(active ? null : p.id)}
                    >
                      {active ? "Clear" : "Align"}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="flex items-start gap-1.5 text-[0.7rem] pt-1">
          <Sparkles className="w-2.5 h-2.5 text-violet-300 mt-1 shrink-0" />
          <span className="text-muted-foreground">
            <span className="text-foreground/80">Tip:</span> Open {DIVINITY_COMPLETION_CHANNELS_REQUIRED}+ Prayer Channels and align a Worship Polarity to complete this layer and unlock Infinity.
          </span>
        </div>

        <div className="flex justify-end pt-2">
          <Button variant="outline" onClick={() => setShowDivinityModal(false)}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
