"use client";

import { useGameStore } from "@/game/state/store";
import {
  ECHO_TYPES,
  FORK_SCENARIOS,
  FUTURE_DEBT_TIERS,
} from "@/game/data/infinity";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Repeat, GitBranch, TrendingUp, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

export function InfinityModal() {
  const showInfinity = useGameStore((s) => s.showInfinity);
  const setShowInfinity = useGameStore((s) => s.setShowInfinity);
  const echoes = useGameStore((s) => s.echoes || 0);
  const echoesOwned = useGameStore((s) => s.echoesOwned || {});
  const forksResolved = useGameStore((s) => s.forksResolved || {});
  const futureDebtUsesThisRun = useGameStore((s) => s.futureDebtUsesThisRun || {});
  const activeDebt = useGameStore((s) => s.activeDebt || []);

  const purchaseEcho = useGameStore((s) => s.purchaseEcho);
  const resolveFork = useGameStore((s) => s.resolveFork);
  const incurFutureDebt = useGameStore((s) => s.incurFutureDebt);

  return (
    <Dialog open={showInfinity} onOpenChange={setShowInfinity}>
      <DialogContent className="max-w-3xl max-h-[88vh] overflow-y-auto glass-strong">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Repeat className="w-5 h-5 text-cyan-400" />
            Infinity
          </DialogTitle>
          <DialogDescription>
            Purchase Echoes (persistent passive bonuses), resolve Fork
            scenarios (per-run branch choices), and incur Future Debt for a
            temporary boost that compounds into a later penalty.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center justify-between rounded-lg border border-border bg-muted/30 px-3 py-2">
          <span className="text-xs text-muted-foreground uppercase tracking-wide">
            Echoes
          </span>
          <span className="font-mono font-bold tabular-nums text-cyan-300">
            {echoes.toFixed(0)} 〰
          </span>
        </div>

        {/* Active debt timers */}
        {activeDebt.length > 0 && (
          <div className="rounded-lg border border-amber-500/40 bg-amber-500/5 p-2.5 space-y-1">
            <div className="text-[0.7rem] uppercase tracking-wide text-amber-200">
              Active Future Debt
            </div>
            {activeDebt.map((d, idx) => {
              const tier = FUTURE_DEBT_TIERS.find((t) => t.id === d.id);
              if (!tier) return null;
              const inBoost = d.boostRemaining > 0;
              const inPenalty = !inBoost && d.penaltyRemaining > 0;
              const label = inBoost
                ? `Boost +${Math.round(tier.boostMult * 100)}% — ${Math.ceil(d.boostRemaining)}s`
                : inPenalty
                  ? `Penalty ${Math.round(tier.penaltyMult * 100)}% — ${Math.ceil(d.penaltyRemaining)}s`
                  : "Resolved";
              return (
                <div key={`${d.id}-${idx}`} className="text-[0.7rem] flex items-center justify-between">
                  <span className="text-foreground/80">{tier.name}</span>
                  <span
                    className={cn(
                      "font-mono font-bold",
                      inBoost && "text-emerald-300",
                      inPenalty && "text-rose-300"
                    )}
                  >
                    {label}
                  </span>
                </div>
              );
            })}
          </div>
        )}

        {/* Echoes */}
        <div className="space-y-1.5">
          <div className="text-[0.7rem] uppercase tracking-wide text-foreground/70 flex items-center gap-1.5">
            <Repeat className="w-3 h-3" /> Echoes (persistent across runs)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {ECHO_TYPES.map((e) => {
              const owned = echoesOwned[e.id] || 0;
              const canAfford = echoes >= e.cost;
              return (
                <div key={e.id} className="stat-card">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{e.icon}</span>
                    <span className="text-sm font-semibold truncate">{e.name}</span>
                    <Badge variant="outline" className="text-[0.6rem] ml-auto text-cyan-300 border-cyan-500/40">
                      ×{owned}
                    </Badge>
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{e.desc}</p>
                  <div className="flex items-center justify-between text-[0.65rem]">
                    <span className="text-muted-foreground">
                      Cost: <span className="font-mono text-cyan-300">{e.cost} 〰</span>
                    </span>
                    <Button
                      size="sm"
                      className="h-7"
                      disabled={!canAfford}
                      onClick={() => purchaseEcho(e.id)}
                    >
                      Purchase
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Fork Scenarios */}
        <div className="space-y-1.5">
          <div className="text-[0.7rem] uppercase tracking-wide text-foreground/70 flex items-center gap-1.5">
            <GitBranch className="w-3 h-3" /> Fork Scenarios (one branch per fork per run)
          </div>
          <div className="grid grid-cols-1 gap-2">
            {FORK_SCENARIOS.map((f) => {
              const resolved = forksResolved[f.id];
              return (
                <div key={f.id} className="stat-card">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{f.icon}</span>
                    <span className="text-sm font-semibold truncate">{f.name}</span>
                    {resolved && (
                      <Badge variant="outline" className="text-[0.6rem] ml-auto text-emerald-300 border-emerald-500/40">
                        Branch {resolved} chosen
                      </Badge>
                    )}
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{f.desc}</p>
                  {!resolved && (
                    <div className="flex justify-end gap-2">
                      <Button
                        size="sm"
                        variant="default"
                        className="h-7"
                        onClick={() => resolveFork(f.id, "A")}
                      >
                        A: {f.branchA.label}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7"
                        onClick={() => resolveFork(f.id, "B")}
                      >
                        B: {f.branchB.label}
                      </Button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Future Debt */}
        <div className="space-y-1.5">
          <div className="text-[0.7rem] uppercase tracking-wide text-foreground/70 flex items-center gap-1.5">
            <TrendingUp className="w-3 h-3" /> Future Debt (panic-button borrowing)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {FUTURE_DEBT_TIERS.map((d) => {
              const uses = futureDebtUsesThisRun[d.id] || 0;
              const atLimit = uses >= d.perRunLimit;
              return (
                <div key={d.id} className="stat-card">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{d.icon}</span>
                    <span className="text-sm font-semibold truncate">{d.name}</span>
                    <Badge variant="outline" className="text-[0.6rem] ml-auto text-amber-300 border-amber-500/40">
                      {uses}/{d.perRunLimit}
                    </Badge>
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{d.desc}</p>
                  <div className="flex items-center justify-between text-[0.65rem]">
                    <span className="text-muted-foreground">
                      +{Math.round(d.boostMult * 100)}% / {Math.round(d.penaltyMult * 100)}%
                    </span>
                    <Button
                      size="sm"
                      variant="destructive"
                      className="h-7"
                      disabled={atLimit}
                      onClick={() => incurFutureDebt(d.id)}
                    >
                      {atLimit ? (
                        <>
                          <CheckCircle2 className="w-3 h-3 mr-1" /> At limit
                        </>
                      ) : (
                        "Incur"
                      )}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <Button variant="outline" onClick={() => setShowInfinity(false)}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
