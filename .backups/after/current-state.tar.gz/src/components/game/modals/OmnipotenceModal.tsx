"use client";

import { useGameStore } from "@/game/state/store";
import {
  HYBRID_LINEAGES,
  STANCES,
  INSTABILITY_MAX,
  instabilityRateMult,
} from "@/game/data/omnipotence";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Layers, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

export function OmnipotenceModal() {
  const showOmnipotence = useGameStore((s) => s.showOmnipotence);
  const setShowOmnipotence = useGameStore((s) => s.setShowOmnipotence);
  const activeHybridLineage = useGameStore((s) => s.activeHybridLineage);
  const activeStance = useGameStore((s) => s.activeStance || "balanced");
  const instabilityLevel = useGameStore((s) => s.instabilityLevel || 0);
  const peakInstability = useGameStore((s) => s.peakInstability || 0);

  const selectHybridLineage = useGameStore((s) => s.selectHybridLineage);
  const setStance = useGameStore((s) => s.setStance);

  const effectiveRate = instabilityRateMult(activeStance, activeHybridLineage);
  const instabilityPct = (instabilityLevel / INSTABILITY_MAX) * 100;
  const peakPct = (peakInstability / INSTABILITY_MAX) * 100;

  return (
    <Dialog open={showOmnipotence} onOpenChange={setShowOmnipotence}>
      <DialogContent className="max-w-3xl max-h-[88vh] overflow-y-auto glass-strong">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Layers className="w-5 h-5 text-violet-400" />
            Omnipotence
          </DialogTitle>
          <DialogDescription>
            Bind one Hybrid Lineage to fuse two archetypes into the run, pick
            one Stance to shape the paradox, and survive an Instability peak
            (≥80) without overflowing (100) to ascend.
          </DialogDescription>
        </DialogHeader>

        {/* Instability meter — always visible */}
        <div className="rounded-lg border border-rose-500/40 bg-rose-500/5 p-2.5 space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-rose-200 uppercase tracking-wide">Instability</span>
            <span className="font-mono font-bold tabular-nums text-rose-300">
              {instabilityLevel.toFixed(1)} / {INSTABILITY_MAX}
            </span>
          </div>
          <Progress value={instabilityPct} className="h-2" />
          <div className="flex items-center justify-between text-[0.65rem] text-muted-foreground">
            <span>
              Peak: <span className="font-mono text-amber-300">{peakInstability.toFixed(1)}</span>
            </span>
            <span>
              Rate: <span className="font-mono text-rose-300">+{effectiveRate.toFixed(2)}/s</span>
            </span>
          </div>
          <Progress value={peakPct} className="h-1 opacity-60" />
        </div>

        {/* Hybrid Lineages */}
        <div className="space-y-1.5">
          <div className="text-[0.7rem] uppercase tracking-wide text-foreground/70 flex items-center gap-1.5">
            <Layers className="w-3 h-3" /> Hybrid Lineages (one bound per run)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {HYBRID_LINEAGES.map((h) => {
              const bound = activeHybridLineage === h.id;
              return (
                <div
                  key={h.id}
                  className={cn(
                    "stat-card transition-all",
                    bound && "border-violet-400/60 ring-1 ring-violet-400/40"
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{h.icon}</span>
                    <span className="text-sm font-semibold truncate">{h.name}</span>
                    {bound && (
                      <Badge variant="outline" className="text-[0.6rem] ml-auto text-violet-300 border-violet-500/40">
                        Bound
                      </Badge>
                    )}
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{h.desc}</p>
                  <div className="text-[0.65rem] text-muted-foreground mb-2">
                    Instability: <span className="font-mono text-rose-300">+{h.instabilityPerSec.toFixed(2)}/s</span>
                  </div>
                  <div className="flex justify-end">
                    <Button
                      size="sm"
                      variant={bound ? "destructive" : "default"}
                      className="h-7"
                      onClick={() => selectHybridLineage(bound ? null : h.id)}
                    >
                      {bound ? "Unbind" : "Bind"}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Stances */}
        <div className="space-y-1.5">
          <div className="text-[0.7rem] uppercase tracking-wide text-foreground/70">
            Stances (one active at a time)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {STANCES.map((st) => {
              const active = activeStance === st.id;
              return (
                <div
                  key={st.id}
                  className={cn(
                    "stat-card transition-all",
                    active && "border-amber-400/60 ring-1 ring-amber-400/40"
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{st.icon}</span>
                    <span className="text-sm font-semibold truncate">{st.name}</span>
                    {active && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 ml-auto" />
                    )}
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{st.desc}</p>
                  <div className="text-[0.65rem] text-muted-foreground mb-2 space-y-0.5">
                    <div>
                      Instability ×<span className="font-mono text-rose-300">{st.instabilityMult.toFixed(2)}</span>
                    </div>
                    <div>
                      Bonuses ×<span className="font-mono text-amber-300">{st.hybridMult.toFixed(2)}</span>
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <Button
                      size="sm"
                      variant={active ? "outline" : "default"}
                      className="h-7"
                      disabled={active}
                      onClick={() => setStance(st.id)}
                    >
                      {active ? "Active" : "Choose"}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <Button variant="outline" onClick={() => setShowOmnipotence(false)}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
