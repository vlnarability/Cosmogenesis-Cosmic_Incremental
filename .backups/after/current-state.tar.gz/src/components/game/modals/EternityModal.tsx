"use client";

import { useGameStore } from "@/game/state/store";
import {
  TESTAMENT_CLAUSES,
  CANONIZATIONS,
  PERMANENCE_WEAVES,
  ENDING_CHOICES,
} from "@/game/data/eternity";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Infinity as InfinityIcon, CheckCircle2, Lock } from "lucide-react";
import { cn } from "@/lib/utils";

export function EternityModal() {
  const showEternity = useGameStore((s) => s.showEternity);
  const setShowEternity = useGameStore((s) => s.setShowEternity);
  const testamentClauses = useGameStore((s) => s.testamentClauses || 0);
  const testamentClausesOwned = useGameStore((s) => s.testamentClausesOwned || {});
  const canonizationsOwned = useGameStore((s) => s.canonizationsOwned || {});
  const permanenceWeavesOwned = useGameStore((s) => s.permanenceWeavesOwned || {});
  const endingChosen = useGameStore((s) => s.endingChosen);
  const cosmicBoonStacks = useGameStore((s) => s.cosmicBoonStacks || 0);

  const purchaseTestamentClause = useGameStore((s) => s.purchaseTestamentClause);
  const performCanonization = useGameStore((s) => s.performCanonization);
  const purchasePermanenceWeave = useGameStore((s) => s.purchasePermanenceWeave);
  const chooseEnding = useGameStore((s) => s.chooseEnding);

  return (
    <Dialog open={showEternity} onOpenChange={setShowEternity}>
      <DialogContent className="max-w-3xl max-h-[88vh] overflow-y-auto glass-strong">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <InfinityIcon className="w-5 h-5 text-violet-400" />
            Eternity
          </DialogTitle>
          <DialogDescription>
            Author Testament Clauses for permanent bonuses, Canonize
            achievements as eternal truths, weave Permanence into items so
            they persist across prestiges, and finally choose an Ending.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center justify-between rounded-lg border border-border bg-muted/30 px-3 py-2">
          <span className="text-xs text-muted-foreground uppercase tracking-wide">
            Testament Clauses · Cosmic Boon Stacks
          </span>
          <span className="font-mono font-bold tabular-nums text-violet-300">
            {testamentClauses.toFixed(0)} § · {cosmicBoonStacks}★
          </span>
        </div>

        {/* Ending status / choice */}
        <div className={cn(
          "rounded-lg border p-2.5",
          endingChosen ? "border-emerald-500/40 bg-emerald-500/5" : "border-amber-500/40 bg-amber-500/5"
        )}>
          <div className="text-[0.7rem] uppercase tracking-wide text-foreground/70 mb-1.5">
            Ending {endingChosen ? "(chosen)" : "(not yet chosen)"}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {ENDING_CHOICES.map((e) => {
              const chosen = endingChosen === e.id;
              return (
                <div
                  key={e.id}
                  className={cn(
                    "stat-card transition-all",
                    chosen && "border-emerald-400/60 ring-1 ring-emerald-400/40"
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{e.icon}</span>
                    <span className="text-sm font-semibold truncate">{e.name}</span>
                    {chosen && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 ml-auto" />
                    )}
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{e.desc}</p>
                  <div className="flex justify-end">
                    <Button
                      size="sm"
                      variant={e.id === "reset" ? "destructive" : "default"}
                      className="h-7"
                      disabled={!!endingChosen}
                      onClick={() => chooseEnding(e.id)}
                    >
                      {chosen ? "Chosen" : endingChosen ? "Locked" : "Choose"}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Testament Clauses */}
        <div className="space-y-1.5">
          <div className="text-[0.7rem] uppercase tracking-wide text-foreground/70">
            Testament Clauses (one-time purchases, persist forever)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {TESTAMENT_CLAUSES.map((c) => {
              const owned = !!testamentClausesOwned[c.id];
              const canAfford = testamentClauses >= c.cost;
              return (
                <div
                  key={c.id}
                  className={cn(
                    "stat-card transition-all",
                    owned && "border-emerald-500/60 ring-1 ring-emerald-500/30"
                  )}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{c.icon}</span>
                    <span className="text-sm font-semibold truncate">{c.name}</span>
                    <Badge variant="outline" className="text-[0.6rem] ml-auto text-violet-300 border-violet-500/40">
                      {c.cost} §
                    </Badge>
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{c.desc}</p>
                  <div className="flex justify-end">
                    {owned ? (
                      <Badge variant="outline" className="text-[0.65rem] text-emerald-300 border-emerald-500/40">
                        <CheckCircle2 className="w-2.5 h-2.5 mr-0.5" /> Authored
                      </Badge>
                    ) : (
                      <Button
                        size="sm"
                        className="h-7"
                        disabled={!canAfford}
                        onClick={() => purchaseTestamentClause(c.id)}
                      >
                        Author
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Canonizations */}
        <div className="space-y-1.5">
          <div className="text-[0.7rem] uppercase tracking-wide text-foreground/70">
            Canonizations (per-item purchase)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {CANONIZATIONS.map((c) => {
              const count = canonizationsOwned[c.id] || 0;
              const canAfford = testamentClauses >= c.cost;
              return (
                <div key={c.id} className="stat-card">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{c.icon}</span>
                    <span className="text-sm font-semibold truncate">{c.name}</span>
                    <Badge variant="outline" className="text-[0.6rem] ml-auto text-violet-300 border-violet-500/40">
                      ×{count}
                    </Badge>
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{c.desc}</p>
                  <div className="flex items-center justify-between text-[0.65rem]">
                    <span className="text-muted-foreground">
                      Cost: <span className="font-mono text-violet-300">{c.cost} §</span>
                    </span>
                    <Button
                      size="sm"
                      className="h-7"
                      disabled={!canAfford}
                      onClick={() => performCanonization(c.id)}
                    >
                      Canonize
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Permanence Weaves */}
        <div className="space-y-1.5">
          <div className="text-[0.7rem] uppercase tracking-wide text-foreground/70">
            Permanence Weaves (pin items across resets)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {PERMANENCE_WEAVES.map((w) => {
              const count = permanenceWeavesOwned[w.id] || 0;
              const canAfford = testamentClauses >= w.cost;
              return (
                <div key={w.id} className="stat-card">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">{w.icon}</span>
                    <span className="text-sm font-semibold truncate">{w.name}</span>
                    <Badge variant="outline" className="text-[0.6rem] ml-auto text-violet-300 border-violet-500/40">
                      ×{count}
                    </Badge>
                  </div>
                  <p className="text-[0.7rem] text-muted-foreground leading-snug mb-2">{w.desc}</p>
                  <div className="flex items-center justify-between text-[0.65rem]">
                    <span className="text-muted-foreground">
                      Cost: <span className="font-mono text-violet-300">{w.cost} §</span>
                    </span>
                    <Button
                      size="sm"
                      className="h-7"
                      disabled={!canAfford}
                      onClick={() => purchasePermanenceWeave(w.id)}
                    >
                      Weave
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer lock if ending chosen */}
        {endingChosen && (
          <div className="flex items-start gap-1.5 text-[0.7rem] pt-1 text-amber-200/80">
            <Lock className="w-2.5 h-2.5 mt-1 shrink-0" />
            <span>
              Ending chosen ({endingChosen === "reset" ? "Reset Universe" : "Preserve Universe"}). Further purchases this run are still allowed, but the loop is closed.
            </span>
          </div>
        )}

        <div className="flex justify-end pt-2">
          <Button variant="outline" onClick={() => setShowEternity(false)}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
