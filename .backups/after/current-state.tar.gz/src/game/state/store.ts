"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { GameState, GameStore, StageId, TabId } from "./types";
import { emptyResources, emptyCapacities } from "../data/resources";
import { STAGES, STAGE_IDS, nextStage } from "../data/stages";
import { ACTION_MAP } from "../data/actions";
import { SYSTEMS, SYSTEM_MAP, systemCost } from "../data/systems";
import { TECH_MAP, TECHS } from "../data/techs";
import { UPGRADE_MAP, UPGRADES, upgradeCost } from "../data/upgrades";
import { STORY_MAP, STORY_TRIGGERS } from "../data/story";
import { ARCHETYPE_MAP, dominantArchetype } from "../data/archetypes";
import { ACHIEVEMENTS, achievementBonus, type AchievementCheckCtx } from "../data/achievements";
import { EVENTS, eventsForStage, EVENT_MAP } from "../data/events";
import {
  CHALLENGE_MAP,
  challengeMasteryBonusFromRepeats,
  getMaxRepeats,
  getChallengeDebuffAtRepeat,
} from "../data/challenges";
import {
  FORESIGHT_NODE_MAP,
  FORESIGHT_NODES,
  ROUTE_MAP,
  ADVANCE_NODE_COUNT,
  foresightBonus,
  routeBonus,
} from "../data/foresight";
import {
  OFFERING_MAP,
  OFFERINGS,
  RITUAL_MAP,
  RITUALS,
  SCRIPT_MAP,
  SCRIPTS,
  BLOOD_PACT_MAP,
  BLOOD_PACTS,
  activeRitualProductionBonus,
  activeRitualPopMult,
  transcendenceDivinityPerSecond,
} from "../data/transcendence";
import {
  CRADLE_WORLDS,
  CRADLE_WORLD_MAP,
  PRIME_CONDITIONS,
  SACRED_GEOGRAPHIES,
  DORMANT_SEEDS,
  DORMANT_SEED_MAP,
  DIFFICULTY_TIERS,
  worldProductionMult,
  worldCapMult,
  worldPopGrowthMult,
  worldEpMultiplier,
  worldStartResourceBonus,
  worldStartPopulationBonus,
  worldStartTech,
  type WorldConfig,
} from "../data/genesis";
import {
  DIVINE_LAWS,
  DIVINE_LAW_MAP,
  WORSHIP_MODES,
  WORSHIP_MODE_MAP,
  MIRACLES,
  MIRACLE_MAP,
  HERESY_RESPONSES,
  HERESY_RESPONSE_MAP,
  BASE_HERESY_RATE,
  HERESY_MAX,
  APOTHEOSIS_COMPLETION_LAWS_REQUIRED,
  divineLawBonus,
  worshipModeBonus,
  heresyRateMult,
  isApotheosisComplete,
  MIRACLE_ALL_RESOURCE_TARGETS,
} from "../data/apotheosis";
import {
  RELIC_LOADOUTS,
  RELIC_LOADOUT_MAP,
  LOGIC_CORES,
  LOGIC_CORE_MAP,
  MAX_INSTALLED_LOGIC_CORES,
  relicBonus,
  logicCoreBonus,
} from "../data/singularity";
import {
  HYBRID_LINEAGES,
  HYBRID_LINEAGE_MAP,
  STANCES,
  STANCE_MAP,
  INSTABILITY_MAX,
  hybridBonus,
  instabilityRateMult,
  isOmnipotenceComplete,
} from "../data/omnipotence";
import {
  PRAYER_CHANNELS,
  PRAYER_CHANNEL_MAP,
  DIVINE_MASKS,
  DIVINE_MASK_MAP,
  WORSHIP_POLARITIES,
  WORSHIP_POLARITY_MAP,
  DIVINITY_COMPLETION_CHANNELS_REQUIRED,
  prayerChannelBonus,
  divineMaskBonus,
  worshipPolarityBonus,
  prayerRate,
  isDivinityComplete,
} from "../data/divinity_layer";
import {
  ECHO_TYPES,
  ECHO_MAP,
  FORK_SCENARIOS,
  FORK_MAP,
  FUTURE_DEBT_TIERS,
  FUTURE_DEBT_MAP,
  echoBonus,
  forkBonus,
  isInfinityComplete,
} from "../data/infinity";
import {
  TESTAMENT_CLAUSES,
  TESTAMENT_CLAUSE_MAP,
  CANONIZATIONS,
  CANONIZATION_MAP,
  PERMANENCE_WEAVES,
  PERMANENCE_WEAVE_MAP,
  ENDING_CHOICES,
  ENDING_CHOICE_MAP,
  testamentClauseBonus,
  canonizationBonus,
  cosmicBoonBonus,
  isEternityComplete,
} from "../data/eternity";
import { RESOURCES as ALL_RESOURCES } from "../data/resources";

const STORAGE_KEY = "evolution_idle_v2";

function initialRunState(): Partial<GameState> {
  const resources = emptyResources();
  const capacities = emptyCapacities();
  resources.atp = 15;
  resources.glucose = 20;
  resources.happiness = 75;
  return {
    stageIndex: 0,
    time: 0,
    population: 8,
    populationProgress: 0,
    maxPopulation: 8,
    resources,
    capacities,
    ownedSystems: {},
    systemEnabled: {},
    technologies: {},
    lockedTechs: {},
    archetypeAffinity: {},
    lockedArchetype: null,
    log: ["New run started. The first spark stirs."],
  };
}

function initialMetaState(): Partial<GameState> {
  return {
    evolutionPoints: 0,
    totalRuns: 0,
    galacticWins: 0,
    stageClearCounts: Object.fromEntries(STAGE_IDS.map((s) => [s, 0])) as Record<StageId, number>,
    fastestCellClear: 0,
    totalEventsResolved: 0,
    totalPlayTime: 0,
    totalActions: 0,
    totalSystemsBuilt: 0,
    totalTechResearched: 0,
    upgrades: Object.fromEntries(UPGRADES.map((u) => [u.id, 0])),
    storyUnlocked: { first_spark: true },
    storyAcknowledged: {},
    archive: [],
    archivedArchetypes: [],
    unlockedLayers: { evolution: true },
    achievements: {},
    newAchievements: [],
    unlockedChallenges: false,
    activeChallenge: null,
    completedChallenges: {},
    challengeRepeatCounts: {},
    showChallenges: false,
    showPrestigeTab: false,

    // Layer 2: Enlightenment
    enlightenmentUnlocked: false,
    divinity: 0,
    selectedRoute: null,
    foresightNodes: {},
    showEnlightenment: false,

    // Layer 3: Transcendence
    transcendenceUnlocked: false,
    showTranscendence: false,
    offeringsUsedThisRun: {},
    ritualUsesThisRun: {},
    ritualsUsedAllTime: {},
    bloodPactUsesThisRun: {},
    bloodPactUsedAllTime: false,
    activeScripts: {},
    scriptsTriedAllTime: {},
    activeRituals: [],
    evolveSkipBuffs: 0,

    // Layer 4: Genesis
    genesisUnlocked: false,
    showGenesis: false,
    worldConfig: null,
    cradleWorldWins: {},
    awakenedSeedsThisRun: {},
    awakenedSeedsAllTime: {},

    // Layer 5: Apotheosis
    apotheosisUnlocked: false,
    showApotheosis: false,
    divineLawsEnactedThisRun: {},
    divineLawsEnactedAllTime: {},
    worshipMode: null,
    worshipModesUsedAllTime: {},
    miracleUsesThisRun: {},
    miracleUsesAllTime: {},
    heresyLevel: 0,
    heresyResponseUsesThisRun: {},
    heresySurvivedAllTime: false,

    // Layer 6: Singularity
    singularityUnlocked: false,
    showSingularity: false,
    activeRelicLoadout: null,
    relicsBoundAllTime: {},
    activeLogicCores: {},
    logicCoresEnabledAllTime: {},

    // Layer 7: Omnipotence
    omnipotenceUnlocked: false,
    showOmnipotence: false,
    activeHybridLineage: null,
    hybridLineagesTriedAllTime: {},
    activeStance: "balanced",
    stancesTriedAllTime: {},
    instabilityLevel: 0,
    peakInstability: 0,

    // Layer 8: Divinity
    divinityUnlocked: false,
    showDivinityModal: false,
    prayerChannels: {},
    prayerOutput: 0,
    activeDivineMask: null,
    divineMasksTriedAllTime: {},
    activeWorshipPolarity: null,
    worshipPolaritiesTriedAllTime: {},

    // Layer 9: Infinity
    infinityUnlocked: false,
    showInfinity: false,
    echoes: 0,
    echoesOwned: {},
    forksResolved: {},
    forksResolvedAllTime: {},
    futureDebtUsesThisRun: {},
    futureDebtRepaidAllTime: false,
    activeDebt: [],

    // Layer 10: Eternity
    eternityUnlocked: false,
    showEternity: false,
    testamentClauses: 0,
    testamentClausesOwned: {},
    canonizationsOwned: {},
    permanenceWeavesOwned: {},
    endingChosen: null,
    cosmicBoonStacks: 0,

    currentTab: "actions",
    speed: 1,
    paused: false,
    showShop: false,
    showEvolve: false,
    showSettings: false,
    activeStoryPopup: "first_spark",
    activeEvent: null,
    eventCooldown: 30, // first event fires sooner (30s) to hook new players
    eventHistory: [],
    hasSeenIntro: false,
    lastSaved: Date.now(),
    tutorialStep: 0,
    tutorialActive: true,
    tutorialDismissed: false,
    eventFrequency: "normal",
  };
}

export const useGameStore = create<GameStore>()(
  persist(
    (set, get) => ({
      ...initialRunState(),
      ...initialMetaState(),

      // ============ TICK ============
      tick: (dt) => {
        const s = get();
        if (s.paused) return;
        // Temporal Acceleration: permanent game-speed multiplier (Layer 1 upgrade)
        const speedMultLvl = s.upgrades["temporal_acceleration"] || 0;
        const permSpeedMult = 1 + speedMultLvl * 0.5;
        const realDt = dt * s.speed * permSpeedMult;

        const autoLvl = s.upgrades["inherited_efficiency"] || 0;
        // Deep Memory: +5% production per prestige (scales with totalRuns)
        const deepMemoryLvl = s.upgrades["deep_memory"] || 0;
        const prestigeMult = 1 + deepMemoryLvl * 0.05 * (s.totalRuns || 0);
        const autoMult = (1 + autoLvl * 0.15) * prestigeMult;
        const techMult = techMultiplier(s, "production");
        const capBoostLvl = s.upgrades["expansive_vaults"] || 0;
        const capMult = 1 + capBoostLvl * 0.20;
        const hasAutoBalancer = (s.upgrades["auto_balancer"] || 0) > 0;

        // Archetype bonus
        const archetype = s.lockedArchetype ? ARCHETYPE_MAP[s.lockedArchetype] : null;
        const archAllMult = archetype?.bonus.allProductionMult || 0;
        const archPopMult = archetype?.bonus.populationGrowthMult || 0;
        const archCapMult = archetype?.bonus.capMult || 0;

        // ===== Layer 2-6 bonus setup =====
        // Layer 2: Route bonus (player-picked destiny for this run)
        const routeB = s.selectedRoute ? routeBonus(s.selectedRoute) : undefined;
        // Layer 4: World config authored-facet multipliers (Genesis)
        const worldCfg = s.worldConfig;
        let worldProdBonus = 0;
        let worldPopGrowthBonus = 0;
        let worldCapMap: Partial<Record<string, number>> = {};
        if (worldCfg) {
          const awakened = !!(s.awakenedSeedsThisRun?.[worldCfg.dormantSeed]);
          worldProdBonus = worldProductionMult(worldCfg, awakened);
          worldPopGrowthBonus = worldPopGrowthMult(worldCfg);
          worldCapMap = worldCapMult(worldCfg, awakened);
        }
        // Layer 5: Divine Law aggregate bonus + Worship Mode active bonus
        const lawBonus = divineLawBonus(s.divineLawsEnactedThisRun || {});
        const worship = s.worshipMode ? worshipModeBonus(s.worshipMode) : null;
        // Layer 6: Relic loadout + Logic Core passive bonuses
        const relic = relicBonus(s.activeRelicLoadout);
        let relicProdMult = relic.productionMult;
        let relicCapMult = relic.capsMult;
        if (relic.special?.kind === "scale_with_installed_cores") {
          const installedCount = Object.values(s.activeLogicCores || {}).filter(Boolean).length;
          relicProdMult *= (1 + relic.special.perCoreMult * installedCount);
          relicCapMult *= (1 + relic.special.perCoreMult * installedCount);
        }
        const coreBonus = logicCoreBonus(s.activeLogicCores || {});

        // ===== Layer 7-10 bonus setup =====
        // Layer 7: Omnipotence — hybrid lineage bonus × stance.hybridMult
        const hybrid = hybridBonus(s.activeHybridLineage);
        const stanceDef = STANCE_MAP[s.activeStance || "balanced"] || STANCES[0];
        const stanceHybridMult = stanceDef ? stanceDef.hybridMult : 1.0;
        const hybridProdBonus = hybrid.productionMult * stanceHybridMult;
        const hybridCapBonus = hybrid.capsMult * stanceHybridMult;
        const hybridPopBonus = hybrid.populationGrowthMult * stanceHybridMult;
        const hybridSciBonus = hybrid.scienceMult * stanceHybridMult;
        const hybridMilBonus = hybrid.militaryMult * stanceHybridMult;

        // Layer 8: Divinity — prayer channel aggregate + divine mask + worship polarity
        const prayerBonus = prayerChannelBonus(s.prayerChannels || {});
        const maskBonus = divineMaskBonus(s.activeDivineMask);
        const polarityBonus = worshipPolarityBonus(s.activeWorshipPolarity);
        const divMaskDivinityMult = 1 + maskBonus.divinityMult;

        // Layer 9: Infinity — echo aggregate + per-fork chosen branch bonus
        const echoAgg = echoBonus(s.echoesOwned || {});
        let forkAggProdMult = 0;
        let forkAggPopMult = 0;
        let forkAggMilMult = 0;
        let forkAggSciMult = 0;
        let forkAggCapMult = 0;
        let forkAggGoldMult = 0;
        let forkAggEpMult = 0;
        for (const fork of FORK_SCENARIOS) {
          const branch = (s.forksResolved || {})[fork.id];
          if (branch !== "A" && branch !== "B") continue;
          const fb = forkBonus(fork.id, branch);
          forkAggProdMult += fb.productionMult;
          forkAggPopMult += fb.populationGrowthMult;
          forkAggMilMult += fb.militaryMult;
          forkAggSciMult += fb.scienceMult;
          forkAggCapMult += fb.capsMult;
          forkAggGoldMult += fb.goldMult;
          forkAggEpMult += fb.epMult;
        }
        void forkAggEpMult; // EP multiplier is reserved for future prestige-EP wiring
        // Layer 9: active debt timers — compute current debt production multiplier
        let activeDebtProdMult = 0;
        let activeDebt = (s.activeDebt || []).map((d) => {
          const tier = FUTURE_DEBT_MAP[d.id];
          if (!tier) return null;
          let boostRemaining = Math.max(0, d.boostRemaining - realDt);
          let penaltyRemaining = d.penaltyRemaining;
          if (boostRemaining <= 0) {
            // boost phase ended; start penalty phase if not already started
            if (penaltyRemaining <= 0) {
              penaltyRemaining = tier.penaltyDuration;
            } else {
              penaltyRemaining = Math.max(0, penaltyRemaining - realDt);
            }
          }
          if (boostRemaining > 0) activeDebtProdMult += tier.boostMult;
          else if (penaltyRemaining > 0) activeDebtProdMult += tier.penaltyMult;
          return { id: d.id, boostRemaining, penaltyRemaining };
        }).filter((d): d is { id: string; boostRemaining: number; penaltyRemaining: number } => d !== null);
        // Drop debts where both phases are over; mark repaid when first debt completes
        activeDebt = activeDebt.filter((d) => d.boostRemaining > 0 || d.penaltyRemaining > 0);

        // Layer 10: Eternity — testament clause aggregate + cosmic boon
        const testamentAgg = testamentClauseBonus(s.testamentClausesOwned || {});
        const canonAgg = canonizationBonus(s.canonizationsOwned || {});
        const cosmicBoon = cosmicBoonBonus(s.cosmicBoonStacks || 0);

        // Layer 3: Ritual timers decrement + active ritual bonuses
        let activeRituals = (s.activeRituals || [])
          .map((r) => ({ ...r, remaining: Math.max(0, r.remaining - realDt) }))
          .filter((r) => r.remaining > 0);
        const ritualTimers: Record<string, number> = {};
        for (const r of activeRituals) ritualTimers[r.id] = r.remaining;
        const ritualProdMult = activeRitualProductionBonus(ritualTimers, s.ritualUsesThisRun || {});
        const ritualPopBonus = activeRitualPopMult(ritualTimers, s.ritualUsesThisRun || {});
        // Layer 3: Divinity/s generated by Transcendence scripts/rituals + Layer 6 Faith Core
        const transDivinityPerSec = transcendenceDivinityPerSecond(
          s.activeScripts || {},
          s.ritualUsesThisRun || {}
        ) + coreBonus.divinityPerSec;

        // Challenge debuffs (Layer 1: Evolution) — scaled by repeat count.
        // Each effect is a {target, mode, value}. Modes: mult | flat_per_sec | flat.
        // Targets: food | science | production | military_power | population_growth |
        //          happiness | caps | starting_pop | all_production
        let challengeFoodMult = 1;
        let challengeScienceMult = 1;
        let challengeProdMult = 1;
        let challengeMilitaryMult = 1;
        let challengePopMult = 1;
        let challengeAllProdMult = 1;
        let challengeCapMult = 1;
        let challengeHappinessDrain = 0;
        if (s.activeChallenge) {
          const ch = CHALLENGE_MAP[s.activeChallenge];
          if (ch) {
            const currentRepeat = (s.challengeRepeatCounts || {})[s.activeChallenge] || 0;
            const nextRepeat = currentRepeat + 1;
            const scaledDebuff = getChallengeDebuffAtRepeat(s.activeChallenge, nextRepeat);
            for (const e of scaledDebuff.effects) {
              // Only mult and flat_per_sec effects apply mid-tick.
              // flat effects (e.g. starting_pop) are applied at run start, not here.
              if (e.mode === "mult") {
                const v = e.value;
                switch (e.target) {
                  case "food": challengeFoodMult *= (1 + v); break;
                  case "science": challengeScienceMult *= (1 + v); break;
                  case "production": challengeProdMult *= (1 + v); break;
                  case "military_power": challengeMilitaryMult *= (1 + v); break;
                  case "population_growth": challengePopMult *= (1 + v); break;
                  case "all_production": challengeAllProdMult *= (1 + v); break;
                  case "caps": challengeCapMult *= (1 + v); break;
                  default: break;
                }
              } else if (e.mode === "flat_per_sec") {
                if (e.target === "happiness") {
                  challengeHappinessDrain += e.value;
                }
              }
            }
          }
        }

        const resources = { ...s.resources };
        let capacities = recomputeCapacitiesFresh(s, capMult + archCapMult);
        // Apply challenge cap debuff after base capacity computation
        if (challengeCapMult !== 1) {
          for (const r of Object.keys(capacities)) {
            capacities[r] = Math.max(1, (capacities[r] || 0) * challengeCapMult);
          }
        }
        // Layer 4: World config per-resource cap multipliers (Cradle World / Geography / Vault Seed)
        if (Object.keys(worldCapMap).length > 0) {
          for (const [r, m] of Object.entries(worldCapMap)) {
            capacities[r] = Math.max(1, (capacities[r] || 0) * (1 + (m as number)));
          }
        }
        // Layer 6: Relic cap multiplier (Singularity Core −20%, Stone Tablet +50%, Omni Matrix +10%)
        if (relicCapMult !== 0) {
          for (const r of Object.keys(capacities)) {
            capacities[r] = Math.max(1, (capacities[r] || 0) * (1 + relicCapMult));
          }
        }
        // Layer 7: Hybrid Lineage cap multiplier (Photosynthetic Crystal +20% × stance, Crystal Survivor +30% × stance)
        if (hybridCapBonus !== 0) {
          for (const r of Object.keys(capacities)) {
            capacities[r] = Math.max(1, (capacities[r] || 0) * (1 + hybridCapBonus));
          }
        }
        // Layer 8: Divine Mask + Worship Polarity cap multiplier (Creator +15%, Preserver +30%, Sovereign +10%)
        const maskCapBonus = maskBonus.capsMult;
        if (maskCapBonus !== 0) {
          for (const r of Object.keys(capacities)) {
            capacities[r] = Math.max(1, (capacities[r] || 0) * (1 + maskCapBonus));
          }
        }
        // Layer 9: Echo + Fork cap multiplier (Stability Echo × count × 10%, Realm of Mirrors A +30%)
        const echoForkCapBonus = echoAgg.capsMult + forkAggCapMult;
        if (echoForkCapBonus !== 0) {
          for (const r of Object.keys(capacities)) {
            capacities[r] = Math.max(1, (capacities[r] || 0) * (1 + echoForkCapBonus));
          }
        }
        // Layer 10: Testament Clause of Endurance +100% caps + Cosmic Boon (×stacks) cap bonus
        const eternityCapBonus = testamentAgg.capsMult + cosmicBoon.capsMult;
        if (eternityCapBonus !== 0) {
          for (const r of Object.keys(capacities)) {
            capacities[r] = Math.max(1, (capacities[r] || 0) * (1 + eternityCapBonus));
          }
        }

        // Apply system production — with cap-aware pausing
        for (const [sysId, count] of Object.entries(s.ownedSystems)) {
          if (!count) continue;
          const sys = SYSTEM_MAP[sysId];
          if (!sys) continue;
          if (sys.requiredTech && !s.technologies[sys.requiredTech]) continue;

          // Check if system is manually disabled
          const manuallyEnabled = s.systemEnabled[sysId] !== false; // default true
          if (!manuallyEnabled && !hasAutoBalancer) continue;

          // Cap-aware logic: if all output resources are at cap, idle the system
          // (don't produce, don't consume upkeep — no waste)
          const outputsCapped = Object.keys(sys.produces).length > 0 &&
            Object.keys(sys.produces).every((r) => {
              const cap = capacities[r] || 0;
              return (resources[r] || 0) >= cap - 0.01;
            });

          if (outputsCapped) {
            // System idles — no production, no upkeep
            continue;
          }

          const stageMult = sys.stage === STAGES[s.stageIndex].id ? 1 : 0.5;
          const mult = autoMult * techMult * stageMult * (1 + archAllMult) * challengeAllProdMult;

          // Per-resource archetype bonus + challenge debuff
          const produces = sys.produces as Record<string, number>;
          for (const [r, v] of Object.entries(produces)) {
            const archResBonus = archetype?.bonus.productionMult?.[r] || 0;
            let resChallengeMult = 1;
            if (r === "food") resChallengeMult = challengeFoodMult;
            else if (r === "science") resChallengeMult = challengeScienceMult;
            else if (r === "production") resChallengeMult = challengeProdMult;
            else if (r === "military_power") resChallengeMult = challengeMilitaryMult;
            // Layer 2-6 per-resource multiplier (route / ritual / world / law / worship / relic / core)
            let layerResMult = 1;
            if (routeB) {
              if (
                routeB.type === "all" ||
                (routeB.type === "gold" && r === "gold") ||
                (routeB.type === "science" && r === "science") ||
                (routeB.type === "military" && r === "military_power") ||
                (routeB.type === "happiness" && r === "happiness")
              ) {
                layerResMult *= (1 + routeB.value);
              }
            }
            // Layer 3: Ritual production mult (Golden Hand +20% production)
            if (r === "production") layerResMult *= (1 + ritualProdMult);
            // Layer 3: Ritual gold mult (Golden Hand +20% gold) — read directly from data
            if (r === "gold") {
              for (const ritual of RITUALS) {
                if (!s.ritualUsesThisRun?.[ritual.id]) continue;
                if (ritual.duration !== undefined && (ritualTimers[ritual.id] || 0) <= 0) continue;
                for (const eff of ritual.effects) {
                  if (eff.mode === "mult" && eff.target === "gold") layerResMult *= (1 + eff.value);
                }
              }
            }
            if (r === "military_power") {
              for (const ritual of RITUALS) {
                if (!s.ritualUsesThisRun?.[ritual.id]) continue;
                if (ritual.duration !== undefined && (ritualTimers[ritual.id] || 0) <= 0) continue;
                for (const eff of ritual.effects) {
                  if (eff.mode === "mult" && eff.target === "military_power") layerResMult *= (1 + eff.value);
                }
              }
            }
            if (r === "science") {
              for (const ritual of RITUALS) {
                if (!s.ritualUsesThisRun?.[ritual.id]) continue;
                if (ritual.duration !== undefined && (ritualTimers[ritual.id] || 0) <= 0) continue;
                for (const eff of ritual.effects) {
                  if (eff.mode === "mult" && eff.target === "science") layerResMult *= (1 + eff.value);
                }
              }
            }
            // Layer 4: World production bonus (additive to all production)
            layerResMult *= (1 + worldProdBonus);
            // Layer 5: Divine Law per-resource multipliers
            if (r === "gold") layerResMult *= (1 + lawBonus.goldMult);
            if (r === "science") layerResMult *= (1 + lawBonus.scienceMult);
            if (r === "military_power") layerResMult *= (1 + lawBonus.militaryMult);
            // Layer 5: Worship mode per-resource multipliers
            if (worship) {
              if (r === "production") layerResMult *= (1 + (worship.productionMult || 0));
              if (r === "gold") layerResMult *= (1 + (worship.goldMult || 0));
              if (r === "science") layerResMult *= (1 + (worship.scienceMult || 0));
              if (r === "military_power") layerResMult *= (1 + (worship.militaryMult || 0));
            }
            // Layer 6: Relic per-resource multipliers
            if (r === "production") layerResMult *= (1 + relicProdMult);
            if (r === "gold") layerResMult *= (1 + relic.goldMult);
            if (r === "science") layerResMult *= (1 + relic.scienceMult);
            if (r === "military_power") layerResMult *= (1 + relic.militaryMult);
            if (r === "food") layerResMult *= (1 + relic.foodMult);
            if (r === "organic_matter") layerResMult *= (1 + relic.organicMatterMult);
            // Layer 6: Logic core per-resource multipliers
            if (r === "gold") layerResMult *= (1 + coreBonus.goldMult);
            if (r === "science") layerResMult *= (1 + coreBonus.scienceMult);
            if (r === "military_power") layerResMult *= (1 + coreBonus.militaryMult);
            // Layer 7: Hybrid Lineage per-resource multipliers (scaled by stance)
            if (r === "production") layerResMult *= (1 + hybridProdBonus);
            if (r === "science") layerResMult *= (1 + hybridSciBonus);
            if (r === "military_power") layerResMult *= (1 + hybridMilBonus);
            // Layer 8: Prayer channel + Divine Mask + Worship Polarity per-resource
            if (r === "production") layerResMult *= (1 + prayerBonus.productionMult + maskBonus.productionMult + polarityBonus.productionMult);
            if (r === "gold") layerResMult *= (1 + prayerBonus.goldMult + maskBonus.goldMult + polarityBonus.goldMult);
            if (r === "science") layerResMult *= (1 + prayerBonus.scienceMult + maskBonus.scienceMult + polarityBonus.scienceMult);
            if (r === "military_power") layerResMult *= (1 + prayerBonus.militaryMult + maskBonus.militaryMult + polarityBonus.militaryMult);
            // Layer 9: Echo + Fork per-resource multipliers + active debt production mult
            if (r === "production") layerResMult *= (1 + echoAgg.productionMult + forkAggProdMult + activeDebtProdMult);
            if (r === "gold") layerResMult *= (1 + echoAgg.goldMult + forkAggGoldMult);
            if (r === "science") layerResMult *= (1 + echoAgg.scienceMult + forkAggSciMult);
            if (r === "military_power") layerResMult *= (1 + echoAgg.militaryMult + forkAggMilMult);
            // Layer 10: Testament clause per-resource + Canonization production mult
            if (r === "production") layerResMult *= (1 + testamentAgg.productionMult + canonAgg.productionMult + cosmicBoon.productionMult);
            if (r === "gold") layerResMult *= (1 + testamentAgg.goldMult);
            if (r === "science") layerResMult *= (1 + testamentAgg.scienceMult);
            if (r === "military_power") layerResMult *= (1 + testamentAgg.militaryMult);
            // Layer 10: Clause of Unity meta-amp applied LAST per-resource
            if (testamentAgg.allBonusesMult !== 0) {
              layerResMult *= (1 + testamentAgg.allBonusesMult);
            }
            const rate = v * count * mult * (1 + archResBonus) * resChallengeMult * layerResMult;
            resources[r] = (resources[r] || 0) + rate * realDt;
          }
          // Upkeep
          if (sys.upkeep) {
            const upkeep = sys.upkeep as Record<string, number>;
            for (const [r, v] of Object.entries(upkeep)) {
              resources[r] = (resources[r] || 0) - v * count * realDt;
            }
          }
        }

        // Challenge: flat-per-second happiness drain
        if (challengeHappinessDrain !== 0) {
          const cap = capacities.happiness || 100;
          resources.happiness = Math.max(0, Math.min(cap, (resources.happiness || 0) + challengeHappinessDrain * realDt));
        }

        // Clamp resources to capacities (no overflow)
        for (const r of Object.keys(resources)) {
          const cap = capacities[r];
          if (cap != null && resources[r] > cap) resources[r] = cap;
          if (resources[r] < 0) resources[r] = 0;
        }

        // Slow passive ATP for cell (keeps early game from stalling)
        if (STAGES[s.stageIndex].id === "cell") {
          resources.atp = Math.min(capacities.atp || 30, resources.atp + 0.5 * realDt);
        }

        // ===== Layer 3-6 post-production effects =====
        // Layer 3: Divinity/s (Prayer Mill script + Eternal Well ritual + Layer 6 Faith Core)
        if (transDivinityPerSec > 0) {
          const cap = capacities.divinity || Infinity;
          resources.divinity = Math.min(cap, (resources.divinity || 0) + transDivinityPerSec * realDt);
        }
        // Layer 3: Calm the Storm ritual — set happiness to 100 while active
        if ((ritualTimers["calm_storm"] || 0) > 0) {
          resources.happiness = 100;
        }
        // Layer 3: Comfort script — drift happiness upward when below threshold
        if (s.activeScripts?.["comfort"]) {
          const comfort = SCRIPT_MAP["comfort"];
          if (comfort?.behavior.kind === "happiness_drift") {
            if ((resources.happiness || 0) < comfort.behavior.below) {
              const cap = capacities.happiness || 100;
              resources.happiness = Math.min(
                cap,
                Math.max(0, (resources.happiness || 0) + comfort.behavior.perSec * realDt)
              );
            }
          }
        }
        // Layer 6: Relic happiness drain (Eternal Flame −0.2/s, War Drum −0.3/s)
        if (relic.happinessDrainPerSec !== 0) {
          const cap = capacities.happiness || 100;
          resources.happiness = Math.max(0, Math.min(cap, (resources.happiness || 0) + relic.happinessDrainPerSec * realDt));
        }
        // Layer 5: Law of Mercy — +10 happiness flat per tick-window equivalent (scaled by dt)
        if (lawBonus.happinessFlat !== 0) {
          const cap = capacities.happiness || 100;
          resources.happiness = Math.max(0, Math.min(cap, (resources.happiness || 0) + lawBonus.happinessFlat * realDt * 0.1));
        }
        // Layer 5: Worship mode happiness flat (Wonder +10, Devotion +15)
        if (worship?.happinessFlat) {
          const cap = capacities.happiness || 100;
          resources.happiness = Math.max(0, Math.min(cap, (resources.happiness || 0) + worship.happinessFlat * realDt * 0.1));
        }
        // Layer 5: Law of Order — clamp happiness to target while codified
        if (lawBonus.happinessTarget !== null) {
          resources.happiness = lawBonus.happinessTarget;
        }

        // Layer 5: Heresy ticking (rises passively when Apotheosis is unlocked)
        let heresyLevel = s.heresyLevel || 0;
        if (s.apotheosisUnlocked && heresyLevel < HERESY_MAX) {
          const rate = BASE_HERESY_RATE * (1 + heresyRateMult(s.divineLawsEnactedThisRun || {}, s.worshipMode));
          heresyLevel = Math.min(HERESY_MAX, Math.max(0, heresyLevel + rate * realDt));
        }

        // ===== Layer 7-10 post-production effects =====
        // Layer 7: Instability meter — rises per second while Omnipotence is unlocked
        let instabilityLevel = s.instabilityLevel || 0;
        let peakInstability = s.peakInstability || 0;
        if (s.omnipotenceUnlocked && instabilityLevel < INSTABILITY_MAX) {
          const rate = instabilityRateMult(s.activeStance, s.activeHybridLineage);
          instabilityLevel = Math.min(INSTABILITY_MAX, Math.max(0, instabilityLevel + rate * realDt));
          if (instabilityLevel > peakInstability) peakInstability = instabilityLevel;
        }
        // Layer 8: Prayer generation — population × PRAYER_RATE_PER_POPULATION per second
        // Routed into Divinity via the Faith channel; prayerOutput accumulates as a meter
        let prayerOutput = s.prayerOutput || 0;
        if (s.divinityUnlocked) {
          const prayerGain = prayerRate(s.population || 0) * realDt;
          prayerOutput += prayerGain;
          // Faith channel: each level generates +0.01 Divinity/s per level
          if (prayerBonus.divinityPerSec > 0) {
            const cap = capacities.divinity || Infinity;
            resources.divinity = Math.min(cap, (resources.divinity || 0) + prayerBonus.divinityPerSec * divMaskDivinityMult * realDt);
          }
          // Harmony channel: +5 happiness/s per level
          if (prayerBonus.happinessFlat !== 0) {
            const cap = capacities.happiness || 100;
            resources.happiness = Math.max(0, Math.min(cap, (resources.happiness || 0) + prayerBonus.happinessFlat * realDt));
          }
          // Divine Mask happiness flat (Destroyer -10/s) + Worship polarity happiness (Wonder +10/s)
          const maskPolarHappiness = maskBonus.happinessFlat + polarityBonus.happinessFlat;
          if (maskPolarHappiness !== 0) {
            const cap = capacities.happiness || 100;
            resources.happiness = Math.max(0, Math.min(cap, (resources.happiness || 0) + maskPolarHappiness * realDt));
          }
        }
        // Layer 9: Echo faith Echo generates Divinity per second
        if (echoAgg.divinityPerSec > 0) {
          const cap = capacities.divinity || Infinity;
          resources.divinity = Math.min(cap, (resources.divinity || 0) + echoAgg.divinityPerSec * divMaskDivinityMult * realDt);
        }
        // Layer 9: Echo happiness flat (Stability Echo × count × 10)
        if (echoAgg.happinessFlat !== 0) {
          const cap = capacities.happiness || 100;
          resources.happiness = Math.max(0, Math.min(cap, (resources.happiness || 0) + echoAgg.happinessFlat * realDt));
        }

        // Happiness drift toward 50 baseline if no source
        // (prevents permanent high happiness from start)
        // — disabled: let systems/tech maintain it

        // Population growth with progress bar
        // Growth rate scales with happiness and food/water availability
        let popGrowthRate = 0.015; // base per second
        const happiness = resources.happiness || 50;
        popGrowthRate *= (1 + (happiness - 40) / 200); // happiness 100 → +30%, happiness 20 → -10%
        popGrowthRate *= (1 + archPopMult);
        popGrowthRate *= challengePopMult;
        // Layer 3: Ritual pop growth mult (Fertile Bloom ×2)
        popGrowthRate *= (1 + ritualPopBonus);
        // Layer 4: World config pop growth mult (Ringed Ocean +20%)
        popGrowthRate *= (1 + worldPopGrowthBonus);
        // Layer 5: Divine Law pop growth (Law of Fertility +30%)
        popGrowthRate *= (1 + lawBonus.populationGrowthMult);
        // Layer 5: Worship mode pop growth (Devotion +20%)
        if (worship) popGrowthRate *= (1 + (worship.populationGrowthMult || 0));
        // Layer 6: Relic pop growth (Eternal Flame +50%, Golden Idol −20%)
        popGrowthRate *= (1 + relic.populationGrowthMult);
        // Layer 6: Eternal Flame special — pop growth doubles below threshold
        if (relic.special?.kind === "pop_growth_doubles_below_pop" && (s.population || 0) <= relic.special.threshold) {
          popGrowthRate *= 2;
        }
        // Layer 7: Hybrid Lineage pop growth (Warm-Blooded Hunter +25% × stance, Venomous Warmth +30% × stance)
        popGrowthRate *= (1 + hybridPopBonus);
        // Layer 8: Prayer channel (Growth +10%/level) + Divine Mask (Preserver +20%, Sovereign +10%) + Polarity (Reverence +15%)
        popGrowthRate *= (1 + prayerBonus.populationGrowthMult + maskBonus.populationGrowthMult + polarityBonus.populationGrowthMult);
        // Layer 9: Echo (Growth Echo +10%/count) + Fork (Crossroads B +50%)
        popGrowthRate *= (1 + echoAgg.populationGrowthMult + forkAggPopMult);
        // Layer 10: Testament Clause of Fertility +100% pop growth
        popGrowthRate *= (1 + testamentAgg.populationGrowthMult);
        // Penalty if food/water are critically low (creature+)
        const curStage = STAGES[s.stageIndex];
        if (["creature", "tribal", "civilization", "empire"].includes(curStage.id)) {
          const foodCap = capacities.food || 1;
          const waterCap = capacities.water || 1;
          const foodPct = (resources.food || 0) / foodCap;
          const waterPct = (resources.water || 0) / waterCap;
          if (foodPct < 0.1) popGrowthRate *= 0.3;
          if (waterPct < 0.1) popGrowthRate *= 0.3;
        }

        let populationProgress = (s.populationProgress || 0) + popGrowthRate * realDt;
        let population = s.population;
        while (populationProgress >= 1) {
          populationProgress -= 1;
          population += 1;
        }

        const maxPopulation = Math.max(s.maxPopulation || 0, population);

        const newTime = s.time + realDt;

        // Check story triggers
        const newStory = { ...s.storyUnlocked };
        let activePopup = s.activeStoryPopup;
        const ctx = { ...s, resources, ownedSystems: s.ownedSystems };
        for (const trig of STORY_TRIGGERS) {
          if (!newStory[trig.id] && trig.condition(ctx)) {
            newStory[trig.id] = true;
            if (!activePopup) activePopup = trig.id;
          }
        }

        // Layer 4: Dormant Seed awakening — check if the player has reached
        // the chosen seed's awakening stage and apply one-time effects.
        let awakenedSeedsThisRun = s.awakenedSeedsThisRun;
        let seedTechGrant: string | null = null;
        if (s.worldConfig && !awakenedSeedsThisRun?.[s.worldConfig.dormantSeed]) {
          const seed = DORMANT_SEED_MAP[s.worldConfig.dormantSeed];
          if (seed) {
            const seedStageIdx = STAGE_IDS.indexOf(seed.awakeningStage);
            if (s.stageIndex >= seedStageIdx) {
              awakenedSeedsThisRun = { ...(awakenedSeedsThisRun || {}), [seed.id]: true };
              if (seed.divinityFlat) {
                resources.divinity = (resources.divinity || 0) + seed.divinityFlat;
              }
              if (seed.freeRandomTech) {
                const stageTechs = TECHS.filter(
                  (t) => t.stage === STAGES[s.stageIndex].id && !s.technologies[t.id]
                );
                if (stageTechs.length > 0) {
                  const random = stageTechs[Math.floor(Math.random() * stageTechs.length)];
                  seedTechGrant = random.id;
                  get().addToLog(`Ascension Seed granted free tech: ${random.name}.`);
                }
              }
              get().addToLog(`${seed.name} has awakened.`);
            }
          }
        }

        // Layer 6: Logic Core automation behaviors (auto_evolve, happiness_drift)
        let autoEvolveCoreTrigger = false;
        if (s.activeLogicCores) {
          for (const coreId of Object.keys(s.activeLogicCores)) {
            if (!s.activeLogicCores[coreId]) continue;
            const core = LOGIC_CORE_MAP[coreId];
            if (!core) continue;
            if (core.behavior.kind === "happiness_drift") {
              if ((resources.happiness || 0) < core.behavior.below) {
                const cap = capacities.happiness || 100;
                resources.happiness = Math.min(
                  cap,
                  Math.max(0, (resources.happiness || 0) + core.behavior.perSec * realDt)
                );
                if (resources.happiness > core.behavior.toward) {
                  resources.happiness = core.behavior.toward;
                }
              }
            } else if (core.behavior.kind === "auto_evolve") {
              autoEvolveCoreTrigger = true;
            }
          }
        }

        // Check achievements periodically (every ~2 seconds of game time)
        let achievements = s.achievements;
        let newAchievements = s.newAchievements;
        const checkInterval = 2.0;
        const lastCheck = (s as any)._lastAchCheck || 0;
        if (newTime - lastCheck >= checkInterval) {
          const curState = { ...s, resources, time: newTime } as GameState;
          const result = checkAchievements(curState);
          if (result.newOnes.length > 0) {
            achievements = result.earned;
            newAchievements = [...(newAchievements || []), ...result.newOnes];
          } else if (Object.keys(result.earned).length !== Object.keys(achievements || {}).length) {
            achievements = result.earned;
          }
          (s as any)._lastAchCheck = newTime; // not persisted, just a runtime marker
        }

        // Challenge completion check (every ~5 seconds of game time)
        // completeWhen types: population | stage | stage_clear | stockpile_any
        let activeChallenge = s.activeChallenge;
        let completedChallenges = s.completedChallenges;
        let challengeRepeatCounts = s.challengeRepeatCounts;
        if (activeChallenge && newTime - ((s as any)._lastChallengeCheck || 0) > 5) {
          (s as any)._lastChallengeCheck = newTime;
          const ch = CHALLENGE_MAP[activeChallenge];
          if (ch) {
            const cw = ch.completeWhen;
            let completed = false;
            if (cw.type === "population") {
              completed = population >= (cw.value as number);
            } else if (cw.type === "stage") {
              const targetIdx = STAGE_IDS.indexOf(cw.value as StageId);
              completed = targetIdx >= 0 && s.stageIndex >= targetIdx;
            } else if (cw.type === "stage_clear") {
              // "clear" means the player has cleared that stage at least once (this run or earlier)
              const stageId = cw.value as StageId;
              completed = (s.stageClearCounts?.[stageId] || 0) > 0 || s.stageIndex > STAGE_IDS.indexOf(stageId);
            } else if (cw.type === "stockpile_any") {
              const threshold = cw.value as number;
              completed = Object.values(resources).some((v) => (v || 0) >= threshold);
            }
            if (completed) {
              completedChallenges = { ...(s.completedChallenges || {}), [activeChallenge]: true };
              const newRepeatCounts = { ...(s.challengeRepeatCounts || {}) };
              const currentRepeat = (newRepeatCounts[activeChallenge] || 0) + 1;
              newRepeatCounts[activeChallenge] = currentRepeat;
              challengeRepeatCounts = newRepeatCounts;
              get().addToLog(`Challenge mastered: ${ch.name} (repeat ${currentRepeat}).`);
              activeChallenge = null;
            }
          }
        }

        // Auto-buyer logic (Layer 1 upgrades: auto_system_buyer, auto_tech_buyer, auto_evolver)
        // We compute desired purchases here and apply them via the pending state in set().
        const pendingAutoBuys: { systems: Record<string, number>; techs: string[] } = { systems: {}, techs: [] };
        let autoEvolveTrigger = false;
        const autoSystemLvl = s.upgrades["auto_system_buyer"] || 0;
        const autoTechLvl = s.upgrades["auto_tech_buyer"] || 0;
        const autoEvolverLvl = s.upgrades["auto_evolver"] || 0;
        if (autoSystemLvl > 0 && newTime - ((s as any)._lastAutoBuySystem || 0) > 8) {
          (s as any)._lastAutoBuySystem = newTime;
          // Find cheapest affordable system in the current stage that we don't own yet (or can buy more of)
          const stageId = STAGES[s.stageIndex].id;
          const costReduction = (s.upgrades["frugality"] || 0) * 0.04;
          let best: { sysId: string; totalCost: number } | null = null;
          for (const sys of SYSTEMS) {
            if (sys.stage !== stageId) continue;
            if (sys.requiredTech && !s.technologies[sys.requiredTech]) continue;
            const owned = s.ownedSystems[sys.id] || 0;
            if (sys.maxOwned && owned >= sys.maxOwned) continue;
            const cost = systemCost(sys, owned, costReduction);
            let totalCost = 0;
            let canAfford = true;
            for (const [r, v] of Object.entries(cost)) {
              if ((resources[r] || 0) < (v as number)) { canAfford = false; break; }
              totalCost += (v as number);
            }
            if (canAfford && (!best || totalCost < best.totalCost)) {
              best = { sysId: sys.id, totalCost };
            }
          }
          if (best) {
            pendingAutoBuys.systems[best.sysId] = (pendingAutoBuys.systems[best.sysId] || 0) + 1;
            // Deduct cost immediately so subsequent calculations in the same tick are consistent
            const sys = SYSTEM_MAP[best.sysId];
            const owned = s.ownedSystems[best.sysId] || 0;
            const cost = systemCost(sys, owned, costReduction);
            for (const [r, v] of Object.entries(cost)) {
              resources[r] = (resources[r] || 0) - (v as number);
            }
          }
        }
        if (autoTechLvl > 0 && newTime - ((s as any)._lastAutoBuyTech || 0) > 12) {
          (s as any)._lastAutoBuyTech = newTime;
          // Find cheapest affordable tech in the current stage that's not yet researched
          const stageId = STAGES[s.stageIndex].id;
          let best: { techId: string; totalCost: number } | null = null;
          for (const tech of TECHS) {
            if (tech.stage !== stageId) continue;
            if (s.technologies[tech.id]) continue;
            // Respect mutually-exclusive tech locks — both player-set and
            // implicit (any of the exclusiveWith partners already researched).
            if (s.lockedTechs && s.lockedTechs[tech.id]) continue;
            if (tech.exclusiveWith && tech.exclusiveWith.some((ex) => s.technologies[ex])) continue;
            if (tech.requires) {
              let reqMet = true;
              for (const req of tech.requires) {
                if (!s.technologies[req]) { reqMet = false; break; }
              }
              if (!reqMet) continue;
            }
            let totalCost = 0;
            let canAfford = true;
            for (const [r, v] of Object.entries(tech.cost)) {
              if ((resources[r] || 0) < (v as number)) { canAfford = false; break; }
              totalCost += (v as number);
            }
            if (canAfford && (!best || totalCost < best.totalCost)) {
              best = { techId: tech.id, totalCost };
            }
          }
          if (best) {
            pendingAutoBuys.techs.push(best.techId);
            const tech = TECH_MAP[best.techId];
            for (const [r, v] of Object.entries(tech.cost)) {
              resources[r] = (resources[r] || 0) - (v as number);
            }
          }
        }
        // Auto-Evolver: trigger evolve if requirements are met at threshold (100% + level*20%)
        if (autoEvolverLvl > 0) {
          const stage = STAGES[s.stageIndex];
          const next = nextStage(stage.id);
          if (next) {
            const reqs = stage.evolveRequires;
            const evolveBoost = 1 - Math.min(0.30, (s.upgrades["evolutionary_momentum"] || 0) * 0.05);
            const threshold = 1 + autoEvolverLvl * 0.20;
            const totalSystems = Object.values(s.ownedSystems).reduce((a, b) => a + b, 0);
            const totalTech = Object.keys(s.technologies).length;
            const score = computeScore(s);
            if (
              s.population >= reqs.minPopulation * evolveBoost * threshold &&
              totalSystems >= reqs.minSystems * evolveBoost * threshold &&
              totalTech >= reqs.minTech * evolveBoost * threshold
            ) {
              autoEvolveTrigger = true;
            }
          }
        }

        // Apply pending auto-buys to owned systems / technologies
        let ownedSystems = s.ownedSystems;
        let systemEnabled = s.systemEnabled;
        let technologies = s.technologies;
        let lockedTechs = s.lockedTechs;
        let archetypeAffinity = s.archetypeAffinity;
        let totalSystemsBuilt = s.totalSystemsBuilt || 0;
        let totalTechResearched = s.totalTechResearched || 0;
        // Merge Layer 4 dormant-seed tech grant before auto-buyer mutations
        if (seedTechGrant) {
          technologies = { ...s.technologies, [seedTechGrant]: true };
          totalTechResearched += 1;
        }
        if (Object.keys(pendingAutoBuys.systems).length > 0) {
          ownedSystems = { ...s.ownedSystems };
          systemEnabled = { ...s.systemEnabled };
          archetypeAffinity = { ...s.archetypeAffinity };
          for (const [sysId, count] of Object.entries(pendingAutoBuys.systems)) {
            const sys = SYSTEM_MAP[sysId];
            ownedSystems[sysId] = (ownedSystems[sysId] || 0) + count;
            if (systemEnabled[sysId] === undefined) systemEnabled[sysId] = true;
            if (sys.grantsAffinity) {
              archetypeAffinity[sys.grantsAffinity.archetype] =
                (archetypeAffinity[sys.grantsAffinity.archetype] || 0) + sys.grantsAffinity.amount * count;
            }
            totalSystemsBuilt += count;
            get().addToLog(`Auto-Builder purchased ${count}× ${sys.name}.`);
          }
        }
        if (pendingAutoBuys.techs.length > 0) {
          technologies = { ...s.technologies };
          archetypeAffinity = archetypeAffinity === s.archetypeAffinity ? { ...s.archetypeAffinity } : archetypeAffinity;
          for (const techId of pendingAutoBuys.techs) {
            technologies[techId] = true;
            const tech = TECH_MAP[techId];
            if (tech.grantsAffinity) {
              archetypeAffinity[tech.grantsAffinity.archetype] =
                (archetypeAffinity[tech.grantsAffinity.archetype] || 0) + tech.grantsAffinity.amount;
            }
            // Apply exclusiveWith lock when the auto-buyer picks an exclusive tech
            if (tech.exclusiveWith && tech.exclusiveWith.length > 0) {
              if (lockedTechs === s.lockedTechs) lockedTechs = { ...(s.lockedTechs || {}) };
              for (const ex of tech.exclusiveWith) {
                (lockedTechs as Record<string, boolean>)[ex] = true;
              }
            }
            totalTechResearched += 1;
            get().addToLog(`Auto-Researcher researched ${tech.name}.`);
          }
        }

        // Random event firing — only if no popup/modal is active
        let activeEvent = s.activeEvent;
        let eventCooldown = (s.eventCooldown || 0) - realDt;
        if (eventCooldown < 0) eventCooldown = 0;
        const eventFreq = s.eventFrequency || "normal";
        if (eventFreq !== "off" && !activeEvent && !activePopup && eventCooldown === 0) {
          const stageId = STAGES[s.stageIndex].id;
          const possible = eventsForStage(stageId, newTime);
          if (possible.length > 0) {
            // Weighted random selection
            const totalWeight = possible.reduce((sum, e) => sum + e.weight, 0);
            const roll = Math.random() * totalWeight;
            let cum = 0;
            for (const ev of possible) {
              cum += ev.weight;
              if (roll < cum) {
                activeEvent = ev.id;
                // Cooldown depends on frequency setting AND stage depth.
                // Early stages (Cell, Creature) get more events to keep the
                // opening engaging; later stages use the longer default.
                //   normal:   early 45-90s  · later 90-180s
                //   frequent: early 25-50s  · later 30-60s
                const isEarlyStage = stageId === "cell" || stageId === "creature";
                const base = eventFreq === "frequent"
                  ? (isEarlyStage ? 25 : 30)
                  : (isEarlyStage ? 45 : 90);
                const range = eventFreq === "frequent"
                  ? (isEarlyStage ? 25 : 30)
                  : (isEarlyStage ? 45 : 90);
                eventCooldown = base + Math.random() * range;
                break;
              }
            }
          }
        }

        set({
          resources,
          capacities,
          time: newTime,
          population,
          maxPopulation,
          populationProgress,
          storyUnlocked: newStory,
          activeStoryPopup: activePopup,
          achievements,
          newAchievements,
          activeEvent,
          eventCooldown,
          activeChallenge,
          completedChallenges,
          challengeRepeatCounts,
          ownedSystems,
          systemEnabled,
          technologies,
          lockedTechs,
          archetypeAffinity,
          totalSystemsBuilt,
          totalTechResearched,
          activeRituals,
          awakenedSeedsThisRun,
          heresyLevel,
          divinity: resources.divinity,
          totalPlayTime: (s.totalPlayTime || 0) + realDt,
          instabilityLevel,
          peakInstability,
          prayerOutput,
          activeDebt,
        });

        // Auto-Evolver: trigger evolve after state is committed
        if (autoEvolveTrigger || autoEvolveCoreTrigger) {
          get().evolveStage();
        }
      },

      // ============ ACTIONS ============
      performAction: (actionId) => {
        const s = get();
        const action = ACTION_MAP[actionId];
        if (!action) return;
        if (action.stage !== STAGES[s.stageIndex].id) return;

        const res = { ...s.resources };

        // Check if all output resources are at cap — if so, block (no waste)
        const outputs = Object.entries(action.produces);
        if (outputs.length > 0) {
          const allCapped = outputs.every(([r]) => {
            const cap = s.capacities[r] || 0;
            return (res[r] || 0) >= cap - 0.001;
          });
          if (allCapped) return; // action wasted — block it
        }

        // Check costs
        if (action.cost) {
          for (const [r, v] of Object.entries(action.cost)) {
            if ((res[r] || 0) < (v as number)) return;
          }
          for (const [r, v] of Object.entries(action.cost)) {
            res[r] -= v as number;
          }
        }

        // Manual action multiplier
        const manualLvl = s.upgrades["quickened_hands"] || 0;
        const mult = 1 + manualLvl * 0.25;
        const techMult = techMultiplier(s, "manual");
        const finalMult = mult * techMult;

        // Archetype per-resource bonus
        const archetype = s.lockedArchetype ? ARCHETYPE_MAP[s.lockedArchetype] : null;

        for (const [r, v] of Object.entries(action.produces)) {
          const cap = s.capacities[r] || 0;
          const archResBonus = archetype?.bonus.productionMult?.[r] || 0;
          const totalArchMult = 1 + archResBonus + (archetype?.bonus.allProductionMult || 0);
          const amount = (v as number) * finalMult * totalArchMult;
          res[r] = Math.min(cap, (res[r] || 0) + amount);
        }

        set({
          resources: res,
          totalActions: (s.totalActions || 0) + 1,
        });
      },

      buySystem: (systemId, qty) => {
        const s = get();
        const sys = SYSTEM_MAP[systemId];
        if (!sys) return;
        if (sys.stage !== STAGES[s.stageIndex].id) return;
        // Check tech prerequisite
        if (sys.requiredTech && !s.technologies[sys.requiredTech]) return;

        const costReduction = (s.upgrades["frugality"] || 0) * 0.04;
        let owned = s.ownedSystems[systemId] || 0;
        if (sys.maxOwned && owned >= sys.maxOwned) return;

        const res = { ...s.resources };
        const ownedSystems = { ...s.ownedSystems };
        const systemEnabled = { ...s.systemEnabled };
        const archetypeAffinity = { ...s.archetypeAffinity };

        let bought = 0;
        for (let i = 0; i < qty; i++) {
          if (sys.maxOwned && owned + bought >= sys.maxOwned) break;
          const cost = systemCost(sys, owned + bought, costReduction);
          let canAfford = true;
          for (const [r, v] of Object.entries(cost)) {
            if ((res[r] || 0) < (v as number)) {
              canAfford = false;
              break;
            }
          }
          if (!canAfford) break;
          for (const [r, v] of Object.entries(cost)) {
            res[r] -= v as number;
          }
          bought++;
        }

        if (bought === 0) return;

        ownedSystems[systemId] = owned + bought;
        // New systems are enabled by default
        if (systemEnabled[systemId] === undefined) systemEnabled[systemId] = true;

        // Apply archetype affinity grant
        if (sys.grantsAffinity) {
          const arch = sys.grantsAffinity.archetype;
          archetypeAffinity[arch] = (archetypeAffinity[arch] || 0) + sys.grantsAffinity.amount * bought;
        }

        // Trigger story
        const newStory = { ...s.storyUnlocked };
        let activePopup = s.activeStoryPopup;
        for (const trig of STORY_TRIGGERS) {
          if (!newStory[trig.id] && trig.condition({ ...s, resources: res, ownedSystems })) {
            newStory[trig.id] = true;
            if (!activePopup) activePopup = trig.id;
          }
        }

        set({
          resources: res,
          ownedSystems,
          systemEnabled,
          archetypeAffinity,
          storyUnlocked: newStory,
          activeStoryPopup: activePopup,
          totalSystemsBuilt: (s.totalSystemsBuilt || 0) + bought,
        });
        get().addToLog(`Built ${bought}× ${sys.name}.`);
      },

      toggleSystem: (systemId) => {
        const s = get();
        if (!s.ownedSystems[systemId]) return;
        const systemEnabled = { ...s.systemEnabled };
        systemEnabled[systemId] = systemEnabled[systemId] === false ? true : false;
        set({ systemEnabled });
      },

      enableAllSystems: (enabled) => {
        const s = get();
        const systemEnabled: Record<string, boolean> = {};
        for (const id of Object.keys(s.ownedSystems)) {
          systemEnabled[id] = enabled;
        }
        set({ systemEnabled });
      },

      buyTech: (techId) => {
        const s = get();
        const tech = TECH_MAP[techId];
        if (!tech) return;
        if (s.technologies[techId]) return;
        if (s.lockedTechs && s.lockedTechs[techId]) return;
        if (tech.stage !== STAGES[s.stageIndex].id) return;
        if (tech.requires) {
          for (const req of tech.requires) {
            if (!s.technologies[req]) return;
          }
        }
        // Exclusive path check — if any mutually-exclusive tech is already
        // researched, block the purchase. (The "lock the others on buy"
        // step below ensures this also fires for the second pick.)
        if (tech.exclusiveWith) {
          for (const ex of tech.exclusiveWith) {
            if (s.technologies[ex]) {
              get().addToLog(
                `Cannot research ${tech.name} — exclusive path already chosen (${TECH_MAP[ex]?.name || ex}).`
              );
              return;
            }
          }
        }
        const res = { ...s.resources };
        for (const [r, v] of Object.entries(tech.cost)) {
          if ((res[r] || 0) < (v as number)) return;
        }
        for (const [r, v] of Object.entries(tech.cost)) {
          res[r] -= v as number;
        }
        const technologies = { ...s.technologies, [techId]: true };
        const archetypeAffinity = { ...s.archetypeAffinity };
        if (tech.grantsAffinity) {
          archetypeAffinity[tech.grantsAffinity.archetype] =
            (archetypeAffinity[tech.grantsAffinity.archetype] || 0) + tech.grantsAffinity.amount;
        }
        // Lock mutually-exclusive techs after purchase — this makes the
        // choice permanent for the rest of the run.
        const lockedTechs = { ...(s.lockedTechs || {}) };
        if (tech.exclusiveWith) {
          for (const ex of tech.exclusiveWith) {
            lockedTechs[ex] = true;
          }
        }
        set({
          resources: res,
          technologies,
          lockedTechs,
          archetypeAffinity,
          totalTechResearched: (s.totalTechResearched || 0) + 1,
        });
        get().addToLog(`Researched ${tech.name}.`);
        if (tech.exclusiveWith && tech.exclusiveWith.length > 0) {
          const names = tech.exclusiveWith
            .map((id) => TECH_MAP[id]?.name || id)
            .join(", ");
          get().addToLog(`Locked exclusive paths: ${names}.`);
        }
      },

      buyUpgrade: (upgradeId) => {
        const s = get();
        const up = UPGRADE_MAP[upgradeId];
        if (!up) return;
        if (up.requiresWins && s.galacticWins < up.requiresWins) return;
        const owned = s.upgrades[upgradeId] || 0;
        if (owned >= up.maxLevel) return;
        const cost = upgradeCost(up, owned);
        if (s.evolutionPoints < cost) return;
        const upgrades = { ...s.upgrades, [upgradeId]: owned + 1 };
        set({
          evolutionPoints: s.evolutionPoints - cost,
          upgrades,
        });
        get().addToLog(`Purchased ${up.name} (Lv ${owned + 1}).`);
      },

      evolveStage: () => {
        const s = get();
        const stage = STAGES[s.stageIndex];
        const next = nextStage(stage.id);
        if (!next) {
          get().triggerPrestige();
          return;
        }
        const reqs = stage.evolveRequires;
        const evolveBoost = 1 - Math.min(0.30, (s.upgrades["evolutionary_momentum"] || 0) * 0.05);
        const totalSystems = Object.values(s.ownedSystems).reduce((a, b) => a + b, 0);
        const totalTech = Object.keys(s.technologies).length;
        const score = computeScore(s);

        // Layer 3: Break Through ritual — skip requirement check
        // when one or more evolve-skip buffs are queued. Consume one buff per evolve.
        const hasEvolveSkip = (s.evolveSkipBuffs || 0) > 0;
        if (!hasEvolveSkip) {
          if (s.population < reqs.minPopulation * evolveBoost) return;
          if (totalSystems < reqs.minSystems * evolveBoost) return;
          if (totalTech < reqs.minTech * evolveBoost) return;
        }
        // Score is NOT a requirement — it only affects EP earned at prestige

        const nextStageIdx = s.stageIndex + 1;
        const nextStageDef = STAGES[nextStageIdx];

        const resources = { ...s.resources };
        const capBoostLvl = s.upgrades["expansive_vaults"] || 0;
        const capMult = 1 + capBoostLvl * 0.20;
        const archetype = s.lockedArchetype ? ARCHETYPE_MAP[s.lockedArchetype] : null;
        const archCapMult = archetype?.bonus.capMult || 0;
        const capacities = recomputeCapacitiesFresh(s, capMult + archCapMult);

        const newStory = { ...s.storyUnlocked };
        const storyId = STORY_MAP[
          nextStageDef.id === "creature" ? "first_body_stirs"
          : nextStageDef.id === "tribal" ? "fire_remembered"
          : nextStageDef.id === "civilization" ? "cities_learn_to_dream"
          : nextStageDef.id === "empire" ? "distance_begins_to_obey"
          : nextStageDef.id === "solar" ? "sky_stops_being_a_wall"
          : "galaxy_takes_a_shape"
        ];
        if (storyId) newStory[storyId.id] = true;

        // Lock archetype when evolving from Creature → Tribal
        let lockedArchetype = s.lockedArchetype;
        if (stage.id === "creature" && !lockedArchetype) {
          const dom = dominantArchetype(s.archetypeAffinity);
          if (dom) {
            lockedArchetype = dom;
            get().addToLog(`Lineage locked: ${ARCHETYPE_MAP[dom].name}.`);
          } else {
            lockedArchetype = "humanoid"; // default fallback
            get().addToLog(`Lineage locked: Humanoid (no drift).`);
          }
        }

        const stageClearCounts = { ...s.stageClearCounts, [stage.id]: (s.stageClearCounts[stage.id] || 0) + 1 };

        // Track fastest Cell clear
        let fastestCellClear = s.fastestCellClear || 0;
        if (stage.id === "cell") {
          const clearTime = s.time;
          if (fastestCellClear === 0 || clearTime < fastestCellClear) {
            fastestCellClear = clearTime;
          }
        }

        // Check achievements after stage clear
        const postEvolveState = { ...s, stageClearCounts, lockedArchetype, fastestCellClear } as GameState;
        const achResult = checkAchievements(postEvolveState);
        const newAchievements = achResult.newOnes.length > 0
          ? [...(s.newAchievements || []), ...achResult.newOnes]
          : s.newAchievements;

        set({
          stageIndex: nextStageIdx,
          resources,
          capacities,
          storyUnlocked: newStory,
          activeStoryPopup: storyId?.id || s.activeStoryPopup,
          stageClearCounts,
          fastestCellClear,
          lockedArchetype,
          achievements: achResult.earned,
          newAchievements,
          evolveSkipBuffs: Math.max(0, (s.evolveSkipBuffs || 0) - (hasEvolveSkip ? 1 : 0)),
        });
        get().addToLog(`Evolved to ${nextStageDef.name}. ${nextStageDef.tagline}`);
      },

      triggerPrestige: () => {
        const s = get();
        const stage = STAGES[s.stageIndex];
        const score = computeScore(s);
        const stageMult = [1, 2, 4, 8, 16, 32, 64][s.stageIndex] || 1;
        // Cosmic Understanding: +25% EP earned per level
        const epMultLvl = s.upgrades["cosmic_understanding"] || 0;
        const epMult = 1 + epMultLvl * 0.25;
        // Layer 4: World config EP multiplier (Void Basin +25%, Difficulty tier ×0.7..×2.5)
        const worldEpMult = s.worldConfig ? worldEpMultiplier(s.worldConfig) : 1;
        const epEarned = Math.max(1, Math.floor(Math.sqrt(score / 100) * stageMult * epMult * worldEpMult));

        const archive = [...s.archive];
        const archName = s.lockedArchetype ? ARCHETYPE_MAP[s.lockedArchetype]?.name : "Humanoid";
        archive.unshift({
          runId: `run_${s.totalRuns + 1}`,
          timestamp: Date.now(),
          stage: stage.id,
          archetype: s.lockedArchetype || "humanoid",
          score,
          epEarned,
          duration: s.time,
          ending: s.stageIndex >= 6 ? "Galactic Ascension" : `${stage.name} Evolution (${archName})`,
        });

        const archivedArchetypes = Array.from(new Set([
          ...(s.archivedArchetypes || []),
          ...(s.lockedArchetype ? [s.lockedArchetype] : []),
        ]));

        // Layer 4: track Cradle World wins — increment if a world config was authored this run.
        const cradleWorldWins = { ...(s.cradleWorldWins || {}) };
        if (s.worldConfig && !cradleWorldWins[s.worldConfig.cradleWorld]) {
          cradleWorldWins[s.worldConfig.cradleWorld] = true;
        }

        const fresh = initialRunState();

        // Layer 4: apply authored WorldConfig starting bonuses to the fresh run.
        if (s.worldConfig && fresh.resources) {
          const cfg = s.worldConfig;
          // Start-resource bonuses (cradle + prime)
          const startRes = worldStartResourceBonus(cfg);
          for (const [r, amt] of Object.entries(startRes)) {
            fresh.resources[r] = (fresh.resources[r] || 0) + (amt as number);
          }
          // Population bonus (Stable Geology +10)
          const popBonus = worldStartPopulationBonus(cfg);
          if (popBonus > 0 && fresh.population != null) {
            fresh.population = (fresh.population || 0) + popBonus;
            fresh.maxPopulation = Math.max(fresh.maxPopulation || 0, fresh.population);
          }
          // Starting tech (Abundant Minerals → mining)
          const startTech = worldStartTech(cfg);
          if (startTech && fresh.technologies) {
            fresh.technologies = { ...(fresh.technologies || {}), [startTech]: true };
          }
        }

        // Apply starting bonuses to fresh run state (Layer 1 upgrades)
        // - Warm Start: +5 per level to atp, glucose, proteins, lipids
        // - Frontier Spirit: +10 per level to starting population
        // - Ancestral Bounty: +10 per level to every primary resource
        const warmStartLvl = s.upgrades["warm_start"] || 0;
        const frontierLvl = s.upgrades["frontier_spirit"] || 0;
        const ancestralLvl = s.upgrades["ancestral_bounty"] || 0;
        if (warmStartLvl > 0 && fresh.resources) {
          const bonus = warmStartLvl * 5;
          fresh.resources.atp = (fresh.resources.atp || 0) + bonus;
          fresh.resources.glucose = (fresh.resources.glucose || 0) + bonus;
          fresh.resources.proteins = (fresh.resources.proteins || 0) + bonus;
          fresh.resources.lipids = (fresh.resources.lipids || 0) + bonus;
        }
        if (frontierLvl > 0) {
          const popBonus = frontierLvl * 10;
          fresh.population = (fresh.population || 0) + popBonus;
          fresh.maxPopulation = Math.max(fresh.maxPopulation || 0, fresh.population);
        }
        if (ancestralLvl > 0 && fresh.resources) {
          const resBonus = ancestralLvl * 10;
          for (const r of ALL_RESOURCES) {
            if (r.category === "primary") {
              fresh.resources[r.id] = (fresh.resources[r.id] || 0) + resBonus;
            }
          }
        }
        // Challenge: Trial of the Late Bloom — apply -50% starting pop debuff
        // (only if a challenge is currently active and has starting_pop mult effect)
        if (s.activeChallenge) {
          const ch = CHALLENGE_MAP[s.activeChallenge];
          if (ch) {
            const currentRepeat = (s.challengeRepeatCounts || {})[s.activeChallenge] || 0;
            const nextRepeat = currentRepeat + 1;
            const scaledDebuff = getChallengeDebuffAtRepeat(s.activeChallenge, nextRepeat);
            for (const e of scaledDebuff.effects) {
              if (e.mode === "mult" && e.target === "starting_pop" && fresh.population != null) {
                fresh.population = Math.max(1, Math.floor(fresh.population * (1 + e.value)));
                fresh.maxPopulation = Math.max(fresh.maxPopulation || 0, fresh.population);
              } else if (e.mode === "flat" && e.target === "starting_pop" && fresh.population != null) {
                fresh.population = Math.max(1, fresh.population + e.value);
                fresh.maxPopulation = Math.max(fresh.maxPopulation || 0, fresh.population);
              }
            }
          }
        }
        // Challenge mastery: +15 starting pop from Trial of Growth mastery (flat)
        // Apply via challengeMasteryBonusFromRepeats for repeat-aware stacking
        if (fresh.population != null) {
          const startPopFlat = challengeMasteryBonusFromRepeats(s.challengeRepeatCounts || {}, "starting_pop");
          if (startPopFlat > 0) {
            fresh.population = fresh.population + startPopFlat;
            fresh.maxPopulation = Math.max(fresh.maxPopulation || 0, fresh.population);
          }
        }

        // Determine if challenges should unlock (first Galactic win)
        const newGalacticWins = s.galacticWins + (s.stageIndex >= 6 ? 1 : 0);
        const unlockedChallenges = s.unlockedChallenges || newGalacticWins >= 1;

        // ===== Layer 2-6 unlock chain =====
        // Layer 2 unlocks when 3 unique challenges are completed (already in initialMetaState via completedChallenges)
        const foresightCount = Object.keys(s.foresightNodes || {}).filter((k) => s.foresightNodes![k]).length;
        const enlightenmentUnlocked = s.enlightenmentUnlocked ||
          Object.keys(s.completedChallenges || {}).filter((k) => s.completedChallenges![k]).length >= 3;
        // Layer 3 unlocks when 10 foresight nodes are purchased
        const transcendenceUnlocked = s.transcendenceUnlocked || foresightCount >= ADVANCE_NODE_COUNT;
        // Layer 3 mastery: at least one ritual category used (any ritual performed) + all 5 scripts tried + blood pact used
        const ritualCategories = new Set<string>();
        for (const r of RITUALS) {
          if (s.ritualUsesThisRun?.[r.id]) ritualCategories.add(r.id);
        }
        const scriptsTriedCount = Object.keys(s.scriptsTriedAllTime || {}).filter((k) => s.scriptsTriedAllTime![k]).length;
        const transcendenceMastered = s.bloodPactUsedAllTime &&
          Object.keys(s.ritualsUsedAllTime || {}).length >= RITUALS.length &&
          scriptsTriedCount >= SCRIPTS.length;
        // Layer 4 unlocks when Transcendence mastery is complete
        const genesisUnlocked = s.genesisUnlocked || transcendenceMastered;
        // Layer 4 mastery: all cradle worlds won + all seeds awakened (across all runs)
        const cradleWorldsWonCount = CRADLE_WORLDS.filter((c) => cradleWorldWins[c.id]).length;
        const seedsAwakenedCount = DORMANT_SEEDS.filter((seed) => s.awakenedSeedsAllTime?.[seed.id]).length;
        const genesisMastered = cradleWorldsWonCount >= CRADLE_WORLDS.length &&
          seedsAwakenedCount >= DORMANT_SEEDS.length;
        // Layer 5 unlocks when Genesis mastery is complete
        const apotheosisUnlocked = s.apotheosisUnlocked || genesisMastered;
        // Layer 5 mastery: 3+ divine laws + all worship modes tried + all miracles used + heresy survived
        const lawsCodifiedAllTimeCount = Object.keys(s.divineLawsEnactedAllTime || {}).length;
        const worshipModesTriedCount = Object.keys(s.worshipModesUsedAllTime || {}).filter((k) => s.worshipModesUsedAllTime![k]).length;
        const miracleUsesAllTimeCount = Object.keys(s.miracleUsesAllTime || {}).length;
        const apotheosisMastered = lawsCodifiedAllTimeCount >= APOTHEOSIS_COMPLETION_LAWS_REQUIRED &&
          worshipModesTriedCount >= WORSHIP_MODES.length &&
          miracleUsesAllTimeCount >= MIRACLES.length &&
          !!s.heresySurvivedAllTime;
        // Layer 6 unlocks when Apotheosis mastery is complete
        const singularityUnlocked = s.singularityUnlocked || apotheosisMastered;
        // Layer 6 mastery: per the L6-data worklog, the Compression family is
        // deferred — but we treat Singularity as "mastered" once a relic loadout
        // has been bound AND 3+ logic cores enabled, so the player can advance.
        const relicBoundNow = !!s.activeRelicLoadout;
        const installedCores = Object.values(s.activeLogicCores || {}).filter(Boolean).length;
        const singularityMastered = s.singularityUnlocked &&
          (s.relicsBoundAllTime ? Object.keys(s.relicsBoundAllTime).length >= 1 : false) &&
          installedCores >= MAX_INSTALLED_LOGIC_CORES;
        void relicBoundNow;

        // ===== Layer 7-10 unlock chain =====
        // Layer 7 (Omnipotence) unlocks when Layer 6 (Singularity) is complete.
        const omnipotenceUnlocked = s.omnipotenceUnlocked || singularityMastered;
        // Layer 7 mastery: survive an Instability peak (peak ≥ 80, did not overflow)
        const omnipotenceMastered = s.omnipotenceUnlocked &&
          isOmnipotenceComplete(s.peakInstability || 0);
        // Layer 8 (Divinity) unlocks when Layer 7 is complete.
        const divinityUnlocked = s.divinityUnlocked || omnipotenceMastered;
        // Layer 8 mastery: 3+ prayer channels opened + worship polarity aligned
        const openedChannels = PRAYER_CHANNELS.filter((c) => (s.prayerChannels?.[c.id] || 0) >= 1).length;
        const divinityMastered = s.divinityUnlocked &&
          openedChannels >= DIVINITY_COMPLETION_CHANNELS_REQUIRED &&
          !!s.activeWorshipPolarity;
        // Layer 9 (Infinity) unlocks when Layer 8 is complete.
        const infinityUnlocked = s.infinityUnlocked || divinityMastered;
        // Layer 9 mastery: at least 1 fork resolved + a future debt fully repaid
        const resolvedForks = FORK_SCENARIOS.filter((f) => {
          const b = (s.forksResolved || {})[f.id];
          return b === "A" || b === "B";
        }).length;
        // Debt is considered repaid this run if activeDebt had at least one entry
        // whose penalty phase ended without resetting (we approximate by checking
        // futureDebtRepaidAllTime).
        const infinityMastered = s.infinityUnlocked &&
          resolvedForks >= 1 &&
          !!s.futureDebtRepaidAllTime;
        void resolvedForks;
        // Layer 10 (Eternity) unlocks when Layer 9 is complete.
        const eternityUnlocked = s.eternityUnlocked || infinityMastered;
        // Layer 10 completion: an Ending has been chosen this run
        const endingChosenThisRun = s.endingChosen;
        const eternityMastered = s.eternityUnlocked &&
          isEternityComplete(endingChosenThisRun);
        void eternityMastered;

        // Track that the current run survived heresy (if apotheosis was active)
        const heresySurvivedAllTime = s.heresySurvivedAllTime ||
          (s.apotheosisUnlocked && (s.heresyLevel || 0) > 0 && (s.heresyLevel || 0) < HERESY_MAX);

        const metaState: Partial<GameState> = {
          evolutionPoints: s.evolutionPoints + epEarned,
          totalRuns: s.totalRuns + 1,
          galacticWins: newGalacticWins,
          archive,
          archivedArchetypes,
          upgrades: s.upgrades,
          storyUnlocked: { ...s.storyUnlocked, god_opens_its_eyes: true },
          storyAcknowledged: s.storyAcknowledged,
          unlockedLayers: s.unlockedLayers,
          stageClearCounts: s.stageClearCounts,
          fastestCellClear: s.fastestCellClear,
          totalEventsResolved: s.totalEventsResolved,
          totalPlayTime: s.totalPlayTime,
          totalActions: s.totalActions,
          totalSystemsBuilt: s.totalSystemsBuilt,
          totalTechResearched: s.totalTechResearched,
          achievements: s.achievements,
          newAchievements: s.newAchievements,
          // Layer 1: Evolution — challenge state preserved across prestige
          unlockedChallenges,
          completedChallenges: s.completedChallenges || {},
          challengeRepeatCounts: s.challengeRepeatCounts || {},
          activeChallenge: null, // challenges reset their debuff on prestige (fresh run)
          // Layer 2: Enlightenment — foresight nodes persist across runs (cumulative). Route is per-run.
          enlightenmentUnlocked,
          divinity: 0, // currency resets each run
          selectedRoute: null,
          foresightNodes: s.foresightNodes || {},
          // Layer 3: Transcendence — per-run state resets, all-time state persists
          transcendenceUnlocked,
          offeringsUsedThisRun: {},
          ritualUsesThisRun: {},
          ritualsUsedAllTime: { ...(s.ritualsUsedAllTime || {}) },
          bloodPactUsesThisRun: {},
          bloodPactUsedAllTime: s.bloodPactUsedAllTime,
          activeScripts: {},
          scriptsTriedAllTime: { ...(s.scriptsTriedAllTime || {}) },
          activeRituals: [],
          evolveSkipBuffs: 0,
          // Layer 4: Genesis — worldConfig resets (must re-author), cradleWorldWins persists
          genesisUnlocked,
          worldConfig: null,
          cradleWorldWins,
          awakenedSeedsThisRun: {},
          awakenedSeedsAllTime: {
            ...(s.awakenedSeedsAllTime || {}),
            ...(s.awakenedSeedsThisRun || {}),
          },
          // Layer 5: Apotheosis — per-run state resets, all-time state persists
          apotheosisUnlocked,
          divineLawsEnactedThisRun: {},
          divineLawsEnactedAllTime: { ...(s.divineLawsEnactedAllTime || {}) },
          worshipMode: null,
          worshipModesUsedAllTime: { ...(s.worshipModesUsedAllTime || {}) },
          miracleUsesThisRun: {},
          miracleUsesAllTime: { ...(s.miracleUsesAllTime || {}) },
          heresyLevel: 0,
          heresyResponseUsesThisRun: {},
          heresySurvivedAllTime,
          // Layer 6: Singularity — relic + cores reset, all-time persists
          singularityUnlocked,
          activeRelicLoadout: null,
          relicsBoundAllTime: {
            ...(s.relicsBoundAllTime || {}),
            ...(s.activeRelicLoadout ? { [s.activeRelicLoadout]: true } : {}),
          },
          activeLogicCores: {},
          logicCoresEnabledAllTime: {
            ...(s.logicCoresEnabledAllTime || {}),
            ...Object.fromEntries(
              Object.keys(s.activeLogicCores || {})
                .filter((k) => s.activeLogicCores![k])
                .map((k) => [k, true])
            ),
          },
          // Layer 7: Omnipotence — per-run state resets, all-time persists
          omnipotenceUnlocked,
          activeHybridLineage: null,
          hybridLineagesTriedAllTime: {
            ...(s.hybridLineagesTriedAllTime || {}),
            ...(s.activeHybridLineage ? { [s.activeHybridLineage]: true } : {}),
          },
          activeStance: "balanced",
          stancesTriedAllTime: { ...(s.stancesTriedAllTime || {}) },
          instabilityLevel: 0,
          peakInstability: 0,
          // Layer 8: Divinity — per-run state resets, all-time persists
          divinityUnlocked,
          prayerChannels: {},
          prayerOutput: 0,
          activeDivineMask: null,
          divineMasksTriedAllTime: { ...(s.divineMasksTriedAllTime || {}) },
          activeWorshipPolarity: null,
          worshipPolaritiesTriedAllTime: { ...(s.worshipPolaritiesTriedAllTime || {}) },
          // Layer 9: Infinity — per-run state resets, all-time persists
          infinityUnlocked,
          echoes: 0,
          echoesOwned: { ...(s.echoesOwned || {}) }, // echoes persist across runs (per data file spec)
          forksResolved: {},
          forksResolvedAllTime: { ...(s.forksResolvedAllTime || {}) },
          futureDebtUsesThisRun: {},
          futureDebtRepaidAllTime: s.futureDebtRepaidAllTime,
          activeDebt: [],
          // Layer 10: Eternity — Testament currency/clauses/weaves persist;
          //          endingChosen resets; cosmicBoonStacks persists.
          eternityUnlocked,
          testamentClauses: s.testamentClauses || 0,
          testamentClausesOwned: { ...(s.testamentClausesOwned || {}) },
          canonizationsOwned: { ...(s.canonizationsOwned || {}) },
          permanenceWeavesOwned: { ...(s.permanenceWeavesOwned || {}) },
          endingChosen: null,
          cosmicBoonStacks: s.cosmicBoonStacks || 0,
        };

        // Trigger unlock story popups for newly-unlocked layers
        let activeStoryPopup: string | null = null;
        const newStory = { ...(s.storyUnlocked || {}) };
        if (enlightenmentUnlocked && !s.enlightenmentUnlocked) {
          newStory.enlightenment_unlocked = true;
          activeStoryPopup = "enlightenment_unlocked";
        }
        if (transcendenceUnlocked && !s.transcendenceUnlocked) {
          newStory.transcendence_unlocked = true;
          if (!activeStoryPopup) activeStoryPopup = "transcendence_unlocked";
        }
        if (genesisUnlocked && !s.genesisUnlocked) {
          newStory.genesis_unlocked = true;
          if (!activeStoryPopup) activeStoryPopup = "genesis_unlocked";
        }
        if (apotheosisUnlocked && !s.apotheosisUnlocked) {
          newStory.apotheosis_unlocked = true;
          if (!activeStoryPopup) activeStoryPopup = "apotheosis_unlocked";
        }
        if (singularityUnlocked && !s.singularityUnlocked) {
          newStory.singularity_unlocked = true;
          if (!activeStoryPopup) activeStoryPopup = "singularity_unlocked";
        }
        if (omnipotenceUnlocked && !s.omnipotenceUnlocked) {
          newStory.omnipotence_unlocked = true;
          if (!activeStoryPopup) activeStoryPopup = "omnipotence_unlocked";
        }
        if (divinityUnlocked && !s.divinityUnlocked) {
          newStory.divinity_unlocked = true;
          if (!activeStoryPopup) activeStoryPopup = "divinity_unlocked";
        }
        if (infinityUnlocked && !s.infinityUnlocked) {
          newStory.infinity_unlocked = true;
          if (!activeStoryPopup) activeStoryPopup = "infinity_unlocked";
        }
        if (eternityUnlocked && !s.eternityUnlocked) {
          newStory.eternity_unlocked = true;
          if (!activeStoryPopup) activeStoryPopup = "eternity_unlocked";
        }
        metaState.storyUnlocked = newStory;
        if (activeStoryPopup) metaState.activeStoryPopup = activeStoryPopup;

        // Check achievements after prestige
        const postState = { ...s, ...metaState } as GameState;
        const achResult = checkAchievements(postState);
        metaState.achievements = achResult.earned;
        if (achResult.newOnes.length > 0) {
          metaState.newAchievements = [...(s.newAchievements || []), ...achResult.newOnes];
        }

        set({
          ...fresh,
          ...metaState,
          currentTab: "actions",
          speed: 1,
          paused: false,
          showShop: false,
          showEvolve: false,
          hasSeenIntro: true,
          lastSaved: Date.now(),
          tutorialActive: false,
        });
        get().addToLog(`Prestige! Earned ${epEarned} Evolution Points.`);
      },

      setTab: (tab) => set({ currentTab: tab }),
      setSpeed: (speed) => set({ speed }),
      togglePause: () => set((s) => ({ paused: !s.paused })),
      setShowShop: (v) => set({ showShop: v }),
      setShowEvolve: (v) => set({ showEvolve: v }),
      setShowSettings: (v) => set({ showSettings: v }),
      dismissTutorial: () => set({ tutorialActive: false, tutorialDismissed: true }),
      setEventFrequency: (freq) => set({ eventFrequency: freq }),

      resolveEvent: (eventId, choiceId) => {
        const s = get();
        const ev = EVENT_MAP[eventId];
        if (!ev) {
          set({ activeEvent: null });
          return;
        }
        const choice = ev.choices.find((c) => c.id === choiceId);
        if (!choice) {
          set({ activeEvent: null });
          return;
        }
        // Apply effects
        const res = { ...s.resources };
        if (choice.resourceChanges) {
          for (const [r, v] of Object.entries(choice.resourceChanges)) {
            const cap = s.capacities[r] || Infinity;
            res[r] = Math.max(0, Math.min(cap, (res[r] || 0) + (v as number)));
          }
        }
        let pop = s.population;
        if (choice.populationChange) {
          pop = Math.max(0, pop + choice.populationChange);
        }
        if (choice.happinessChange) {
          const cap = s.capacities.happiness || 100;
          res.happiness = Math.max(0, Math.min(cap, (res.happiness || 0) + choice.happinessChange));
        }
        const archetypeAffinity = { ...s.archetypeAffinity };
        if (choice.affinityChange) {
          for (const ac of choice.affinityChange) {
            archetypeAffinity[ac.archetype] = (archetypeAffinity[ac.archetype] || 0) + ac.amount;
          }
        }
        // Record in event history
        const eventHistory = [
          {
            eventId: ev.id,
            eventName: ev.name,
            eventIcon: ev.icon,
            choiceId: choice.id,
            choiceLabel: choice.label,
            timestamp: Date.now(),
            gameTime: s.time,
          },
          ...(s.eventHistory || []),
        ].slice(0, 50); // keep last 50
        set({
          resources: res,
          population: pop,
          maxPopulation: Math.max(s.maxPopulation || 0, pop),
          archetypeAffinity,
          activeEvent: null,
          eventHistory,
          totalEventsResolved: (s.totalEventsResolved || 0) + 1,
        });
        if (choice.logMsg) get().addToLog(`${ev.name}: ${choice.logMsg}`);

        // Check achievements after event resolution
        const postEventState = get();
        const achResult = checkAchievements(postEventState);
        if (achResult.newOnes.length > 0) {
          set({
            achievements: achResult.earned,
            newAchievements: [...(postEventState.newAchievements || []), ...achResult.newOnes],
          });
        }
      },

      dismissStory: (id) => {
        const s = get();
        const ack = { ...s.storyAcknowledged, [id]: true };
        set({ activeStoryPopup: null, storyAcknowledged: ack });
      },

      dismissAchievementToast: () => {
        set({ newAchievements: [] });
      },

      applyOfflineProgress: () => {
        const s = get();
        if (!s.lastSaved) return null;
        const elapsedSec = Math.floor((Date.now() - s.lastSaved) / 1000);
        // Only apply if away for more than 30 seconds
        if (elapsedSec < 30) return null;
        // Cap: base 24h, +24h per temporal_reserves tier
        const tempReservesLvl = s.upgrades["temporal_reserves"] || 0;
        const maxBank = 86400 + tempReservesLvl * 86400;
        const appliedDt = Math.min(elapsedSec, maxBank);
        if (appliedDt < 30) return null;

        // Snapshot resources before to compute gains
        const before = { ...s.resources };

        // Apply tick at compressed speed (cap at 86400 per call to avoid huge loops)
        // We simulate in chunks of 3600s (1 hour) to stay performant
        const chunkSize = 3600;
        let remaining = appliedDt;
        // Temporarily set speed to 1 and call tick with large dt
        while (remaining > 0) {
          const chunk = Math.min(chunkSize, remaining);
          get().tick(chunk);
          remaining -= chunk;
          // Re-read state in case it changed
          const cur = get();
          if (cur.paused) break;
        }

        const after = get();
        const resourcesGained: Record<string, number> = {};
        for (const r of Object.keys(after.resources)) {
          const gain = (after.resources[r] || 0) - (before[r] || 0);
          if (Math.abs(gain) > 0.01) resourcesGained[r] = gain;
        }

        get().addToLog(`Offline progress: simulated ${Math.floor(appliedDt / 60)}m ${Math.floor(appliedDt % 60)}s away.`);

        return { elapsed: appliedDt, resourcesGained, applied: true };
      },

      addToLog: (msg) => {
        const s = get();
        const ts = new Date().toLocaleTimeString();
        const entry = `[${ts}] ${msg}`;
        const log = [entry, ...s.log].slice(0, 100);
        set({ log });
      },

      hardReset: () => {
        if (typeof window !== "undefined") {
          localStorage.removeItem(STORAGE_KEY);
        }
        const fresh = { ...initialRunState(), ...initialMetaState() };
        set(fresh);
      },

      saveGame: () => {
        set({ lastSaved: Date.now() });
      },

      loadGame: () => {
        // Handled by persist middleware
      },

      exportSave: () => {
        const s = get();
        return btoa(unescape(encodeURIComponent(JSON.stringify(s))));
      },

      importSave: (data) => {
        try {
          const parsed = JSON.parse(decodeURIComponent(escape(atob(data))));
          set(parsed);
          return true;
        } catch {
          return false;
        }
      },

      setShowChallenges: (v) => set({ showChallenges: v }),
      setActiveChallenge: (id) => {
        const s = get();
        if (id) {
          const ch = CHALLENGE_MAP[id];
          if (!ch) return;
          const hasMasteryUpgrade = (s.upgrades["challenge_mastery"] || 0) > 0;
          const maxRepeats = getMaxRepeats(hasMasteryUpgrade);
          const currentRepeats = (s.challengeRepeatCounts || {})[id] || 0;
          if (currentRepeats >= maxRepeats) {
            get().addToLog(`${ch.name} already mastered ${maxRepeats} times — cannot repeat further.`);
            return;
          }
          const nextRepeat = currentRepeats + 1;
          const scaledDebuff = getChallengeDebuffAtRepeat(id, nextRepeat);
          set({ activeChallenge: id });
          get().addToLog(
            `Challenge started: ${ch.name} (repeat ${nextRepeat}/${maxRepeats}). ${scaledDebuff.label}.`
          );
        } else {
          set({ activeChallenge: null });
          get().addToLog("Challenge abandoned.");
        }
      },

      // ============ LAYER 2: ENLIGHTENMENT ============
      setShowEnlightenment: (v) => set({ showEnlightenment: v }),
      selectRoute: (id) => {
        const s = get();
        if (id && !ROUTE_MAP[id]) return;
        set({ selectedRoute: id });
        if (id) {
          const route = ROUTE_MAP[id];
          get().addToLog(`Route chosen: ${route.name}.`);
        } else {
          get().addToLog("Route cleared.");
        }
      },
      purchaseForesightNode: (id) => {
        const s = get();
        const node = FORESIGHT_NODE_MAP[id];
        if (!node) return;
        if (s.foresightNodes?.[id]) return;
        // Check prerequisites
        if (node.requires) {
          for (const req of node.requires) {
            if (!s.foresightNodes?.[req]) {
              get().addToLog(`Foresight node "${node.name}" requires "${FORESIGHT_NODE_MAP[req]?.name || req}" first.`);
              return;
            }
          }
        }
        // Check Divinity cost
        if ((s.resources.divinity || 0) < node.cost) {
          get().addToLog(`Not enough Divinity for "${node.name}" (need ${node.cost}).`);
          return;
        }
        const resources = { ...s.resources };
        resources.divinity = (resources.divinity || 0) - node.cost;
        const foresightNodes = { ...(s.foresightNodes || {}), [id]: true };
        set({ resources, foresightNodes });
        get().addToLog(`Purchased Foresight node: ${node.name}.`);
      },

      // ============ LAYER 3: TRANSCENDENCE ============
      setShowTranscendence: (v) => set({ showTranscendence: v }),
      makeOffering: (id) => {
        const s = get();
        const offering = OFFERING_MAP[id];
        if (!offering) return;
        const costRes = offering.cost.resource;
        if ((s.resources[costRes] || 0) < offering.cost.amount) {
          get().addToLog(`Not enough ${costRes} for ${offering.name}.`);
          return;
        }
        const resources = { ...s.resources };
        resources[costRes] = (resources[costRes] || 0) - offering.cost.amount;
        resources.divinity = (resources.divinity || 0) + offering.divinityGain;
        const offeringsUsedThisRun = {
          ...(s.offeringsUsedThisRun || {}),
          [id]: (s.offeringsUsedThisRun?.[id] || 0) + 1,
        };
        set({ resources, offeringsUsedThisRun });
        get().addToLog(`Offering made: ${offering.name} (+${offering.divinityGain} Divinity).`);
      },
      performRitual: (id) => {
        const s = get();
        const ritual = RITUAL_MAP[id];
        if (!ritual) return;
        if (s.ritualUsesThisRun?.[id]) {
          get().addToLog(`Ritual "${ritual.name}" already performed this run.`);
          return;
        }
        if ((s.resources.divinity || 0) < ritual.cost) {
          get().addToLog(`Not enough Divinity for ${ritual.name} (need ${ritual.cost}).`);
          return;
        }
        const resources = { ...s.resources };
        resources.divinity = (resources.divinity || 0) - ritual.cost;
        const ritualUsesThisRun = { ...(s.ritualUsesThisRun || {}), [id]: true };
        // Track all-time: increment ritualsUsedAllTime counter for this ritual id
        const ritualsUsedAllTime = { ...(s.ritualsUsedAllTime || {}) };
        ritualsUsedAllTime[id] = (ritualsUsedAllTime[id] || 0) + 1;
        // Add to activeRituals if it has a duration (temporary)
        const activeRituals = [...(s.activeRituals || [])];
        if (ritual.duration !== undefined) {
          activeRituals.push({ id, remaining: ritual.duration });
        }
        // Handle Break Through ritual (evolve_skip flag) — queue a buff
        let evolveSkipBuffs = s.evolveSkipBuffs || 0;
        for (const eff of ritual.effects) {
          if (eff.mode === "flag" && eff.target === "evolve_skip") {
            evolveSkipBuffs += 1;
          }
        }
        set({ resources, ritualUsesThisRun, ritualsUsedAllTime, activeRituals, evolveSkipBuffs });
        get().addToLog(`Ritual performed: ${ritual.name}.`);
      },
      toggleScript: (id) => {
        const s = get();
        if (!SCRIPT_MAP[id]) return;
        const activeScripts = { ...(s.activeScripts || {}) };
        const scriptsTriedAllTime = { ...(s.scriptsTriedAllTime || {}) };
        if (activeScripts[id]) {
          delete activeScripts[id];
          get().addToLog(`Script disabled: ${SCRIPT_MAP[id].name}.`);
        } else {
          activeScripts[id] = true;
          scriptsTriedAllTime[id] = true;
          get().addToLog(`Script enabled: ${SCRIPT_MAP[id].name}.`);
        }
        set({ activeScripts, scriptsTriedAllTime });
      },
      performBloodPact: (id) => {
        const s = get();
        const pact = BLOOD_PACT_MAP[id];
        if (!pact) return;
        const uses = (s.bloodPactUsesThisRun?.[id] || 0);
        if (uses >= pact.limitPerRun) {
          get().addToLog(`Blood Pact "${pact.name}" reached per-run limit (${pact.limitPerRun}).`);
          return;
        }
        // Population cost (flat or fraction)
        let popCost = 0;
        if (pact.populationCost !== undefined) {
          popCost = pact.populationCost;
          if ((s.population || 0) < popCost) {
            get().addToLog(`Not enough population for ${pact.name} (need ${popCost}).`);
            return;
          }
        } else if (pact.populationFraction !== undefined) {
          popCost = Math.floor((s.population || 0) * pact.populationFraction);
          if (popCost < 1) {
            get().addToLog(`Population too low for ${pact.name}.`);
            return;
          }
        }
        const resources = { ...s.resources };
        resources.divinity = (resources.divinity || 0) + pact.divinityGain;
        // Apply happiness cost
        const cap = s.capacities.happiness || 100;
        resources.happiness = Math.max(0, Math.min(cap, (resources.happiness || 0) + pact.happinessCost));
        const bloodPactUsesThisRun = {
          ...(s.bloodPactUsesThisRun || {}),
          [id]: uses + 1,
        };
        set({
          resources,
          population: Math.max(0, (s.population || 0) - popCost),
          maxPopulation: Math.max(s.maxPopulation || 0, Math.max(0, (s.population || 0) - popCost)),
          bloodPactUsesThisRun,
          bloodPactUsedAllTime: true,
        });
        get().addToLog(`Blood Pact: ${pact.name} (-${popCost} pop, +${pact.divinityGain} Divinity, ${pact.happinessCost} happiness).`);
      },

      // ============ LAYER 4: GENESIS ============
      setShowGenesis: (v) => set({ showGenesis: v }),
      setWorldConfig: (config) => {
        const s = get();
        set({ worldConfig: config });
        get().addToLog(`Cradle World authored: ${CRADLE_WORLD_MAP[config.cradleWorld]?.name || config.cradleWorld}.`);
      },
      clearWorldConfig: () => {
        set({ worldConfig: null });
        get().addToLog("Cradle World authoring cleared.");
      },

      // ============ LAYER 5: APOTHEOSIS ============
      setShowApotheosis: (v) => set({ showApotheosis: v }),
      enactDivineLaw: (id) => {
        const s = get();
        const law = DIVINE_LAW_MAP[id];
        if (!law) return;
        if (s.divineLawsEnactedThisRun?.[id]) {
          get().addToLog(`Law "${law.name}" already codified this run.`);
          return;
        }
        if ((s.resources.divinity || 0) < law.cost) {
          get().addToLog(`Not enough Divinity for ${law.name} (need ${law.cost}).`);
          return;
        }
        const resources = { ...s.resources };
        resources.divinity = (resources.divinity || 0) - law.cost;
        const divineLawsEnactedThisRun = { ...(s.divineLawsEnactedThisRun || {}), [id]: true };
        // Track all-time count
        const divineLawsEnactedAllTime = { ...(s.divineLawsEnactedAllTime || {}) };
        divineLawsEnactedAllTime[id] = (divineLawsEnactedAllTime[id] || 0) + 1;
        // Apply one-time heresy flat change (Law of Faith: -20)
        let heresyLevel = s.heresyLevel || 0;
        if (law.heresyFlatOnCodify) {
          heresyLevel = Math.max(0, heresyLevel + law.heresyFlatOnCodify);
        }
        set({ resources, divineLawsEnactedThisRun, divineLawsEnactedAllTime, heresyLevel });
        get().addToLog(`Divine Law codified: ${law.name}.`);
      },
      setWorshipMode: (id) => {
        const s = get();
        if (id && !WORSHIP_MODE_MAP[id]) return;
        const worshipModesUsedAllTime = { ...(s.worshipModesUsedAllTime || {}) };
        if (id) worshipModesUsedAllTime[id] = true;
        set({ worshipMode: id, worshipModesUsedAllTime });
        if (id) {
          get().addToLog(`Worship mode set: ${WORSHIP_MODE_MAP[id].name}.`);
        } else {
          get().addToLog("Worship mode cleared.");
        }
      },
      performMiracle: (id) => {
        const s = get();
        const miracle = MIRACLE_MAP[id];
        if (!miracle) return;
        const uses = (s.miracleUsesThisRun?.[id] || 0);
        if (uses >= miracle.limitPerRun) {
          get().addToLog(`Miracle "${miracle.name}" reached per-run limit (${miracle.limitPerRun}).`);
          return;
        }
        if ((s.resources.divinity || 0) < miracle.cost) {
          get().addToLog(`Not enough Divinity for ${miracle.name} (need ${miracle.cost}).`);
          return;
        }
        const resources = { ...s.resources };
        resources.divinity = (resources.divinity || 0) - miracle.cost;
        // Apply effects
        if (miracle.grantAllResources) {
          for (const rid of MIRACLE_ALL_RESOURCE_TARGETS) {
            const cap = s.capacities[rid] || Infinity;
            resources[rid] = Math.min(cap, (resources[rid] || 0) + miracle.grantAllResources);
          }
        }
        if (miracle.grantPopulation) {
          // population handled below
        }
        if (miracle.setHappiness !== undefined) {
          resources.happiness = miracle.setHappiness;
        }
        let heresyLevel = s.heresyLevel || 0;
        if (miracle.heresyFlat) {
          heresyLevel = Math.max(0, heresyLevel + miracle.heresyFlat);
        }
        const miracleUsesThisRun = {
          ...(s.miracleUsesThisRun || {}),
          [id]: uses + 1,
        };
        const miracleUsesAllTime = {
          ...(s.miracleUsesAllTime || {}),
          [id]: (s.miracleUsesAllTime?.[id] || 0) + 1,
        };
        const popBonus = miracle.grantPopulation || 0;
        set({
          resources,
          population: (s.population || 0) + popBonus,
          maxPopulation: Math.max(s.maxPopulation || 0, (s.population || 0) + popBonus),
          heresyLevel,
          miracleUsesThisRun,
          miracleUsesAllTime,
        });
        get().addToLog(`Miracle invoked: ${miracle.name}.`);
      },
      respondToHeresy: (id) => {
        const s = get();
        const response = HERESY_RESPONSE_MAP[id];
        if (!response) return;
        const uses = (s.heresyResponseUsesThisRun?.[id] || 0);
        if (uses >= response.limitPerRun) {
          get().addToLog(`Heresy response "${response.name}" reached per-run limit.`);
          return;
        }
        if ((s.resources.divinity || 0) < response.cost) {
          get().addToLog(`Not enough Divinity for ${response.name} (need ${response.cost}).`);
          return;
        }
        const resources = { ...s.resources };
        resources.divinity = (resources.divinity || 0) - response.cost;
        let heresyLevel = s.heresyLevel || 0;
        let happiness = resources.happiness || 0;
        let population = s.population || 0;
        if (response.heresyFlat) heresyLevel = Math.max(0, heresyLevel + response.heresyFlat);
        if (response.happinessFlat) {
          const cap = s.capacities.happiness || 100;
          happiness = Math.max(0, Math.min(cap, happiness + response.happinessFlat));
          resources.happiness = happiness;
        }
        if (response.populationFlat) {
          population = Math.max(0, population + response.populationFlat);
        }
        const heresyResponseUsesThisRun = {
          ...(s.heresyResponseUsesThisRun || {}),
          [id]: uses + 1,
        };
        // Inquisition resolves the schism
        const heresySurvivedAllTime = s.heresySurvivedAllTime || id === "inquisition";
        set({
          resources,
          heresyLevel,
          population,
          maxPopulation: Math.max(s.maxPopulation || 0, population),
          heresyResponseUsesThisRun,
          heresySurvivedAllTime,
        });
        get().addToLog(`Heresy response: ${response.name}.`);
      },

      // ============ LAYER 6: SINGULARITY ============
      setShowSingularity: (v) => set({ showSingularity: v }),
      bindRelicLoadout: (id) => {
        const s = get();
        if (id && !RELIC_LOADOUT_MAP[id]) return;
        const relicsBoundAllTime = {
          ...(s.relicsBoundAllTime || {}),
          ...(id ? { [id]: true } : {}),
        };
        set({ activeRelicLoadout: id, relicsBoundAllTime });
        if (id) {
          get().addToLog(`Relic equipped: ${RELIC_LOADOUT_MAP[id].name}.`);
        } else {
          get().addToLog("Relic unequipped.");
        }
      },
      toggleLogicCore: (id) => {
        const s = get();
        if (!LOGIC_CORE_MAP[id]) return;
        const activeLogicCores = { ...(s.activeLogicCores || {}) };
        const logicCoresEnabledAllTime = { ...(s.logicCoresEnabledAllTime || {}) };
        const installedCount = Object.keys(activeLogicCores).filter((k) => activeLogicCores[k]).length;
        if (activeLogicCores[id]) {
          delete activeLogicCores[id];
          get().addToLog(`Logic Core uninstalled: ${LOGIC_CORE_MAP[id].name}.`);
        } else {
          if (installedCount >= MAX_INSTALLED_LOGIC_CORES) {
            get().addToLog(`Max installed cores (${MAX_INSTALLED_LOGIC_CORES}) reached.`);
            return;
          }
          activeLogicCores[id] = true;
          logicCoresEnabledAllTime[id] = true;
          get().addToLog(`Logic Core installed: ${LOGIC_CORE_MAP[id].name}.`);
        }
        set({ activeLogicCores, logicCoresEnabledAllTime });
      },

      // ============ LAYER 7: OMNIPOTENCE ============
      setShowOmnipotence: (v) => set({ showOmnipotence: v }),
      selectHybridLineage: (id) => {
        const s = get();
        if (id && !HYBRID_LINEAGE_MAP[id]) return;
        const hybridLineagesTriedAllTime = {
          ...(s.hybridLineagesTriedAllTime || {}),
          ...(id ? { [id]: true } : {}),
        };
        set({ activeHybridLineage: id, hybridLineagesTriedAllTime });
        if (id) {
          get().addToLog(`Hybrid Lineage bound: ${HYBRID_LINEAGE_MAP[id].name}.`);
        } else {
          get().addToLog("Hybrid Lineage unbound.");
        }
      },
      setStance: (id) => {
        const s = get();
        if (!STANCE_MAP[id]) return;
        const stancesTriedAllTime = { ...(s.stancesTriedAllTime || {}), [id]: true };
        set({ activeStance: id, stancesTriedAllTime });
        get().addToLog(`Stance chosen: ${STANCE_MAP[id].name}.`);
      },

      // ============ LAYER 8: DIVINITY ============
      setShowDivinityModal: (v) => set({ showDivinityModal: v }),
      levelPrayerChannel: (id) => {
        const s = get();
        const channel = PRAYER_CHANNEL_MAP[id];
        if (!channel) return;
        // Cost grows linearly with level (10 Divinity × current level + 10).
        const currentLevel = (s.prayerChannels?.[id] || 0);
        const cost = 10 * (currentLevel + 1);
        if ((s.resources.divinity || 0) < cost) {
          get().addToLog(`Not enough Divinity for ${channel.name} Lv ${currentLevel + 1} (need ${cost}).`);
          return;
        }
        const resources = { ...s.resources };
        resources.divinity = (resources.divinity || 0) - cost;
        const prayerChannels = { ...(s.prayerChannels || {}), [id]: currentLevel + 1 };
        set({ resources, prayerChannels });
        get().addToLog(`Prayer Channel leveled: ${channel.name} → Lv ${currentLevel + 1}.`);
      },
      selectDivineMask: (id) => {
        const s = get();
        if (id && !DIVINE_MASK_MAP[id]) return;
        const divineMasksTriedAllTime = {
          ...(s.divineMasksTriedAllTime || {}),
          ...(id ? { [id]: true } : {}),
        };
        set({ activeDivineMask: id, divineMasksTriedAllTime });
        if (id) {
          get().addToLog(`Divine Mask worn: ${DIVINE_MASK_MAP[id].name}.`);
        } else {
          get().addToLog("Divine Mask removed.");
        }
      },
      alignWorshipPolarity: (id) => {
        const s = get();
        if (id && !WORSHIP_POLARITY_MAP[id]) return;
        const worshipPolaritiesTriedAllTime = {
          ...(s.worshipPolaritiesTriedAllTime || {}),
          ...(id ? { [id]: true } : {}),
        };
        set({ activeWorshipPolarity: id, worshipPolaritiesTriedAllTime });
        if (id) {
          get().addToLog(`Worship Polarity aligned: ${WORSHIP_POLARITY_MAP[id].name}.`);
        } else {
          get().addToLog("Worship Polarity cleared.");
        }
      },

      // ============ LAYER 9: INFINITY ============
      setShowInfinity: (v) => set({ showInfinity: v }),
      purchaseEcho: (id) => {
        const s = get();
        const echo = ECHO_MAP[id];
        if (!echo) return;
        if ((s.echoes || 0) < echo.cost) {
          get().addToLog(`Not enough Echoes for ${echo.name} (need ${echo.cost}).`);
          return;
        }
        const echoes = (s.echoes || 0) - echo.cost;
        const echoesOwned = { ...(s.echoesOwned || {}), [id]: (s.echoesOwned?.[id] || 0) + 1 };
        set({ echoes, echoesOwned });
        get().addToLog(`Purchased Echo: ${echo.name}.`);
      },
      resolveFork: (id, branch) => {
        const s = get();
        const fork = FORK_MAP[id];
        if (!fork) return;
        if ((s.forksResolved || {})[id]) {
          get().addToLog(`Fork "${fork.name}" already resolved this run.`);
          return;
        }
        const forksResolved = { ...(s.forksResolved || {}), [id]: branch };
        const forksResolvedAllTime = { ...(s.forksResolvedAllTime || {}), [id]: true };
        // Award echoes for resolving a fork (gives currency to spend on Echoes)
        const echoReward = 3;
        const echoes = (s.echoes || 0) + echoReward;
        set({ forksResolved, forksResolvedAllTime, echoes });
        get().addToLog(`Fork resolved: ${fork.name} → Branch ${branch}. +${echoReward} Echoes.`);
        // Fork specials (e.g. The Final Divergence branch B's unlock_random_divine_law)
        // would require deep integration with the Apotheosis layer; deferred to a
        // future task per the L9-data worklog (matches the relic-specials pattern
        // from L6-data that was similarly deferred in L2-L6-wire).
      },
      incurFutureDebt: (id) => {
        const s = get();
        const tier = FUTURE_DEBT_MAP[id];
        if (!tier) return;
        const uses = (s.futureDebtUsesThisRun?.[id] || 0);
        if (uses >= tier.perRunLimit) {
          get().addToLog(`${tier.name} reached per-run limit (${tier.perRunLimit}).`);
          return;
        }
        const futureDebtUsesThisRun = {
          ...(s.futureDebtUsesThisRun || {}),
          [id]: uses + 1,
        };
        // Add to activeDebt — boost phase begins immediately.
        const activeDebt = [...(s.activeDebt || []), {
          id,
          boostRemaining: tier.boostDuration,
          penaltyRemaining: 0,
        }];
        set({ futureDebtUsesThisRun, activeDebt });
        get().addToLog(`Future Debt incurred: ${tier.name} (+${Math.round(tier.boostMult * 100)}% production for ${tier.boostDuration}s).`);
      },

      // ============ LAYER 10: ETERNITY ============
      setShowEternity: (v) => set({ showEternity: v }),
      purchaseTestamentClause: (id) => {
        const s = get();
        const clause = TESTAMENT_CLAUSE_MAP[id];
        if (!clause) return;
        if (s.testamentClausesOwned?.[id]) {
          get().addToLog(`Clause "${clause.name}" already authored.`);
          return;
        }
        if ((s.testamentClauses || 0) < clause.cost) {
          get().addToLog(`Not enough Testament Clauses for ${clause.name} (need ${clause.cost}).`);
          return;
        }
        const testamentClauses = (s.testamentClauses || 0) - clause.cost;
        const testamentClausesOwned = { ...(s.testamentClausesOwned || {}), [id]: true };
        set({ testamentClauses, testamentClausesOwned });
        get().addToLog(`Testament Clause authored: ${clause.name}.`);
      },
      performCanonization: (id) => {
        const s = get();
        const canon = CANONIZATION_MAP[id];
        if (!canon) return;
        if ((s.testamentClauses || 0) < canon.cost) {
          get().addToLog(`Not enough Testament Clauses for ${canon.name} (need ${canon.cost}).`);
          return;
        }
        const testamentClauses = (s.testamentClauses || 0) - canon.cost;
        const canonizationsOwned = {
          ...(s.canonizationsOwned || {}),
          [id]: (s.canonizationsOwned?.[id] || 0) + 1,
        };
        set({ testamentClauses, canonizationsOwned });
        get().addToLog(`Canonization performed: ${canon.name}.`);
      },
      purchasePermanenceWeave: (id) => {
        const s = get();
        const weave = PERMANENCE_WEAVE_MAP[id];
        if (!weave) return;
        if ((s.testamentClauses || 0) < weave.cost) {
          get().addToLog(`Not enough Testament Clauses for ${weave.name} (need ${weave.cost}).`);
          return;
        }
        const testamentClauses = (s.testamentClauses || 0) - weave.cost;
        const permanenceWeavesOwned = {
          ...(s.permanenceWeavesOwned || {}),
          [id]: (s.permanenceWeavesOwned?.[id] || 0) + 1,
        };
        set({ testamentClauses, permanenceWeavesOwned });
        get().addToLog(`Permanence Weave purchased: ${weave.name}.`);
      },
      chooseEnding: (id) => {
        const s = get();
        if (id !== "preserve" && id !== "reset") return;
        if (s.endingChosen) {
          get().addToLog("Ending already chosen this run.");
          return;
        }
        // Choosing "reset" increments cosmicBoonStacks (carries the boon forward).
        const cosmicBoonStacks = id === "reset" ? (s.cosmicBoonStacks || 0) + 1 : (s.cosmicBoonStacks || 0);
        // Award Testament Clauses for the run (used to purchase clauses/canonizations/weaves).
        const clauseReward = 5 + (s.totalRuns || 0);
        const testamentClauses = (s.testamentClauses || 0) + clauseReward;
        set({ endingChosen: id, cosmicBoonStacks, testamentClauses });
        const ending = ENDING_CHOICE_MAP[id];
        get().addToLog(`Ending chosen: ${ending.name}. +${clauseReward} Testament Clauses.`);
      },
    }),
    {
      name: STORAGE_KEY,
      storage: createJSONStorage(() => {
        if (typeof window === "undefined") {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return window.localStorage;
      }),
      version: 5,
      partialize: (s) => s,
      // Migrate old saves (v1 → v2 → v3 → v4 → v5) to new structure
      migrate: (persisted: any, version: number) => {
        if (!persisted) return persisted;
        if (version < 2) {
          if (!persisted.systemEnabled) persisted.systemEnabled = {};
          if (!persisted.archetypeAffinity) persisted.archetypeAffinity = {};
          if (persisted.lockedArchetype === undefined) persisted.lockedArchetype = null;
          if (persisted.populationProgress === undefined) persisted.populationProgress = 0;
          if (!persisted.achievements) persisted.achievements = {};
          if (!persisted.newAchievements) persisted.newAchievements = [];
          if (persisted.upgrades) {
            if (persisted.upgrades.auto_balancer === undefined) persisted.upgrades.auto_balancer = 0;
            if (persisted.upgrades.archetype_insight === undefined) persisted.upgrades.archetype_insight = 0;
          }
        }
        // Always ensure achievements fields exist (even on v2)
        if (!persisted.achievements) persisted.achievements = {};
        if (!persisted.newAchievements) persisted.newAchievements = [];
        if (persisted.showSettings === undefined) persisted.showSettings = false;
        if (persisted.tutorialDismissed === undefined) persisted.tutorialDismissed = false;
        if (persisted.maxPopulation === undefined) persisted.maxPopulation = persisted.population || 8;
        if (persisted.fastestCellClear === undefined) persisted.fastestCellClear = 0;
        if (persisted.activeEvent === undefined) persisted.activeEvent = null;
        if (persisted.eventCooldown === undefined) persisted.eventCooldown = 30;
        if (!persisted.eventHistory) persisted.eventHistory = [];
        if (persisted.totalEventsResolved === undefined) persisted.totalEventsResolved = 0;
        if (persisted.totalPlayTime === undefined) persisted.totalPlayTime = 0;
        if (persisted.totalActions === undefined) persisted.totalActions = 0;
        if (persisted.totalSystemsBuilt === undefined) persisted.totalSystemsBuilt = 0;
        if (persisted.totalTechResearched === undefined) persisted.totalTechResearched = 0;
        if (!persisted.eventFrequency) persisted.eventFrequency = "normal";
        // v5: lockedTechs (exclusiveWith mechanic) — default to empty
        if (!persisted.lockedTechs) persisted.lockedTechs = {};
        // Layer 1 (Challenges/Prestige) migration
        if (persisted.unlockedChallenges === undefined) persisted.unlockedChallenges = false;
        if (persisted.activeChallenge === undefined) persisted.activeChallenge = null;
        if (!persisted.completedChallenges) persisted.completedChallenges = {};
        if (!persisted.challengeRepeatCounts) persisted.challengeRepeatCounts = {};
        if (persisted.showChallenges === undefined) persisted.showChallenges = false;
        if (persisted.showPrestigeTab === undefined) persisted.showPrestigeTab = false;
        // Upgrade roster migration: remove deprecated, add new defaults
        if (persisted.upgrades) {
          // Removed upgrades: quickened_hands (manual_mult — instant click), rival_insight (score-only)
          delete persisted.upgrades.quickened_hands;
          delete persisted.upgrades.rival_insight;
          // New upgrades default to level 0
          for (const id of [
            "auto_system_buyer", "auto_tech_buyer", "auto_evolver",
            "frontier_spirit", "ancestral_bounty",
            "challenge_mastery", "stage_compression",
            "temporal_acceleration", "deep_memory", "cosmic_understanding",
          ]) {
            if (persisted.upgrades[id] === undefined) persisted.upgrades[id] = 0;
          }
        }
        // v4: Layer 2-6 state field migration — backfill defaults for new fields
        if (persisted.enlightenmentUnlocked === undefined) persisted.enlightenmentUnlocked = false;
        if (persisted.divinity === undefined) persisted.divinity = 0;
        if (persisted.selectedRoute === undefined) persisted.selectedRoute = null;
        if (!persisted.foresightNodes) persisted.foresightNodes = {};
        if (persisted.showEnlightenment === undefined) persisted.showEnlightenment = false;
        if (persisted.transcendenceUnlocked === undefined) persisted.transcendenceUnlocked = false;
        if (persisted.showTranscendence === undefined) persisted.showTranscendence = false;
        if (!persisted.offeringsUsedThisRun) persisted.offeringsUsedThisRun = {};
        if (!persisted.ritualUsesThisRun) persisted.ritualUsesThisRun = {};
        if (!persisted.ritualsUsedAllTime) persisted.ritualsUsedAllTime = {};
        if (!persisted.bloodPactUsesThisRun) persisted.bloodPactUsesThisRun = {};
        if (persisted.bloodPactUsedAllTime === undefined) persisted.bloodPactUsedAllTime = false;
        if (!persisted.activeScripts) persisted.activeScripts = {};
        if (!persisted.scriptsTriedAllTime) persisted.scriptsTriedAllTime = {};
        if (!persisted.activeRituals) persisted.activeRituals = [];
        if (persisted.evolveSkipBuffs === undefined) persisted.evolveSkipBuffs = 0;
        if (persisted.genesisUnlocked === undefined) persisted.genesisUnlocked = false;
        if (persisted.showGenesis === undefined) persisted.showGenesis = false;
        if (persisted.worldConfig === undefined) persisted.worldConfig = null;
        if (!persisted.cradleWorldWins) persisted.cradleWorldWins = {};
        if (!persisted.awakenedSeedsThisRun) persisted.awakenedSeedsThisRun = {};
        if (!persisted.awakenedSeedsAllTime) persisted.awakenedSeedsAllTime = {};
        if (persisted.apotheosisUnlocked === undefined) persisted.apotheosisUnlocked = false;
        if (persisted.showApotheosis === undefined) persisted.showApotheosis = false;
        if (!persisted.divineLawsEnactedThisRun) persisted.divineLawsEnactedThisRun = {};
        if (!persisted.divineLawsEnactedAllTime) persisted.divineLawsEnactedAllTime = {};
        if (persisted.worshipMode === undefined) persisted.worshipMode = null;
        if (!persisted.worshipModesUsedAllTime) persisted.worshipModesUsedAllTime = {};
        if (!persisted.miracleUsesThisRun) persisted.miracleUsesThisRun = {};
        if (!persisted.miracleUsesAllTime) persisted.miracleUsesAllTime = {};
        if (persisted.heresyLevel === undefined) persisted.heresyLevel = 0;
        if (!persisted.heresyResponseUsesThisRun) persisted.heresyResponseUsesThisRun = {};
        if (persisted.heresySurvivedAllTime === undefined) persisted.heresySurvivedAllTime = false;
        if (persisted.singularityUnlocked === undefined) persisted.singularityUnlocked = false;
        if (persisted.showSingularity === undefined) persisted.showSingularity = false;
        if (persisted.activeRelicLoadout === undefined) persisted.activeRelicLoadout = null;
        if (!persisted.relicsBoundAllTime) persisted.relicsBoundAllTime = {};
        if (!persisted.activeLogicCores) persisted.activeLogicCores = {};
        if (!persisted.logicCoresEnabledAllTime) persisted.logicCoresEnabledAllTime = {};
        // v5: Layer 7-10 state field migration — backfill defaults for new fields
        if (persisted.omnipotenceUnlocked === undefined) persisted.omnipotenceUnlocked = false;
        if (persisted.showOmnipotence === undefined) persisted.showOmnipotence = false;
        if (persisted.activeHybridLineage === undefined) persisted.activeHybridLineage = null;
        if (!persisted.hybridLineagesTriedAllTime) persisted.hybridLineagesTriedAllTime = {};
        if (persisted.activeStance === undefined) persisted.activeStance = "balanced";
        if (!persisted.stancesTriedAllTime) persisted.stancesTriedAllTime = {};
        if (persisted.instabilityLevel === undefined) persisted.instabilityLevel = 0;
        if (persisted.peakInstability === undefined) persisted.peakInstability = 0;
        if (persisted.divinityUnlocked === undefined) persisted.divinityUnlocked = false;
        if (persisted.showDivinityModal === undefined) persisted.showDivinityModal = false;
        if (!persisted.prayerChannels) persisted.prayerChannels = {};
        if (persisted.prayerOutput === undefined) persisted.prayerOutput = 0;
        if (persisted.activeDivineMask === undefined) persisted.activeDivineMask = null;
        if (!persisted.divineMasksTriedAllTime) persisted.divineMasksTriedAllTime = {};
        if (persisted.activeWorshipPolarity === undefined) persisted.activeWorshipPolarity = null;
        if (!persisted.worshipPolaritiesTriedAllTime) persisted.worshipPolaritiesTriedAllTime = {};
        if (persisted.infinityUnlocked === undefined) persisted.infinityUnlocked = false;
        if (persisted.showInfinity === undefined) persisted.showInfinity = false;
        if (persisted.echoes === undefined) persisted.echoes = 0;
        if (!persisted.echoesOwned) persisted.echoesOwned = {};
        if (!persisted.forksResolved) persisted.forksResolved = {};
        if (!persisted.forksResolvedAllTime) persisted.forksResolvedAllTime = {};
        if (!persisted.futureDebtUsesThisRun) persisted.futureDebtUsesThisRun = {};
        if (persisted.futureDebtRepaidAllTime === undefined) persisted.futureDebtRepaidAllTime = false;
        if (!persisted.activeDebt) persisted.activeDebt = [];
        if (persisted.eternityUnlocked === undefined) persisted.eternityUnlocked = false;
        if (persisted.showEternity === undefined) persisted.showEternity = false;
        if (persisted.testamentClauses === undefined) persisted.testamentClauses = 0;
        if (!persisted.testamentClausesOwned) persisted.testamentClausesOwned = {};
        if (!persisted.canonizationsOwned) persisted.canonizationsOwned = {};
        if (!persisted.permanenceWeavesOwned) persisted.permanenceWeavesOwned = {};
        if (persisted.endingChosen === undefined) persisted.endingChosen = null;
        if (persisted.cosmicBoonStacks === undefined) persisted.cosmicBoonStacks = 0;
        return persisted;
      },
    }
  )
);

// ============ HELPERS ============

function techMultiplier(s: GameState, target: "production" | "manual" | "capacity"): number {
  let mult = 1;
  for (const [techId, owned] of Object.entries(s.technologies)) {
    if (!owned) continue;
    const tech = TECH_MAP[techId];
    if (!tech || !tech.multiplier) continue;
    if (tech.multiplier.target === target || tech.multiplier.target === "production") {
      mult += tech.multiplier.value;
    }
  }
  // Achievement production bonus
  const ctx = buildAchievementCtx(s);
  mult += achievementBonus(s.achievements || {}, ctx, "production");
  // Challenge mastery bonus (Layer 1) — repeat-aware aggregation
  if (target === "production") {
    // "production" target covers the Trial of Discontent/Stagnation mastery
    mult += challengeMasteryBonusFromRepeats(s.challengeRepeatCounts || {}, "production");
    // "all_production" mastery (Trial of Swiftness) applies to all production
    mult += challengeMasteryBonusFromRepeats(s.challengeRepeatCounts || {}, "all_production");
  }
  // Layer 2: Foresight node bonuses — additive per type
  mult += foresightBonus(s.foresightNodes || {}, "production");
  if (target === "manual") {
    mult += foresightBonus(s.foresightNodes || {}, "manual");
  }
  if (target === "capacity") {
    mult += foresightBonus(s.foresightNodes || {}, "capacity");
  }
  // Layer 5: Divine Law production bonus (Law of Abundance, Law of Tithe)
  const lawBonus = divineLawBonus(s.divineLawsEnactedThisRun || {});
  if (target === "production") mult += lawBonus.productionMult;
  // Layer 6: Logic core passive production bonus (Trade Core)
  if (target === "production") {
    const coreBonus = logicCoreBonus(s.activeLogicCores || {});
    mult += coreBonus.productionMult;
    // Relic production bonus (Singularity Core, Golden Idol, Stone Tablet negative, Omni Matrix)
    const relic = relicBonus(s.activeRelicLoadout);
    let relicProd = relic.productionMult;
    // Omni Matrix scaling special
    if (relic.special?.kind === "scale_with_installed_cores") {
      const installedCount = Object.values(s.activeLogicCores || {}).filter(Boolean).length;
      relicProd *= (1 + relic.special.perCoreMult * installedCount);
    }
    mult += relicProd;
  }
  return mult;
}

function buildAchievementCtx(s: GameState): AchievementCheckCtx {
  const systemsDiscoveredCount = Object.keys(s.ownedSystems).filter((id) => (s.ownedSystems[id] || 0) > 0).length;
  const techResearchedCount = Object.keys(s.technologies).filter((id) => s.technologies[id]).length;
  const upgradesOwnedCount = Object.values(s.upgrades).filter((c) => c > 0).length;
  const storyUnlockedCount = Object.keys(s.storyUnlocked).filter((id) => s.storyUnlocked[id]).length;
  return {
    galacticWins: s.galacticWins,
    totalRuns: s.totalRuns,
    stageClearCounts: s.stageClearCounts,
    archivedArchetypes: s.archivedArchetypes || [],
    storyUnlockedCount,
    systemsDiscoveredCount,
    techResearchedCount,
    upgradesOwnedCount,
    maxPopulation: s.maxPopulation || 0,
    fastestCellClear: s.fastestCellClear || 0,
    totalEventsResolved: s.totalEventsResolved || 0,
  };
}

// Check all achievements; return new ones earned
function checkAchievements(s: GameState): { earned: Record<string, boolean>; newOnes: string[] } {
  const ctx = buildAchievementCtx(s);
  const earned = { ...(s.achievements || {}) };
  const newOnes: string[] = [];
  for (const ach of ACHIEVEMENTS) {
    if (!earned[ach.id] && ach.check(ctx)) {
      earned[ach.id] = true;
      newOnes.push(ach.id);
    }
  }
  return { earned, newOnes };
}

function computeScore(s: GameState): number {
  const totalSystems = Object.values(s.ownedSystems).reduce((a, b) => a + b, 0);
  const totalTech = Object.keys(s.technologies).length;
  const resourceSum = Object.values(s.resources).reduce((a, b) => a + b, 0);
  return Math.floor(
    s.population * 2 +
    totalSystems * 5 +
    totalTech * 10 +
    resourceSum * 0.5 +
    s.time * 0.1
  );
}

// Recompute all capacities from scratch based on owned systems
function recomputeCapacitiesFresh(s: GameState, capMult: number): Record<string, number> {
  const base = emptyCapacities();
  const caps: Record<string, number> = {};
  for (const r of Object.keys(base)) {
    let cap = (base[r] || 50) * capMult;
    for (const sys of SYSTEMS) {
      const count = s.ownedSystems[sys.id] || 0;
      if (!count || !sys.capacityBoost) continue;
      const boost = sys.capacityBoost[r];
      if (boost) cap += (boost as number) * count * capMult;
    }
    caps[r] = cap;
  }
  return caps;
}

// Export helper for components to compute whether an action is capped
export function isActionCapped(
  produces: Record<string, number>,
  resources: Record<string, number>,
  capacities: Record<string, number>
): boolean {
  const outputs = Object.entries(produces);
  if (outputs.length === 0) return false;
  return outputs.every(([r]) => {
    const cap = capacities[r] || 0;
    return (resources[r] || 0) >= cap - 0.001;
  });
}

// Export helper for whether a system is currently capped (idling)
export function isSystemCapped(
  sysId: string,
  resources: Record<string, number>,
  capacities: Record<string, number>
): boolean {
  const sys = SYSTEM_MAP[sysId];
  if (!sys) return false;
  const produces = Object.keys(sys.produces);
  if (produces.length === 0) return false;
  return produces.every((r) => {
    const cap = capacities[r] || 0;
    return (resources[r] || 0) >= cap - 0.01;
  });
}

// Export for components
export { STAGES, STAGE_IDS, SYSTEMS, TECHS, UPGRADES, ARCHETYPE_MAP };
