// Core game type definitions for Evolution Idle

export type ResourceId =
  | "atp" | "glucose" | "proteins" | "lipids" | "elements"
  | "food" | "water" | "materials" | "organic_matter" | "knowledge" | "culture"
  | "wood" | "lumber" | "stone" | "clay" | "science" | "happiness" | "military_power"
  | "production" | "gold" | "influence" | "energy" | "alloys" | "data"
  | "divinity" | "evolution_points" | "enlightenment_points" | "transcendence_points";

export type StageId =
  | "cell" | "creature" | "tribal" | "civilization" | "empire" | "solar" | "galactic";

export type TabId =
  | "actions" | "systems" | "production" | "tech" | "story"
  | "codex" | "achievements" | "archive" | "log" | "shop" | "prestige";

export interface ResourceDef {
  id: ResourceId;
  name: string;
  category: "primary" | "divinity" | "meta";
  firstStage: StageId;
  color: string;
  icon: string; // emoji
}

export interface StageAction {
  id: string;
  name: string;
  desc: string;
  stage: StageId;
  icon: string;
  cost?: Partial<Record<ResourceId, number>>;
  produces: Partial<Record<ResourceId, number>>;
  cooldown?: number; // seconds
  unlockRequirement?: string;
  scaleWith?: "population" | "happiness" | "tech";
}

export interface SystemDef {
  id: string;
  name: string;
  desc: string;
  stage: StageId;
  icon: string;
  category: string;
  baseCost: Partial<Record<ResourceId, number>>;
  costGrowth: number; // multiplier per owned
  produces: Partial<Record<ResourceId, number>>;
  capacityBoost?: Partial<Record<ResourceId, number>>;
  upkeep?: Partial<Record<ResourceId, number>>;
  maxOwned?: number;
  requiredTech?: string;
  grantsAffinity?: { archetype: string; amount: number };
}

export interface TechDef {
  id: string;
  name: string;
  desc: string;
  stage: StageId;
  cost: Partial<Record<ResourceId, number>>;
  branch: string;
  tier: number;
  requires?: string[];
  /** Techs that, if any are already researched, block this purchase.
   * Buying this tech will also lock all techs listed here (mutually exclusive paths). */
  exclusiveWith?: string[];
  effects: string;
  multiplier?: { target: "production" | "manual" | "capacity"; value: number };
  grantsAffinity?: { archetype: string; amount: number };
}

export interface StageDef {
  id: StageId;
  name: string;
  tagline: string;
  desc: string;
  icon: string;
  accent: string; // hex
  bgGradient: string; // css
  duration: string;
  evolveRequires: {
    minPopulation: number;
    minSystems: number;
    minTech: number;
  };
  storyIntro: string;
  storyOutro: string;
}

export interface UpgradeDef {
  id: string;
  name: string;
  desc: (level: number) => string;
  baseCost: number;
  maxLevel: number;
  costGrowth: number;
  category: "automation" | "economy" | "prestige" | "acceleration";
  requiresWins?: number;
  effect: { type: "auto_mult" | "cost_reduction" | "start_bonus" | "cap_boost" | "evolve_boost" | "auto_tech_buyer" | "auto_system_buyer" | "auto_evolver" | "speed_mult" | "prestige_mult" | "ep_mult" | "start_pop" | "start_all_resources"; value: number };
}

export interface StoryEntry {
  id: string;
  title: string;
  body: string;
  stage: StageId | "meta";
  layer: string;
  trigger: string;
  category: "primary" | "stage" | "layer" | "choice" | "milestone";
}

export interface ArchiveEntry {
  runId: string;
  timestamp: number;
  stage: StageId;
  archetype: string;
  score: number;
  epEarned: number;
  duration: number;
  ending: string;
  notes?: string;
  favorite?: boolean;
}

export interface EventHistoryEntry {
  eventId: string;
  eventName: string;
  eventIcon: string;
  choiceId: string;
  choiceLabel: string;
  timestamp: number;
  gameTime: number;
}

export interface GameState {
  // Run state
  stageIndex: number;
  time: number;
  population: number;
  populationProgress: number; // 0-1 toward next population point
  maxPopulation: number; // peak population this run (for achievements)
  resources: Record<string, number>;
  capacities: Record<string, number>;
  ownedSystems: Record<string, number>;
  systemEnabled: Record<string, boolean>; // per-system on/off toggle
  technologies: Record<string, boolean>;
  lockedTechs: Record<string, boolean>; // techs locked via exclusiveWith (mutually-exclusive paths)
  archetypeAffinity: Record<string, number>; // drift during run
  lockedArchetype: string | null; // locked at Creature→Tribal
  log: string[];

  // Meta state
  evolutionPoints: number;
  totalRuns: number;
  galacticWins: number;
  stageClearCounts: Record<StageId, number>;
  fastestCellClear: number; // seconds, best time clearing Cell stage
  totalEventsResolved: number; // across all runs
  totalPlayTime: number; // seconds across all runs
  totalActions: number; // manual actions clicked across all runs
  totalSystemsBuilt: number; // systems built across all runs
  totalTechResearched: number; // techs researched across all runs
  upgrades: Record<string, number>;
  storyUnlocked: Record<string, boolean>;
  storyAcknowledged: Record<string, boolean>;
  archive: ArchiveEntry[];
  archivedArchetypes: string[];
  unlockedLayers: Record<string, boolean>;
  achievements: Record<string, boolean>; // earned achievements
  newAchievements: string[]; // queue of newly-earned achievement IDs for toast

  // Layer 1: Evolution (Challenges)
  unlockedChallenges: boolean;
  activeChallenge: string | null;
  completedChallenges: Record<string, boolean>;
  challengeRepeatCounts: Record<string, number>;
  showChallenges: boolean;
  showPrestigeTab: boolean;

  // Layer 2: Enlightenment (Foresight tree + Routes)
  enlightenmentUnlocked: boolean;
  divinity: number;
  selectedRoute: string | null;
  foresightNodes: Record<string, boolean>;
  showEnlightenment: boolean;

  // Layer 3: Transcendence (Offerings / Rituals / Scripts / Blood Pact)
  transcendenceUnlocked: boolean;
  showTranscendence: boolean;
  offeringsUsedThisRun: Record<string, number>;
  ritualUsesThisRun: Record<string, boolean>;
  ritualsUsedAllTime: Record<string, number>;
  bloodPactUsesThisRun: Record<string, number>;
  bloodPactUsedAllTime: boolean;
  activeScripts: Record<string, boolean>;
  scriptsTriedAllTime: Record<string, boolean>;
  activeRituals: Array<{ id: string; remaining: number }>;
  evolveSkipBuffs: number;

  // Layer 4: Genesis (Cradle World authoring)
  genesisUnlocked: boolean;
  showGenesis: boolean;
  worldConfig: import("../data/genesis").WorldConfig | null;
  cradleWorldWins: Record<string, boolean>;
  awakenedSeedsThisRun: Record<string, boolean>;
  awakenedSeedsAllTime: Record<string, boolean>;

  // Layer 5: Apotheosis (Divine Laws / Worship / Miracles / Heresy)
  apotheosisUnlocked: boolean;
  showApotheosis: boolean;
  divineLawsEnactedThisRun: Record<string, boolean>;
  divineLawsEnactedAllTime: Record<string, number>;
  worshipMode: string | null;
  worshipModesUsedAllTime: Record<string, boolean>;
  miracleUsesThisRun: Record<string, number>;
  miracleUsesAllTime: Record<string, number>;
  heresyLevel: number;
  heresyResponseUsesThisRun: Record<string, number>;
  heresySurvivedAllTime: boolean;

  // Layer 6: Singularity (Relic Loadouts + Logic Cores)
  singularityUnlocked: boolean;
  showSingularity: boolean;
  activeRelicLoadout: string | null;
  relicsBoundAllTime: Record<string, boolean>;
  activeLogicCores: Record<string, boolean>;
  logicCoresEnabledAllTime: Record<string, boolean>;

  // Layer 7: Omnipotence (Hybrid Lineages + Stances + Instability)
  omnipotenceUnlocked: boolean;
  showOmnipotence: boolean;
  activeHybridLineage: string | null;
  hybridLineagesTriedAllTime: Record<string, boolean>;
  activeStance: string; // defaults to "balanced"
  stancesTriedAllTime: Record<string, boolean>;
  instabilityLevel: number; // 0-100; run ends at 100
  peakInstability: number; // highest instability reached this run

  // Layer 8: Divinity (Prayer Channels + Divine Masks + Worship Polarities)
  divinityUnlocked: boolean; // distinct from `divinity: number` (the currency)
  showDivinityModal: boolean;
  prayerChannels: Record<string, number>; // channel id → level
  prayerOutput: number; // accumulated prayer this run
  activeDivineMask: string | null;
  divineMasksTriedAllTime: Record<string, boolean>;
  activeWorshipPolarity: string | null;
  worshipPolaritiesTriedAllTime: Record<string, boolean>;

  // Layer 9: Infinity (Echoes + Forks + Future Debt)
  infinityUnlocked: boolean;
  showInfinity: boolean;
  echoes: number; // Infinity currency
  echoesOwned: Record<string, number>; // echo type → count owned
  forksResolved: Record<string, "A" | "B">; // fork id → chosen branch
  forksResolvedAllTime: Record<string, boolean>;
  futureDebtUsesThisRun: Record<string, number>;
  futureDebtRepaidAllTime: boolean;
  activeDebt: Array<{ id: string; boostRemaining: number; penaltyRemaining: number }>;

  // Layer 10: Eternity (Testament Clauses + Canonizations + Permanence Weaves + Ending)
  eternityUnlocked: boolean;
  showEternity: boolean;
  testamentClauses: number; // Eternity currency
  testamentClausesOwned: Record<string, boolean>;
  canonizationsOwned: Record<string, number>; // canonization id → count purchased
  permanenceWeavesOwned: Record<string, number>; // weave id → count purchased
  endingChosen: "preserve" | "reset" | null; // null = not yet
  cosmicBoonStacks: number; // lifetime count of "reset" ending choices

  // UI state
  currentTab: TabId;
  speed: number;
  paused: boolean;
  showShop: boolean;
  showEvolve: boolean;
  showSettings: boolean;
  activeStoryPopup: string | null;
  activeEvent: string | null; // ID of the currently-offered random event
  eventCooldown: number; // seconds until next event can fire
  eventHistory: EventHistoryEntry[]; // log of past event choices this run
  hasSeenIntro: boolean;
  lastSaved: number;

  // Tutorial
  tutorialStep: number;
  tutorialActive: boolean;
  tutorialDismissed: boolean;
  // Settings
  eventFrequency: "off" | "normal" | "frequent";
}

export interface GameStore extends GameState {
  // Actions
  tick: (dt: number) => void;
  performAction: (actionId: string) => void;
  buySystem: (systemId: string, qty: number) => void;
  toggleSystem: (systemId: string) => void;
  enableAllSystems: (enabled: boolean) => void;
  buyTech: (techId: string) => void;
  buyUpgrade: (upgradeId: string) => void;
  evolveStage: () => void;
  triggerPrestige: () => void;
  setTab: (tab: TabId) => void;
  setSpeed: (speed: number) => void;
  togglePause: () => void;
  setShowShop: (v: boolean) => void;
  setShowEvolve: (v: boolean) => void;
  setShowSettings: (v: boolean) => void;
  setShowChallenges: (v: boolean) => void;
  setActiveChallenge: (id: string | null) => void;

  // Layer 2: Enlightenment
  setShowEnlightenment: (v: boolean) => void;
  selectRoute: (id: string | null) => void;
  purchaseForesightNode: (id: string) => void;

  // Layer 3: Transcendence
  setShowTranscendence: (v: boolean) => void;
  makeOffering: (id: string) => void;
  performRitual: (id: string) => void;
  toggleScript: (id: string) => void;
  performBloodPact: (id: string) => void;

  // Layer 4: Genesis
  setShowGenesis: (v: boolean) => void;
  setWorldConfig: (config: import("../data/genesis").WorldConfig) => void;
  clearWorldConfig: () => void;

  // Layer 5: Apotheosis
  setShowApotheosis: (v: boolean) => void;
  enactDivineLaw: (id: string) => void;
  setWorshipMode: (id: string | null) => void;
  performMiracle: (id: string) => void;
  respondToHeresy: (id: string) => void;

  // Layer 6: Singularity
  setShowSingularity: (v: boolean) => void;
  bindRelicLoadout: (id: string | null) => void;
  toggleLogicCore: (id: string) => void;

  // Layer 7: Omnipotence
  setShowOmnipotence: (v: boolean) => void;
  selectHybridLineage: (id: string | null) => void;
  setStance: (id: string) => void;

  // Layer 8: Divinity
  setShowDivinityModal: (v: boolean) => void;
  levelPrayerChannel: (id: string) => void;
  selectDivineMask: (id: string | null) => void;
  alignWorshipPolarity: (id: string | null) => void;

  // Layer 9: Infinity
  setShowInfinity: (v: boolean) => void;
  purchaseEcho: (id: string) => void;
  resolveFork: (id: string, branch: "A" | "B") => void;
  incurFutureDebt: (id: string) => void;

  // Layer 10: Eternity
  setShowEternity: (v: boolean) => void;
  purchaseTestamentClause: (id: string) => void;
  performCanonization: (id: string) => void;
  purchasePermanenceWeave: (id: string) => void;
  chooseEnding: (id: "preserve" | "reset") => void;

  dismissTutorial: () => void;
  resolveEvent: (eventId: string, choiceId: string) => void;
  setEventFrequency: (freq: "off" | "normal" | "frequent") => void;
  dismissStory: (id: string) => void;
  dismissAchievementToast: () => void;
  applyOfflineProgress: () => { elapsed: number; resourcesGained: Record<string, number>; applied: boolean } | null;
  hardReset: () => void;
  saveGame: () => void;
  loadGame: () => void;
  exportSave: () => string;
  importSave: (data: string) => boolean;
  addToLog: (msg: string) => void;
}
